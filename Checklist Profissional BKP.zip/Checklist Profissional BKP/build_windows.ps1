$ErrorActionPreference = 'Stop'

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot
$Python = Join-Path $ProjectRoot 'venv\Scripts\python.exe'

if (-not (Test-Path $Python)) {
    throw 'Ambiente virtual nao encontrado em venv. Crie-o e instale requirements.txt antes do build.'
}

& $Python -m pip install --upgrade pyinstaller
& $Python packaging\create_icon.py

Remove-Item -Recurse -Force build, dist -ErrorAction SilentlyContinue
& $Python -m PyInstaller `
    --noconfirm `
    --clean `
    ChecklistProfissional.spec

if ($LASTEXITCODE -ne 0) {
    throw "Falha ao gerar o executavel (codigo $LASTEXITCODE)."
}

New-Item -ItemType Directory -Force dist\ChecklistProfissional\logs | Out-Null
New-Item -ItemType Directory -Force dist\ChecklistProfissional\data\uploads\cisco | Out-Null
New-Item -ItemType Directory -Force dist\ChecklistProfissional\data\uploads\claro | Out-Null
New-Item -ItemType Directory -Force dist\ChecklistProfissional\data\pdfs | Out-Null

if (Test-Path .env) {
    Copy-Item .env dist\ChecklistProfissional\.env -Force
}

Write-Host "Executavel criado em: dist\ChecklistProfissional\ChecklistProfissional.exe"