from pathlib import Path

from PIL import Image, ImageDraw


def create_icon(output_path: Path) -> None:
    sizes = (16, 24, 32, 48, 64, 128, 256)
    images = []

    for size in sizes:
        image = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)

        radius = max(4, size // 6)
        draw.rounded_rectangle((0, 0, size - 1, size - 1), radius=radius, fill='#ee1d4a')

        # Escudo branco
        shield = [
            (size * 0.50, size * 0.15),
            (size * 0.75, size * 0.28),
            (size * 0.79, size * 0.57),
            (size * 0.60, size * 0.72),
            (size * 0.50, size * 0.83),
            (size * 0.40, size * 0.72),
            (size * 0.21, size * 0.57),
            (size * 0.25, size * 0.28),
        ]
        draw.polygon(shield, fill='#ffffff')

        # Triângulo vermelho central
        triangle = [
            (size * 0.37, size * 0.34),
            (size * 0.37, size * 0.66),
            (size * 0.68, size * 0.50),
        ]
        draw.polygon(triangle, fill='#ee1d4a')

        images.append(image)

    images[-1].save(output_path, format='ICO', sizes=[(size, size) for size in sizes])


if __name__ == '__main__':
    create_icon(Path(__file__).with_name('checklist.ico'))