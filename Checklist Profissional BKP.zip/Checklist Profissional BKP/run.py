#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script de inicialização da aplicação Checklist Profissional
Localizado na raiz do projeto para facilitar execução
"""
import sys
import os
import site
import threading
import time
import webbrowser
import subprocess

# Definir o diretório do projeto
project_root = os.path.dirname(os.path.abspath(__file__))


def criar_atalho_desktop():
    """Cria ou atualiza o atalho do aplicativo no Desktop do usuário."""
    if not getattr(sys, 'frozen', False) or os.name != 'nt':
        return

    executable = os.path.abspath(sys.executable)
    shortcut_name = 'Checklist Profissional.lnk'
    shortcut_script = (
        '$desktop = [Environment]::GetFolderPath(\'Desktop\'); '
        '$shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut(\n'
        '    (Join-Path $desktop $env:CHECKLIST_SHORTCUT_NAME)\n'
        '); '
        '$shortcut.TargetPath = $env:CHECKLIST_EXECUTABLE; '
        '$shortcut.WorkingDirectory = $env:CHECKLIST_WORKING_DIRECTORY; '
        '$shortcut.IconLocation = $env:CHECKLIST_EXECUTABLE + \',0\'; '
        '$shortcut.Description = \'Checklist Profissional\'; '
        '$shortcut.Save()'
    )
    environment = os.environ.copy()
    environment.update({
        'CHECKLIST_SHORTCUT_NAME': shortcut_name,
        'CHECKLIST_EXECUTABLE': executable,
        'CHECKLIST_WORKING_DIRECTORY': os.path.dirname(executable),
    })

    try:
        subprocess.run(
            [
                'powershell.exe',
                '-NoProfile',
                '-NonInteractive',
                '-ExecutionPolicy',
                'Bypass',
                '-Command',
                shortcut_script,
            ],
            env=environment,
            check=True,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except (OSError, subprocess.SubprocessError):
        pass

# Adicionar src/ ao path
sys.path.insert(0, os.path.join(project_root, 'src'))

# Garantir que o venv site-packages está no path
venv_path = os.path.join(project_root, 'venv')
if os.path.exists(venv_path):
    # Adicionar venv site-packages
    site_packages = os.path.join(venv_path, 'Lib', 'site-packages')
    if os.path.exists(site_packages):
        sys.path.insert(0, site_packages)
        print(f"✓ venv site-packages adicionado ao path: {site_packages}")

# Verificar se psutil está disponível
try:
    import psutil
    print(f"✓ psutil {psutil.__version__} disponível")
except ImportError:
    print("⚠ AVISO: psutil não encontrado. Instale com: pip install psutil")

# Importar e executar a aplicação
if __name__ == '__main__':
    criar_atalho_desktop()
    from app import app

    def abrir_navegador():
        time.sleep(1.5)
        webbrowser.open('http://127.0.0.1:5000')

    threading.Thread(target=abrir_navegador, daemon=True).start()
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=False,
        use_reloader=False
    )
