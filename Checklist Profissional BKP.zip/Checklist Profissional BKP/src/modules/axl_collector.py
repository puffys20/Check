# -*- coding: utf-8 -*-
"""
Módulo para coletar dados do CUCM via AXL SQL Toolkit.
Este módulo substitui a abordagem baseada em script .bat.
"""
import platform
import os
import subprocess
import inspect
from datetime import datetime
import glob
import requests
import logging
import xml.etree.ElementTree as ET
from config import BASE_DIR, config, get_cucm_ssl_verify
from requests.auth import HTTPBasicAuth
from zeep import Client, Settings, Transport
from zeep.exceptions import Fault


def _load_dotenv_if_present():
    """Carrega variáveis do .env na raiz do projeto ou em src/ quando existirem."""
    for env_path in [
        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '.env'),
        os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env'),
    ]:
        if not os.path.exists(env_path):
            continue
        with open(env_path, 'r', encoding='utf-8') as env_file:
            for line in env_file:
                line = line.strip()
                if not line or line.startswith('#') or '=' not in line:
                    continue
                key, value = line.split('=', 1)
                os.environ.setdefault(key.strip(), value.strip())

logger = logging.getLogger(__name__)

_load_dotenv_if_present()


class AXLCollector:
    def __init__(self):
        # O caminho para a pasta com os arquivos XML baixados.
        # A pasta 'resources/axlsqltoolkit' está na raiz do projeto.
        # __file__ = src/modules/axl_collector.py
        # dirname(__file__) = src/modules/
        # dirname(dirname(__file__)) = src/
        # dirname(dirname(dirname(__file__))) = raiz/
        self.xml_data_path = os.path.join(BASE_DIR, 'resources', 'axlsqltoolkit')

        self.wsdl_path = os.path.join(self.xml_data_path, 'AXLAPI.wsdl')
        self.cucm_host = os.getenv('CUCM_HOST') or os.getenv('CALLMANAGER_HOST')
        self.cucm_port = int(os.getenv('CUCM_PORT') or os.getenv('CALLMANAGER_PORT') or '8443')
        self.axl_user = os.getenv('AXL_USER') or os.getenv('CALLMANAGER_USER')
        self.axl_pass = os.getenv('AXL_PASS') or os.getenv('CALLMANAGER_PASS')

        self.online_mode = all([self.cucm_host, self.axl_user, self.axl_pass])
        self.client = None
        self.connection_status_detail = "Manual (lendo arquivos XML)"
        self.collection_errors = {}

        if self.online_mode:
            try:
                if not os.path.exists(self.wsdl_path):
                    raise FileNotFoundError("Arquivo AXLAPI.wsdl não encontrado na pasta axlsqltoolkit.")

                session = requests.Session()
                session.verify = get_cucm_ssl_verify()
                session.auth = HTTPBasicAuth(self.axl_user, self.axl_pass)
                request_timeout = max(1, int(os.getenv('AXL_TIMEOUT_SECONDS', '3')))
                transport = Transport(session=session, timeout=request_timeout)

                settings = Settings(strict=False, xml_huge_tree=True)

                self.client = Client(self.wsdl_path, settings=settings, transport=transport)
                self.client.service._binding_options['address'] = f'https://{self.cucm_host}:{self.cucm_port}/axl/'
                logger.info(f"Coletor AXL inicializado em modo ONLINE. Conectado a {self.cucm_host}:{self.cucm_port}")
                self.connection_status_detail = f"Online ({self.cucm_host}:{self.cucm_port})"
            except Exception as e:
                logger.error(f"Falha ao inicializar cliente Zeep em modo ONLINE: {e}", exc_info=True)
                self.online_mode = False  # Volta para o modo manual em caso de erro

        if not self.online_mode:
            if not os.path.isdir(self.xml_data_path):
                raise FileNotFoundError(f"O diretório de dados XML não foi encontrado em: {self.xml_data_path}")
            logger.info(f"Coletor AXL inicializado em modo MANUAL. Lendo arquivos de: {self.xml_data_path}")

    def check_ping(self, host=None):
        """Verifica a conectividade com o host usando ping."""
        target_host = host or self.cucm_host
        if not target_host:
            return "Host não configurado"

        # Parâmetro de ping dependendo do SO
        param = '-n' if platform.system().lower() == 'windows' else '-c'
        command = ['ping', param, '1', '-w', '2', target_host] # 1 tentativa, 2 segundos de timeout

        try:
            # Executa o comando sem mostrar a janela do console no Windows
            startupinfo = None
            if platform.system().lower() == 'windows':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

            return "Online" if subprocess.call(command, startupinfo=startupinfo) == 0 else "Offline"
        except Exception:
            return "Offline"


    def _read_and_parse_xml(self, query_name, is_sql_query=True):
        """Lê e processa um arquivo XML baseado no nome da consulta."""
        # O nome do arquivo será, por exemplo, 'get_phone_status.xml'
        file_path = os.path.join(self.xml_data_path, f"{query_name}.xml")
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                xml_content = f.read()
            
            root = ET.fromstring(xml_content)
            
            # O namespace pode variar, então vamos tentar encontrá-lo dinamicamente
            # Para queries SQL, o retorno está dentro de <return>. Para outras chamadas, pode ser diferente.
            if is_sql_query:
                return_element = root.find('.//{*}return')
            else:
                # Para chamadas não-SQL, o elemento de retorno tem o nome da resposta
                return_element = root.find(f".//{{*}}{query_name}Response/return")

            if return_element is None:
                logger.warning(f"Elemento <return> não encontrado no arquivo {file_path}")
                return []
            rows = []
            for row_element in return_element.findall('{*}row'):
                row_data = {child.tag: child.text for child in row_element}
                rows.append(row_data)
            
            return rows

        except FileNotFoundError:
            logger.debug(f"Fixture XML '{file_path}' não encontrado; consulta '{query_name}' indisponível no modo manual.")
            return []
        except Exception as e:
            logger.error(f"Erro ao processar o arquivo XML '{file_path}': {e}", exc_info=True)
            return []

    def _execute_sql_query(self, query, query_name):
        """Executa uma consulta SQL, seja online ou lendo um arquivo."""
        if self.online_mode and self.client:
            try:
                # A API Zeep retorna uma estrutura de objetos que convertemos para dicionário
                response = self.client.service.executeSQLQuery(sql=query)
                # A resposta pode não conter 'row' se não houver resultados
                return [dict(row) for row in response['return'].get('row', [])]
            except Fault as e:
                message = getattr(e, 'message', str(e))
                self.collection_errors[query_name] = message
                logger.error(f"Erro na consulta SQL AXL (online) [{query_name}]: {message}", exc_info=True)
                return []
            except Exception as e:
                self.collection_errors[query_name] = str(e)
                logger.error(f"Erro inesperado na consulta SQL AXL [{query_name}]: {e}", exc_info=True)
                return []
        else:
            # Modo manual: lê o arquivo XML correspondente ao nome da query passado como parâmetro.
            return self._read_and_parse_xml(query_name)

    def get_phone_status(self):
        """Obtém a contagem de telefones registrados e não registrados."""
        query = """
        SELECT
            SUM(CASE WHEN tkstatus.name = 'Registered' THEN 1 ELSE 0 END) as registered,
            SUM(CASE WHEN tkstatus.name = 'Unregistered' THEN 1 ELSE 0 END) as unregistered,
            SUM(CASE WHEN tkstatus.name NOT IN ('Registered', 'Unregistered') THEN 1 ELSE 0 END) as partial
        FROM device
        INNER JOIN typestatus AS tkstatus ON device.tkstatus = tkstatus.enum
        WHERE device.tkclass = 1
        """
        try:
            result = self._execute_sql_query(query, 'get_phone_status')
            if result:
                return {
                    'registered': self._to_int(result[0].get('registered')),
                    'unregistered': self._to_int(result[0].get('unregistered')),
                    'partial': self._to_int(result[0].get('partial'))
                }
        except Exception as e:
            self.collection_errors['get_phone_status'] = str(e)
            logger.error(f"Falha ao obter status dos telefones: {e}")
        
        # Retorna um valor padrão em caso de erro
        return {'registered': 0, 'unregistered': 0, 'partial': 0}

    def get_trunk_status(self):
        """Obtém o status dos trunks SIP."""
        query = "SELECT d.name, d.description, s.name as status FROM device d JOIN typestatus s ON d.tkstatus = s.enum WHERE d.tkclass = 4"
        try:
            results = self._execute_sql_query(query, 'get_trunk_status')
            trunks = []
            for row in results:
                status_map = {
                    # Os valores aqui devem corresponder exatamente ao que está no XML
                    'In Service': 'Ativo',
                    'Out of Service': 'Inativo',
                    'Unknown': 'Desconhecido'
                }
                trunks.append({
                    'name': row.get('name', 'N/A'),
                    'status': status_map.get(row.get('status'), 'Desconhecido')
                })
            return trunks
        except Exception as e:
            self.collection_errors['get_trunk_status'] = str(e)
            logger.error(f"Falha ao obter status dos trunks: {e}")
        
        return []

    def get_media_resources(self):
        """Obtém o uso de recursos de mídia (CFB, MTP, XCODER)."""
        query = "SELECT name, activecount FROM mediaresourcelistmember"
        try:
            results = self._execute_sql_query(query, 'get_media_resources')
            
            # Estrutura que o dashboard espera
            resources = {
                'cfb': {'label': 'Conference Bridges', 'inUse': 0, 'total': 48},
                'xcoder': {'label': 'Transcoders', 'inUse': 0, 'total': 24},
                'mtp': {'label': 'MTPs', 'inUse': 0, 'total': 12}
            }

            for row in results:
                # O nome do recurso no XML (ex: 'Cisco IOS MTP')
                name = row.get('name', '').lower()
                in_use = self._to_int(row.get('activecount'))
                
                if 'conference bridge' in name:
                    resources['cfb']['inUse'] += in_use
                elif 'transcoder' in name:
                    resources['xcoder']['inUse'] += in_use
                elif 'media termination point' in name:
                    resources['mtp']['inUse'] += in_use
            
            return resources
        except Exception as e:
            self.collection_errors['get_media_resources'] = str(e)
            logger.error(f"Falha ao obter dados de recursos de mídia: {e}")
            return {}

    def get_cucm_version(self):
        """Obtém a versão do CUCM usando uma chamada AXL padrão."""
        if self.online_mode and self.client:
            try:
                response = self.client.service.getCCMVersion()
                version = response['return']['componentVersion']['version']
                return {'version': version}
            except Fault as e:
                logger.error(f"Falha ao obter versão do CUCM (online): {e.message}")
                return {'version': 'Erro API'}
        else:
            # Modo manual: ler de um arquivo getCCMVersion.xml
            try:
                root = ET.parse(os.path.join(self.xml_data_path, 'getCCMVersion.xml')).getroot()
                # Encontrar o elemento de versão, ignorando namespaces
                # Ex: <ns:getCCMVersionResponse><return><componentVersion><version>12.5(1)SU3</version>...
                version_element = root.find('.//{*}version')
                if version_element is not None:
                    return {'version': version_element.text}
            except FileNotFoundError:
                logger.debug("Fixture getCCMVersion.xml não encontrado; versão indisponível no modo manual.")
            except Exception as e:
                logger.error(f"Falha ao obter versão do CUCM do arquivo XML: {e}")

        return {'version': 'Não disponível'}

    @staticmethod
    def _to_int(value):
        """Converte valores nulos ou textuais retornados pelo AXL para inteiros."""
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0

    def get_wsdl_timestamp(self):
        """Retorna a data de modificação do arquivo WSDL."""
        try:
            if os.path.exists(self.wsdl_path):
                mod_time = os.path.getmtime(self.wsdl_path)
                return datetime.fromtimestamp(mod_time).strftime('%d/%m/%Y %H:%M:%S')
        except Exception as e:
            logger.error(f"Erro ao obter timestamp do WSDL: {e}")
        return "Não encontrado"

    def get_cluster_nodes(self):
        """Obtém a lista de nós (servidores) do cluster CUCM."""
        if self.online_mode and self.client:
            try:
                # Usando uma chamada AXL padrão, não SQL
                response = self.client.service.listProcessNode(searchCriteria={'name': '%'}, returnedTags={'name': '', 'ipAddress': ''})
                nodes = response['return']['processNode']
                return [{'name': node['name'], 'ip': node.get('ipAddress', 'N/A')} for node in nodes]
            except Fault as e:
                logger.error(f"Falha ao obter nós do cluster (online): {e.message}")
                return []
        else:
            # Modo manual: ler de um arquivo listProcessNode.xml
            # No modo offline, retornamos dados de exemplo para evitar erros se o arquivo não existir.
            logger.info("Modo offline: Usando dados de exemplo para os nós do cluster.")
            return [{'name': 'Publisher (Offline)', 'ip': '?.?.?.?'}, {'name': 'Subscriber (Offline)', 'ip': '?.?.?.?'}]

    def get_service_status(self):
        """Obtém o status dos principais serviços do CUCM."""
        if self.online_mode and self.client:
            try:
                # Nomes dos serviços a serem verificados
                services_to_check = [
                    "Cisco CallManager",
                    "Cisco TFTP",
                    "Cisco IP Voice Media Streaming App"
                ]
                
                service_statuses = []
                for service_name in services_to_check:
                    # A API espera um padrão de busca, então usamos o nome exato
                    response = self.client.service.getServiceStatus(service_name)
                    status = response['return']['serviceInfo'][0]['status']
                    service_statuses.append({'name': service_name, 'status': status})
                
                return service_statuses
            except Fault as e:
                logger.error(f"Falha ao obter status dos serviços (online): {e.message}")
                return [{'name': 'Erro API', 'status': 'Unknown'}]
        else:
            # Modo manual: dados de exemplo
            logger.info("Modo offline: Usando dados de exemplo para status de serviços.")
            return [{'name': 'Cisco CallManager', 'status': 'Started'}, {'name': 'Cisco TFTP', 'status': 'Started'}]