document.addEventListener('DOMContentLoaded', function () {
    // Objeto para manter referência a todas as instâncias de gráficos
    let chartInstances = {};
    let realtimeRequestInFlight = false;

    // Renderizar o gráfico de pizza de atividades do módulo
    const moduleActivityCtx = document.getElementById('moduleActivityChart');
    if (moduleActivityCtx && window.dashboardConfig) {
        const stats = window.dashboardConfig.stats;
        chartInstances.moduleActivity = new Chart(moduleActivityCtx, {
            type: 'doughnut',
            data: {
                labels: ['Cisco', 'Claro', 'Salas'],
                datasets: [{
                    label: 'Total de Atividades',
                    data: [stats.cisco, stats.claro, stats.salas],
                    backgroundColor: [
                        'rgba(0, 153, 255, 0.7)',  // Azul Cisco
                        'rgba(0, 204, 109, 0.7)',  // Verde Claro
                        'rgba(255, 153, 0, 0.7)'   // Laranja Salas
                    ],
                    borderColor: [
                        '#0099ff',
                        '#00cc6d',
                        '#ff9900'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'right' } }
            }
        });
        // Registrar atualização no monitor
        window.logChartUpdate('moduleActivity', 'success', 'Gráfico renderizado');
    }

    // Função para destruir todas as instâncias de gráficos existentes
    function destroyCharts() {
        // Lista de IDs de gráficos que são dinâmicos e precisam ser destruídos
        const dynamicChartIds = Object.keys(chartInstances).filter(id => id !== 'moduleActivity');

        dynamicChartIds.forEach(chartId => {
            const chart = chartInstances[chartId];
            if (chart) {
                chart.destroy();
                delete chartInstances[chartId];
            }
        });
    }

    // --- FUNÇÕES AUXILIARES PARA GRÁFICOS ---

    const createRadialGauge = (ctx, label, value, max) => {
        const percentage = max > 0 ? Math.round((value / max) * 100) : 0;
        let color = '#28a745'; // Verde
        if (percentage > 70) color = '#ffc107'; // Amarelo
        if (percentage > 90) color = '#dc3545'; // Vermelho

        return new Chart(ctx, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [percentage, 100 - percentage],
                    backgroundColor: [color, 'rgba(255, 255, 255, 0.1)'],
                    borderColor: 'transparent',
                    borderWidth: 0,
                }]
            },
            options: {
                responsive: true,
                cutout: '80%',
                circumference: 360,
                plugins: { legend: { display: false }, tooltip: { enabled: false } }
            },
            plugins: [{
                id: 'centerText',
                beforeDraw: function(chart) {
                    const { width, height, ctx } = chart;
                    ctx.save();
                    ctx.font = `bold 28px sans-serif`;
                    ctx.fillStyle = color;
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(`${percentage}%`, width / 2, height / 2);
                    ctx.restore();
                }
            }]
        });
    };

    const createBarChart = (ctx, labels, values, barColors, label) => new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: values,
                backgroundColor: barColors,
                borderColor: barColors,
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: { callbacks: { label: (c) => ` ${c.label}: ${c.raw}%` } },
                datalabels: {
                    anchor: 'end', align: 'end', color: 'white',
                    formatter: (value) => value + '%'
                }
            },
            scales: { 
                x: { min: 0, max: 100, grid: { color: 'rgba(255, 255, 255, 0.1)' }, ticks: { stepSize: 10, callback: v => v + '%' } }, 
                y: { 
                    grid: { display: false } 
                } 
            }
        }
    });

    const createLineChart = (ctx, labels, data, label, color) => {
        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: label,
                    data: data,
                    borderColor: color,
                    backgroundColor: `${color}33`, // com transparência
                    fill: true,
                    tension: 0.4
                }]
            },
            options: { 
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: {
                        grid: { 
                            color: 'rgba(255, 255, 255, 0.05)' 
                        },
                        beginAtZero: true
                    },
                    x: {
                        grid: { 
                            display: false 
                        }
                    }
                }
            }
        });
        return chart;
    };

    const createStackedAreaChart = (ctx, labels, datasets) => {
        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: datasets.map(ds => ({
                    ...ds,
                    fill: true,
                    tension: 0.4
                }))
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'top' } },
                scales: {
                    y: {
                        stacked: true,
                        beginAtZero: true
                    }
                }
            }
        });
        return chart;
    };

    const fetchRecentActivity = async () => {
        try {
            const response = await fetch(window.dashboardConfig.urls.recent_activity);
            const result = await response.json();
            const activityBody = document.getElementById('recentActivityBody');

            if (result.sucesso && activityBody) {
                if (result.atividades.length > 0) {
                    activityBody.innerHTML = result.atividades.map(item => {
                        const date = new Date(item.data);
                        const formattedDate = date.toLocaleString('pt-BR', {
                            day: '2-digit', month: '2-digit', year: 'numeric',
                            hour: '2-digit', minute: '2-digit'
                        });
                        const detail = item.detalhe.length > 50 ? item.detalhe.substring(0, 50) + '...' : item.detalhe;

                        let icon = 'fa-file-alt';
                        if (item.tipo.includes('Cisco')) icon = 'fa-network-wired';
                        if (item.tipo.includes('Claro')) icon = 'fa-building';
                        if (item.tipo.includes('Inspeção')) icon = 'fa-door-open';
                        if (item.tipo.includes('Atualização')) icon = 'fa-sync-alt';

                        return `
                            <tr>
                                <td><i class="fas ${icon}" style="margin-right: 8px;"></i>${item.tipo}</td>
                                <td title="${item.detalhe}">${detail}</td>
                                <td>${formattedDate}</td>
                            </tr>
                        `;
                    }).join('');
                } else {
                    activityBody.innerHTML = '<tr><td colspan="3" style="text-align:center;">Nenhuma atividade recente.</td></tr>';
                }
            }
        } catch (error) { console.error("Erro ao buscar atividade recente:", error); }
    };

    function showLoading(show) {
        const loadingOverlay = document.getElementById('loading-overlay');
        if (show) {
            loadingOverlay.classList.remove('hidden');
        } else {
            loadingOverlay.classList.add('hidden');
        }
    }

    // --- FUNÇÃO PRINCIPAL PARA BUSCAR E RENDERIZAR DADOS ---
    async function fetchAndRenderRealtimeData() {
        if (realtimeRequestInFlight) return;
        realtimeRequestInFlight = true;

        const controller = new AbortController();
        const requestTimeout = setTimeout(() => controller.abort(), 15000);

        try {
            showLoading(true); // Mostra o esqueleto de carregamento
            window.logChartUpdate('RTMT API', 'success', 'Iniciando requisição');
            
            // Chamada real para a API que usa o AXLCollector
            const response = await fetch(window.dashboardConfig.urls.rtmt_data, { signal: controller.signal });
            const result = await response.json();
            
            if (!result.sucesso) {
                console.error("Erro API RTMT:", result.mensagem);
                window.logChartUpdate('RTMT API', 'error', result.mensagem);
                const realtimeView = document.getElementById('realtime-view');
                realtimeView.innerHTML = `<p class="error-message" style="padding: 40px;"><i class="fas fa-exclamation-triangle"></i> Falha ao carregar dados do CUCM: ${result.mensagem}</p>`;
                showLoading(false);
                return;
            }
            const data = result.dados;
            window.logChartUpdate('RTMT API', 'success', 'Dados recebidos');

            // Renderizar Status da Conexão
            const statusIndicator = document.getElementById('connection-status-indicator');
            if (statusIndicator && data.connectionMode) {
                let statusClass = 'status-inativo';
                let iconClass = 'fa-times-circle';

                if (data.connectionMode.startsWith('Online')) {
                    statusClass = 'status-ativo';
                    iconClass = data.connectionMode.includes('API') ? 'fa-check-circle' : 'fa-network-wired';
                } else if (data.connectionMode.includes('Cache')) {
                    statusClass = 'status-aviso';
                    iconClass = 'fa-hdd';
                } else { // Unreachable
                    statusClass = 'status-inativo';
                    iconClass = 'fa-exclamation-triangle';
                }

                statusIndicator.innerHTML = `
                    <span class="connection-status ${statusClass}"><i class="fas ${iconClass}"></i> ${data.connectionMode}</span>
                `;
                statusIndicator.classList.remove('hidden');
            }

            // Renderizar Versão do CUCM
            const versionIndicator = document.getElementById('cucm-version-indicator');
            const versionText = document.getElementById('cucm-version-text');
            if (versionIndicator && versionText && data.cucmVersion) {
                versionText.textContent = data.cucmVersion;
                versionIndicator.classList.remove('hidden');
            }

            // Renderizar Status do Ping
            const pingIndicator = document.getElementById('ping-status-indicator');
            if (pingIndicator && data.pingStatus) {
                let statusClass = 'status-inativo';
                let iconClass = 'fa-times-circle';
                let text = data.pingStatus;

                if (data.pingStatus === 'Online') {
                    statusClass = 'status-ativo';
                    iconClass = 'fa-check-circle';
                } else if (data.pingStatus === 'Offline') {
                    statusClass = 'status-inativo';
                    iconClass = 'fa-exclamation-triangle';
                } else { // Host não configurado
                    statusClass = 'status-aviso';
                    iconClass = 'fa-question-circle';
                }
                pingIndicator.innerHTML = `<span class="connection-status ${statusClass}"><i class="fas ${iconClass}"></i> Ping: ${text}</span>`;
                pingIndicator.classList.remove('hidden');
            }

            // Renderizar Timestamps
            const timestampInfo = document.getElementById('timestamp-info');
            const lastUpdatedEl = document.getElementById('last-updated-time');
            const wsdlTimestampEl = document.getElementById('wsdl-timestamp');

            if (timestampInfo && lastUpdatedEl && wsdlTimestampEl) {
                if (data.lastUpdated) {
                    lastUpdatedEl.innerHTML = `<i class="fas fa-sync-alt"></i> Atualizado às: <strong>${data.lastUpdated}</strong>`;
                }
                if (data.wsdlTimestamp) {
                    wsdlTimestampEl.textContent = data.wsdlTimestamp;
                }
                timestampInfo.classList.remove('hidden');
            }

            // --- Renderizar Saúde do Cluster (Gráficos de Barra) ---
            const nodeNames = data.clusterHealth.map(n => n.name);
            const cpuValues = data.clusterHealth.map(n => n.cpu);
            const memValues = data.clusterHealth.map(n => n.memory);
            const diskValues = data.clusterHealth.map(n => n.disk);
            const barColors = ['#0099ff', '#457b9d', '#a8dadc', '#f1faee'];

            // Função para atualizar ou criar gráficos de barra
            const updateOrCreateBarChart = (chartId, canvasId, labels, values, colors, label) => {
                const canvas = document.getElementById(canvasId);
                const container = canvas.parentElement;
                const chartHeight = Math.max(140, labels.length * 40);
                container.style.height = `${chartHeight}px`;
                container.style.minHeight = `${chartHeight}px`;

                if (chartInstances[chartId]) {
                    const chart = chartInstances[chartId];
                    chart.data.labels = labels;
                    chart.data.datasets[0].data = values;
                    chart.update();
                } else {
                    chartInstances[chartId] = createBarChart(canvas, labels, values, colors, label);
                }
            };

            // Atualizar ou criar os gráficos
            updateOrCreateBarChart('cpuBars', 'cpu-bars', nodeNames, cpuValues, barColors, 'CPU');
            updateOrCreateBarChart('memBars', 'mem-bars', nodeNames, memValues, barColors, 'Memory');
            updateOrCreateBarChart('diskBars', 'disk-bars', nodeNames, diskValues, barColors, 'Disk');
            
            // Remover skeletons de carregamento após renderizar os gráficos
            const skeletons = document.querySelectorAll('.chart-panel.skeleton');
            skeletons.forEach(skeleton => {
                skeleton.remove();
            });
            
            window.logChartUpdate('CPU Graph', 'success', `${nodeNames.length} nós`);
            window.logChartUpdate('Memory Graph', 'success', `${nodeNames.length} nós`);
            window.logChartUpdate('Disk Graph', 'success', `${nodeNames.length} nós`);

            // Atualizar ou criar o gráfico de Volume de Chamadas
            if (chartInstances.callVolume) {
                const chart = chartInstances.callVolume;
                chart.data.labels = data.callVolume.labels;
                chart.data.datasets[0].data = data.callVolume.data;
                chart.update();
            } else {
                chartInstances.callVolume = createLineChart(document.getElementById('callVolumeChart'), data.callVolume.labels, data.callVolume.data, 'Chamadas', '#00cc6d');
            }
            window.logChartUpdate('Call Volume Chart', 'success', `${data.callVolume.data.length} pontos`);

            // Renderizar Status dos Telefones
            const totalPhones = data.phoneStatus.registered + data.phoneStatus.unregistered + data.phoneStatus.partial;
            
            if (chartInstances.phoneStatus) {
                const chart = chartInstances.phoneStatus;
                chart.data.datasets[0].data = [data.phoneStatus.registered, data.phoneStatus.unregistered, data.phoneStatus.partial];
                // Atualiza o total no plugin de texto central
                chart.options.plugins.centerText.total = totalPhones;
                chart.update();
            } else {
                chartInstances.phoneStatus = new Chart(document.getElementById('phoneStatusChart'), {
                    type: 'doughnut',
                    data: {
                        labels: ['Registrados', 'Não Registrados', 'Parcial'],
                        datasets: [{
                            data: [data.phoneStatus.registered, data.phoneStatus.unregistered, data.phoneStatus.partial],
                            backgroundColor: ['#28a745', '#dc3545', '#ffc107'],
                            borderColor: 'var(--bg-secondary)',
                            borderWidth: 4
                        }]
                    },
                    options: { 
                        responsive: true, 
                        cutout: '70%',
                        plugins: { 
                            legend: { display: false },
                            tooltip: { enabled: true },
                            centerText: { total: totalPhones } // Passa o total para o plugin
                        }
                    },
                    plugins: [{
                        id: 'centerText',
                        beforeDraw: function(chart) {
                            const ctx = chart.ctx;
                            const center = { x: chart.width / 2, y: chart.height / 2 };
                            const total = chart.options.plugins.centerText.total; // Lê o total das opções
                            ctx.save();
                            ctx.fillStyle = 'white';
                            ctx.font = 'bold 24px sans-serif';
                            ctx.textAlign = 'center';
                            ctx.textBaseline = 'middle';
                            ctx.fillText(total, center.x, center.y);
                            ctx.restore();
                        }
                    }]
                });
            }
            window.logChartUpdate('Phone Status Chart', 'success', `${totalPhones} telefones`);

            const getPercentage = (value, total) => total > 0 ? ((value / total) * 100).toFixed(1) : 0;

            document.getElementById('phoneStatusSummary').innerHTML = `
                <ul>
                    <li><span class="status-badge ativo">Registrados</span> <strong>${data.phoneStatus.registered}</strong> <span class="text-secondary">(${getPercentage(data.phoneStatus.registered, totalPhones)}%)</span></li>
                    <li><span class="status-badge inativo">Não Registrados</span> <strong>${data.phoneStatus.unregistered}</strong> <span class="text-secondary">(${getPercentage(data.phoneStatus.unregistered, totalPhones)}%)</span></li>
                    <li><span class="status-badge" style="background-color: rgba(255, 193, 7, 0.2); color: #ffc107;">Parcial</span> <strong>${data.phoneStatus.partial}</strong> <span class="text-secondary">(${getPercentage(data.phoneStatus.partial, totalPhones)}%)</span></li>
                </ul>`;

            // Renderizar Status dos Trunks
            const trunkTableBody = document.querySelector('#trunkStatusTable tbody');
            if (trunkTableBody) {
                trunkTableBody.innerHTML = data.trunkStatus.map(trunk => `
                    <tr>
                        <td>${trunk.name}</td>
                        <td><span class="status-badge ${trunk.status.toLowerCase()}">${trunk.status}</span></td>
                    </tr>
                `).join('');
            }

            // Renderizar Recursos de Mídia
            const mediaContainer = document.getElementById('mediaResourcesContainer');
            // Limpa o contêiner a cada atualização para evitar duplicação de elementos ao recarregar os dados.
            mediaContainer.innerHTML = ''; 

            Object.keys(data.mediaResources).forEach(key => {
                const resource = data.mediaResources[key];
                const chartId = `gauge-${key}`;
                
                const wrapper = document.createElement('div');
                wrapper.className = 'radial-gauge';
                wrapper.innerHTML = `<canvas id="${chartId}"></canvas><div class="gauge-label" style="margin-top: 10px;">${resource.label}</div><div class="gauge-value">${resource.inUse} / ${resource.total}</div>`;
                mediaContainer.appendChild(wrapper);
                const newCtx = document.getElementById(chartId).getContext('2d');
                chartInstances[chartId] = createRadialGauge(newCtx, resource.label, resource.inUse, resource.total);
            });
            window.logChartUpdate('Media Resources', 'success', `${Object.keys(data.mediaResources).length} recursos`);


            // Renderizar Status dos Serviços
            const serviceStatusList = document.getElementById('serviceStatusList');
            if (serviceStatusList && data.serviceStatus) {
                serviceStatusList.innerHTML = data.serviceStatus.map(service => {
                    const isStarted = service.status === 'Started';
                    const statusClass = isStarted ? 'ativo' : 'inativo';
                    const statusText = isStarted ? 'Iniciado' : 'Parado';

                    return `
                        <div class="service-status-item">
                            <div class="status-icon ${statusClass}"></div>
                            <span>${service.name}</span>
                            <strong style="margin-left: auto; color: var(--${isStarted ? 'success' : 'error'});">${statusText}</strong>
                        </div>
                    `;
                }).join('');
            } else {
                document.getElementById('cucmServicesContainer').classList.add('hidden');
            }

            // ========== SISTEMA PROFISSIONAL ==========
            if (window.dashboardProfessional) {
                window.dashboardProfessional.renderAll(data);
            }

            // ========== MÉTRICAS AVANÇADAS ==========
            console.log('🔍 [DEBUG] Iniciando renderização de Métricas Avançadas');
            console.log('🔍 [DEBUG] window.advancedMetrics:', !!window.advancedMetrics);
            console.log('🔍 [DEBUG] advancedMetricsContainer:', !!document.getElementById('advancedMetricsContainer'));
            
            if (window.advancedMetrics) {
                const advContainer = document.getElementById('advancedMetricsContainer');
                if (advContainer) {
                    try {
                        console.log('🔍 [DEBUG] Chamando renderAll()...');
                        const html = window.advancedMetrics.renderAll();
                        console.log('✅ [SUCCESS] Renderizando Métricas Avançadas...', html.length + ' chars');
                        advContainer.innerHTML = html;
                        console.log('✅ [SUCCESS] Conteúdo inserido no container');
                        window.logChartUpdate('Advanced Metrics', 'success', '7 seções renderizadas (' + html.length + ' chars)');
                    } catch(e) {
                        console.error('❌ Erro ao renderizar Métricas Avançadas:', e);
                        console.error('❌ Stack:', e.stack);
                        window.logChartUpdate('Advanced Metrics', 'error', 'Erro: ' + e.message);
                    }
                } else {
                    console.warn('⚠️ Container advancedMetricsContainer não encontrado');
                    window.logChartUpdate('Advanced Metrics', 'warning', 'Container não encontrado');
                }
            } else {
                console.warn('⚠️ window.advancedMetrics não definido');
                window.logChartUpdate('Advanced Metrics', 'warning', 'advancedMetrics não definido');
            }

        } catch (error) {
            console.error("Erro ao buscar dados do RTMT:", error);
            window.logChartUpdate('RTMT API', 'error', error.message);
            const realtimeView = document.getElementById('realtime-view');
            const message = error.name === 'AbortError'
                ? 'A API RTMT demorou mais de 10 segundos para responder.'
                : 'Não foi possível conectar à API de dados. Verifique o console para mais detalhes.';
            realtimeView.innerHTML = `<p class="error-message" style="padding: 40px;"><i class="fas fa-exclamation-triangle"></i> ${message}</p>`;
        } finally {
            clearTimeout(requestTimeout);
            realtimeRequestInFlight = false;
            showLoading(false); // Esconde o esqueleto de carregamento
            window.logChartUpdate('Dashboard', 'success', 'Atualização completa');
        }
    }

    async function fetchAndRenderHistoryData(days = 30) {
        try {
            destroyCharts(); // Destruir gráficos de tempo real (medidores)
            showLoading(true);
            window.logChartUpdate('History Data', 'success', `Carregando ${days} dias`);
            
            // Adiciona o parâmetro 'dias' à URL da API
            const url = `${window.dashboardConfig.urls.rtmt_data_history}?dias=${days}`;
            const response = await fetch(url);
            const result = await response.json();
            if (!result.sucesso) {
                console.error("Erro API Histórico:", result.mensagem);
                window.logChartUpdate('History Data', 'error', result.mensagem);
                return;
            }
            const { labels, dados } = result;
            window.logChartUpdate('History Data', 'success', `${labels.length} períodos carregados`);
            
            // Renderizar Gráfico Histórico de CPU
            chartInstances.cpuHistory = new Chart(document.getElementById('cpuHistoryChart'), {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        { label: 'Publisher CPU', data: dados.cpu.pub, borderColor: '#0099ff', fill: false, tension: 0.1 },
                        { label: 'Subscriber 1 CPU', data: dados.cpu.sub1, borderColor: '#457b9d', fill: false, tension: 0.1 }
                    ]
                },
                options: { 
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { 
                        legend: { position: 'top' },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return `${context.dataset.label}: ${context.parsed.y}%`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            min: 0,
                            max: 100,
                            ticks: {
                                callback: function(value) { return value + '%'; }, stepSize: 10
                            },
                            grid: {
                                color: 'rgba(255, 255, 255, 0.05)'
                            }
                        },
                        x: {
                            ticks: {
                                autoSkip: days > 15, // Pula rótulos se o período for longo
                                maxRotation: days > 10 ? 45 : 0, // Rotaciona se o período for longo
                            }
                        }
                    }
                }
            });
            window.logChartUpdate('CPU History', 'success', 'Gráfico renderizado');

            // Renderizar Gráfico Histórico de Memória
            chartInstances.memHistory = new Chart(document.getElementById('memHistoryChart'), {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        { label: 'Publisher Memória', data: dados.memory.pub, borderColor: '#e63946', fill: false, tension: 0.1 },
                        { label: 'Subscriber 1 Memória', data: dados.memory.sub1, borderColor: '#a8dadc', fill: false, tension: 0.1 }
                    ]
                },
                options: { 
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { 
                        legend: { position: 'top' },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return `${context.dataset.label}: ${context.parsed.y}%`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            min: 0,
                            max: 100,
                            ticks: {
                                callback: function(value) { return value + '%'; }, stepSize: 10
                            },
                            grid: {
                                color: 'rgba(255, 255, 255, 0.05)'
                            }
                        },
                        x: {
                            ticks: {
                                autoSkip: days > 15,
                                maxRotation: days > 10 ? 45 : 0
                            }
                        }
                    }
                }
            });
            window.logChartUpdate('Memory History', 'success', 'Gráfico renderizado');

            // Renderizar Gráfico Histórico de Volume de Chamadas
            chartInstances.callVolumeHistory = createLineChart(document.getElementById('callVolumeHistoryChart'), labels, dados.call_volume, 'Chamadas por Dia', '#00cc6d');
            // Adicionar configuração do eixo X após a criação
            if (chartInstances.callVolumeHistory) {
                chartInstances.callVolumeHistory.options.scales.x = {
                    ticks: {
                        autoSkip: days > 15,
                        maxRotation: days > 10 ? 45 : 0
                    },
                    grid: { 
                        display: false 
                    }
                };
                chartInstances.callVolumeHistory.update();
            }
            window.logChartUpdate('Call Volume History', 'success', 'Gráfico renderizado');
            
            // Renderizar Gráfico Histórico de Status dos Telefones (Área Empilhada)
            chartInstances.phoneStatusHistory = createStackedAreaChart(document.getElementById('phoneStatusHistoryChart'), labels, [
                { label: 'Registrados', data: dados.phone_status.registered, backgroundColor: 'rgba(40, 167, 69, 0.5)', borderColor: '#28a745' },
                { label: 'Não Registrados', data: dados.phone_status.unregistered, backgroundColor: 'rgba(220, 53, 69, 0.5)', borderColor: '#dc3545' },
                { label: 'Parcial', data: dados.phone_status.partial, backgroundColor: 'rgba(255, 193, 7, 0.5)', borderColor: '#ffc107' }
            ]);

            // Adicionar configuração do eixo X após a criação
            if (chartInstances.phoneStatusHistory) {
                chartInstances.phoneStatusHistory.options.scales.x = {
                    ticks: {
                        autoSkip: days > 15,
                        maxRotation: days > 10 ? 45 : 0
                    },
                    grid: { 
                        display: false 
                    }
                };
                chartInstances.phoneStatusHistory.update();
            }
            window.logChartUpdate('Phone Status History', 'success', 'Gráfico renderizado');

            // Renderizar Gráfico Histórico de Recursos de Mídia (Área Empilhada)
            chartInstances.mediaResourceHistory = createStackedAreaChart(document.getElementById('mediaResourceHistoryChart'), labels, [
                { label: 'Conference Bridges', data: dados.media_resources.cfb, backgroundColor: 'rgba(69, 123, 157, 0.5)', borderColor: '#457b9d' },
                { label: 'Transcoders', data: dados.media_resources.xcoder, backgroundColor: 'rgba(168, 218, 220, 0.5)', borderColor: '#a8dadc' },
                { label: 'MTPs', data: dados.media_resources.mtp, backgroundColor: 'rgba(241, 250, 238, 0.5)', borderColor: '#f1faee' }
            ]);

            // Adicionar configuração do eixo X após a criação
            if (chartInstances.mediaResourceHistory) {
                chartInstances.mediaResourceHistory.options.scales.x = {
                    ticks: {
                        autoSkip: days > 15,
                        maxRotation: days > 10 ? 45 : 0
                    },
                    grid: { 
                        display: false 
                    }
                };
                chartInstances.mediaResourceHistory.update();
            }
            window.logChartUpdate('Media Resources History', 'success', 'Gráfico renderizado');

        } catch (error) {
            console.error("Erro ao buscar dados históricos:", error);
            window.logChartUpdate('History Data', 'error', error.message);
        } finally {
            showLoading(false);
            window.logChartUpdate('Dashboard', 'success', 'Histórico completo');
        }
    }

    function toggleDashboardView(view) {
        // Para o intervalo de atualização antes de trocar de view
        if (autoUpdateInterval) {
            clearInterval(autoUpdateInterval);
            autoUpdateInterval = null;
        }
        
        destroyCharts();

        const realtimeView = document.getElementById('realtime-view');
        const historyView = document.getElementById('history-view');

        if (view === 'history') {
            realtimeView.classList.add('hidden');
            historyView.classList.remove('hidden');
            const days = document.getElementById('historyDaysSelector')?.value || 30;
            fetchAndRenderHistoryData(days);
        } else { // 'realtime'
            historyView.classList.add('hidden');
            realtimeView.classList.remove('hidden');
            fetchAndRenderRealtimeData().then(() => {
                startAutoUpdate(); // Inicia a atualização automática APÓS a primeira renderização
            });
        }
    }

    // --- INICIALIZAÇÃO ---
    let autoUpdateInterval = null; // Variável para controlar o intervalo
    let currentView = 'realtime'; // Rastreia a view ativa
    const timeRangeSelector = document.getElementById('timeRangeSelector');
    
    if (timeRangeSelector) {
        // Usuário é admin, pode alternar as views
        toggleDashboardView(timeRangeSelector.value);
        timeRangeSelector.addEventListener('change', (e) => {
            currentView = e.target.value;
            toggleDashboardView(e.target.value);
        });
    } else {
        // Se o seletor não existe, o usuário não é admin.
        // Usuário não é admin, carrega a view de tempo real por padrão
        currentView = 'realtime';
        toggleDashboardView('realtime');
    }

    fetchRecentActivity();

    // Função para iniciar a atualização automática
    function startAutoUpdate() {
        if (autoUpdateInterval) clearInterval(autoUpdateInterval);
        autoUpdateInterval = setInterval(() => { 
            if (currentView === 'realtime') {
                // Na atualização automática, não mostramos o overlay de loading para uma experiência mais fluida
                const loadingOverlay = document.getElementById('loading-overlay');
                loadingOverlay.classList.add('hidden'); // Garante que esteja escondido
                fetchAndRenderRealtimeData(false); // Passa false para não mostrar o loading
            }
        }, 2000);
    }
});