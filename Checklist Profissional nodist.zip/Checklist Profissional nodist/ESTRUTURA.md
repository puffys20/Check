# 📋 Checklist Profissional - Estrutura Reorganizada

## 🎯 Novo Layout do Projeto

```
Checklist Profissional/
├── 📁 src/                      # Código-fonte Python
│   ├── app.py                   # Aplicação Flask principal
│   ├── config.py                # Configurações
│   └── modules/                 # Módulos Python
│       ├── auth.py
│       ├── cisco.py
│       ├── claro.py
│       ├── salas.py
│       ├── database.py
│       ├── axl_collector.py
│       ├── perfmon_collector.py
│       ├── email_utils.py
│       └── rtmt_collector.py
│
├── 📁 static/                   # Arquivos estáticos
│   ├── css/
│   ├── js/
│   └── images/
│
├── 📁 templates/                # Templates HTML (Jinja2)
│   ├── base.html
│   ├── dashboard.html
│   ├── auth/
│   ├── modulos/
│   └── erros/
│
├── 📁 data/                     # Dados e armazenamento
│   ├── uploads/                 # Arquivos enviados
│   │   ├── cisco/
│   │   └── claro/
│   ├── pdfs/                    # PDFs gerados
│   ├── temp_screenshots/        # Screenshots temporários
│   └── usuarios.db              # Database SQLite
│
├── 📁 docs/                     # Documentação
│   ├── Avaliação/
│   └── *.md                     # Documentação técnica
│
├── 📁 resources/                # Recursos (WSDL, XSD)
│   └── axlsqltoolkit/
│
├── 📁 tests/                    # Scripts de teste
│   ├── test_*.py
│   └── debug_*.py
│
├── 📁 logs/                     # Logs da aplicação
│   └── app.log
│
├── 📁 venv/                     # Virtual environment
│
├── run.py                       # ⭐ INICIAR AQUI!
├── requirements.txt             # Dependências
├── .env.example                 # Exemplo de variáveis
├── .gitignore                   # Git ignore
└── README.md                    # Este arquivo
```

## 🚀 Como Executar

### Opção 1: Usando run.py (RECOMENDADO)
```bash
python run.py
```

### Opção 2: Diretamente (cd src/ + python app.py)
```bash
cd src
python app.py
```

## 📦 Dependências

Instalar dependências:
```bash
pip install -r requirements.txt
```

## ⚙️ Configuração

1. Copiar `.env.example` para `.env` (na raiz)
2. Editar `.env` com suas variáveis:
   - `MAIL_SERVER`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`
   - `ADMIN_EMAIL`, `ADMIN_PASSWORD`
   - `CUCM_HOST`, `AXL_USER`, `AXL_PASS` (opcional)

## 📍 Locais Importantes

| Recurso | Localização |
|---------|------------|
| **App** | `src/app.py` |
| **Config** | `src/config.py` |
| **Database** | `data/usuarios.db` |
| **Uploads** | `data/uploads/` |
| **Logs** | `logs/app.log` |
| **Docs** | `docs/*.md` |

## ✅ Benefícios da Reorganização

✨ **Melhor Organização**
- Código separado de recursos
- Dados centralizados em `data/`
- Documentação em `docs/`

✨ **Mais Profissional**
- Segue padrão de projetos Python
- Fácil de manter e expandir
- Separação clara de responsabilidades

✨ **Escalável**
- Fácil adicionar novos módulos
- Estrutura pronta para deployment
- Compatível com Docker/CI-CD

## 🔧 Troubleshooting

### Erro: "ModuleNotFoundError: No module named 'config'"
- Use `python run.py` na raiz (não em src/)
- Ou adicione `src/` ao PYTHONPATH

### Erro: "Template not found"
- Verifique se `templates/` está na raiz
- Não mova `templates/` para src/

### Erro: "Database not found"
- `data/usuarios.db` é criado automaticamente
- Verifique permissões de escrita em `data/`

---

**Versão:** 1.0.0  
**Última Atualização:** 2026-07-01
