# 📊 ANÁLISE COMPLETA - Integração AXL 8.5 com Dashboard CUCM

**Data**: 01/07/2026  
**Status**: ✅ Análise Completa  
**Versão CUCM**: 8.5 (Latest)  
**Arquivos Atualizados**: ✓ WSDL/XSD em `axlsqltoolkit/schema/current/`

---

## 📋 SUMÁRIO EXECUTIVO

Você atualizou o toolkit AXL para versão **8.5**, que suporta **120+ operações SOAP** para consultar dados do CallManager. O dashboard atualmente usa apenas **5%** do potencial disponível. Este documento apresenta um plano para explorar todas as capacidades.

### 🎯 Objetivos:
1. **Expandir dados** do dashboard (28 → 40+ métricas)
2. **Implementar alertas** baseados em limites do AXL
3. **Criar histórico** de dados (trending)
4. **Integrar Perfmon** para CPU/Memória/Disco reais
5. **Gerar relatórios** automatizados

---

## 1️⃣ ESTADO ATUAL DO SISTEMA

### ✅ O Que Funciona
- Dashboard renderiza **5 gráficos de tempo real** (CPU, Memória, Disco, Volume de Chamadas, Status de Telefones)
- **7 seções de métricas avançadas** (Qualidade de Voz, Bandwidth, Dispositivos, Chamadas, Departamentos, Usuários, API)
- Dados simulados para CPU/Memória/Disco (valores aleatórios 0-100%)
- Status de telefones e troncos (dados reais do AXL)
- Interface profissional com alertas e health score

### ❌ O Que Falta
- **Dados de Performance Real**: CPU/Memória/Disco precisam da API Perfmon (não AXL)
- **Histórico de Dados**: Sem trending/gráficos históricos
- **Alertas Automáticos**: Sem notificações quando limites são excedidos
- **Relatórios**: Sem exportação ou geração de relatórios
- **Integração Completa**: Alguns dados ainda estão mockados

### 📊 Dados Atualmente Consumidos do AXL
```
✓ Phone Status (Registrados, Não-Registrados, Parcial)
✓ Trunk Status (SIP Trunks, PSTN)
✓ Media Resources (CFB, MTP, Transcoders)
✓ Service Status (Serviços CUCM)
✓ Cluster Nodes (Publisher, Subscribers)
✗ CPU/Memory/Disk (Requer Perfmon)
✗ Call Volume Real (Requer CDR/Perfmon)
✗ Voice Quality (Requer RTMT/Perfmon)
```

---

## 2️⃣ DADOS DISPONÍVEIS NO AXL 8.5

### 📞 TELEFONES E DISPOSITIVOS

**Operações Disponíveis:**
- `listPhone` - Lista todos os telefones
- `getPhone` - Detalhes de um telefone
- `listPhoneTemplate` - Templates de configuração

**Dados Extraíveis:**
```xml
<phone>
  <name>SEP001122334455</name>
  <model>CISCO7941G</model>
  <devicePoolName>Default_Pool</devicePoolName>
  <registerTTL>3600</registerTTL>
  <registrationStatus>REGISTERED</registrationStatus>
  <ipAddress>10.243.190.45</ipAddress>
  <ipv6Address/>
  <userDN>
    <firstName>João</firstName>
    <lastName>Silva</lastName>
    <userId>jsilva</userId>
  </userDN>
  <extensions>
    <pattern>2001</pattern>
    <pattern>2099</pattern>
  </extensions>
</phone>
```

**Para Dashboard:**
- Total de telefones por modelo (Pie chart)
- Distribuição por status (Registered/Unregistered/Partial)
- Telefones por departamento
- Últimos telefones configurados

---

### 👥 USUÁRIOS

**Operações Disponíveis:**
- `listEndUser` - Lista usuários
- `getEndUser` - Detalhes de usuário
- `listUser` - Usuários sistema

**Dados Extraíveis:**
```xml
<user>
  <userId>jsilva</userId>
  <firstName>João</firstName>
  <lastName>Silva</lastName>
  <department>TI</department>
  <manager>mgr@company.com</manager>
  <primaryExtension>2001</primaryExtension>
  <mobileNumber>11987654321</mobileNumber>
  <mailboxNumber>3000</mailboxNumber>
</user>
```

**Para Dashboard:**
- Usuários ativos por departamento
- Usuários com extensão móvel
- Usuários recém-criados
- Taxa de ativação de usuários

---

### 📡 TRONCOS SIP / PSTN

**Operações Disponíveis:**
- `listSipTrunk` - Troncos SIP
- `getSipTrunk` - Detalhes do tronco
- `listSipPeer` - Peers SIP (provedores)

**Dados Extraíveis:**
```xml
<sipTrunk>
  <name>PSTN_Primary</name>
  <description>Tronco PSTN Primário</description>
  <sipTrunkType>SIP_TRUNK_TYPE_CISCO_UNIFIED_GATEWAY</sipTrunkType>
  <registered>true</registered>
  <registrationStatus>REGISTERED</registrationStatus>
  <registrations>2</registrations>
  <destination>10.243.190.100</destination>
  <port>5060</port>
  <transportLayerProtocol>TCP</transportLayerProtocol>
</sipTrunk>
```

**Para Dashboard:**
- Taxa de conectividade de troncos
- Registrações por tronco
- Distribuição de chamadas por tronco
- Alertas de tronco inativo

---

### 🎤 RECURSOS DE MÍDIA

**Operações Disponíveis:**
- `listConferenceRoom` - Salas de conferência
- `listMRGList` - Grupos de recursos
- `listDevicePool` - Pools de dispositivos

**Dados Extraíveis:**
```xml
<conferenceRoom>
  <name>CFB-Publisher</name>
  <description>Conference Bridge Principal</description>
  <maxParticipants>64</maxParticipants>
  <inUse>12</inUse>
  <status>ACTIVE</status>
</conferenceRoom>
```

**Para Dashboard:**
- Utilização de CFB/MTP/Transcoders
- Capacidade vs. Uso
- Alertas de capacidade atingida
- Previsão de necessidade

---

### 🖥️ CLUSTER / SERVIDORES

**Operações Disponíveis:**
- `getCCMCluster` - Info do cluster
- `getRisData` - Real-time Info Server
- `getServiceStatus` - Status dos serviços

**Dados Extraíveis:**
```xml
<CCMCluster>
  <name>CiscoCM</name>
  <version>8.5.2.xxx</version>
  <nodes>
    <node>
      <name>Publisher</name>
      <ipAddress>10.243.190.10</ipAddress>
      <status>ACTIVE</status>
    </node>
    <node>
      <name>Subscriber1</name>
      <ipAddress>10.243.190.11</ipAddress>
      <status>ACTIVE</status>
    </node>
  </nodes>
</CCMCluster>
```

**Para Dashboard:**
- Saúde do cluster
- Nós ativos/inativos
- Versão do CUCM
- Status de sincronização

---

### 🔧 SERVIÇOS

**Operações Disponíveis:**
- `getServiceStatus` - Status de cada serviço
- `getRisData` - Dados RIS

**Serviços Monitoráveis:**
- Cisco CallManager
- Cisco TFTP Server
- Cisco Message Store
- Cisco Tomcat
- Cisco Licensing
- Cisco Unified Communications Manager 

**Para Dashboard:**
- Status de cada serviço (Online/Offline)
- Tempo de atividade
- Alertas se serviço cair

---

## 3️⃣ DADOS NÃO DISPONÍVEIS NO AXL (Requer Outras APIs)

### ⚠️ Performance em Tempo Real (Requer **Perfmon API**)
- **CPU por nó**: `GetValue("\\server\Processor(_Total)\% Processor Time")`
- **Memória**: `GetValue("\\server\Memory\Available MBytes")`
- **Disco**: `GetValue("\\server\PhysicalDisk(*)\% Disk Time")`
- **Volume de Chamadas**: `GetValue("Cisco CallManager\Calls in Progress")`
- **Latência de Rede**: Não disponível (requer RTMT)
- **MOS Score**: Não disponível (requer RTMT)

### 📞 CDR - Call Detail Records (Requer **CDR API**)
- Chamadas por origem/destino
- Duração de chamadas
- Taxa de sucesso/falha
- Padrões de chamadas

---

## 4️⃣ PLANO DE IMPLEMENTAÇÃO

### 📌 **FASE 1: OTIMIZAR COLLECTOR (Semana 1)**

**Objetivo**: Expandir métodos do AXLCollector para extrair mais dados

**Tarefas:**

1. **Expandir `get_phone_status()` para retornar:**
   ```python
   {
       'registered': 850,
       'unregistered': 45,
       'partial': 12,
       'by_model': {
           'CISCO7941G': 300,
           'CISCO7945G': 250,
           '8841': 300
       },
       'last_registered': [
           {'name': 'SEP001122334455', 'timestamp': '...'}
       ]
   }
   ```

2. **Expandir `get_trunk_status()` para retornar:**
   ```python
   {
       'trunks': [
           {
               'name': 'PSTN_Primary',
               'status': 'Active',
               'registrations': 2,
               'last_registration': '...',
               'call_count': 1250
           }
       ]
   }
   ```

3. **Implementar `get_user_statistics()`:**
   ```python
   {
       'total_users': 450,
       'by_department': {
           'TI': 50,
           'RH': 30,
           'Vendas': 100
       },
       'with_mobile': 120,
       'inactive': 15
   }
   ```

4. **Implementar `get_media_utilization()`:**
   ```python
   {
       'cfb': {'total': 48, 'in_use': 12, 'available': 36},
       'mtp': {'total': 32, 'in_use': 8, 'available': 24},
       'xcoder': {'total': 16, 'in_use': 4, 'available': 12}
   }
   ```

5. **Implementar `get_device_statistics()`:**
   ```python
   {
       'by_model': {
           'CISCO7941G': {'total': 300, 'registered': 295},
           'CISCO7945G': {'total': 250, 'registered': 248}
       },
       'by_pool': {
           'Default_Pool': {'total': 450, 'registered': 440}
       }
   }
   ```

---

### 📌 **FASE 2: INTEGRAR PERFMON (Semana 2-3)**

**Objetivo**: Obter dados de performance reais em vez de simulados

**Tarefas:**

1. Criar novo módulo `modules/perfmon_integration.py`
2. Implementar cliente Perfmon
3. Queries para:
   - CPU por nó
   - Memória por nó
   - Disco por nó
   - Volume de chamadas
   - Latência média

**Código Base:**
```python
# modules/perfmon_integration.py
from zeep import Client

class PerfmonCollector:
    def __init__(self, cucm_host, username, password):
        self.client = Client(f"https://{cucm_host}:8443/perfmon")
        
    def get_cpu_usage(self, node_name):
        # Query: "\\{node}\Processor(_Total)\% Processor Time"
        pass
    
    def get_memory_usage(self, node_name):
        # Query: "\\{node}\Memory\Available MBytes"
        pass
    
    def get_disk_usage(self, node_name):
        # Query: "\\{node}\PhysicalDisk(*)\% Disk Time"
        pass
```

---

### 📌 **FASE 3: ALERTAS AUTOMÁTICOS (Semana 3)**

**Objetivo**: Notificar quando métricas excedem limites

**Implementação:**
```python
# modules/alert_engine.py
class AlertEngine:
    def __init__(self):
        self.thresholds = {
            'cpu': {'warning': 70, 'critical': 85},
            'memory': {'warning': 75, 'critical': 90},
            'disk': {'warning': 80, 'critical': 95},
            'phones_unregistered': {'warning': 50, 'critical': 100},
            'trunk_inactive': {'warning': 1, 'critical': 2}
        }
    
    def check_alerts(self, metrics):
        # Gera alertas baseado em limites
        pass
```

---

### 📌 **FASE 4: HISTÓRICO E TRENDING (Semana 4)**

**Objetivo**: Armazenar dados históricos e exibir tendências

**Implementação:**
```sql
CREATE TABLE IF NOT EXISTS metrics_history (
    id INTEGER PRIMARY KEY,
    metric_name TEXT,
    metric_value REAL,
    timestamp DATETIME,
    node_name TEXT
);

-- Exemplo: CPU do Publisher nos últimos 7 dias
SELECT timestamp, metric_value 
FROM metrics_history 
WHERE metric_name = 'cpu' AND node_name = 'Publisher'
AND timestamp > datetime('now', '-7 days')
ORDER BY timestamp;
```

---

## 5️⃣ EXEMPLOS DE IMPLEMENTAÇÃO

### Exemplo 1: Expandir Métodos do Collector

```python
# modules/axl_collector.py - ADICIONAR ESTES MÉTODOS

def get_phone_statistics(self):
    """Retorna estatísticas detalhadas de telefones"""
    try:
        # Conectar ao AXL (modo online) ou ler XML (modo manual)
        phones = self._query_axl('listPhone', {
            'searchCriteria': '<name>%</name>',
            'returnedTags': '''
                <name/>
                <model/>
                <status/>
                <ipAddress/>
                <userDN>
                    <firstName/>
                    <lastName/>
                </userDN>
            '''
        })
        
        # Processar dados
        stats = {
            'total': len(phones),
            'by_model': {},
            'by_status': {'REGISTERED': 0, 'UNREGISTERED': 0, 'PARTIAL': 0},
            'by_user': {}
        }
        
        for phone in phones:
            # Agregar por modelo
            model = phone.get('model', 'Unknown')
            stats['by_model'][model] = stats['by_model'].get(model, 0) + 1
            
            # Agregar por status
            status = phone.get('status', 'UNREGISTERED')
            stats['by_status'][status] = stats['by_status'].get(status, 0) + 1
            
            # Agregar por usuário
            if phone.get('userDN'):
                user = f"{phone['userDN']['firstName']} {phone['userDN']['lastName']}"
                stats['by_user'][user] = stats['by_user'].get(user, 0) + 1
        
        return stats
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas de telefones: {e}")
        return None

def get_trunk_statistics(self):
    """Retorna estatísticas detalhadas de troncos"""
    try:
        trunks = self._query_axl('listSipTrunk', {
            'searchCriteria': '<name>%</name>',
            'returnedTags': '''
                <name/>
                <description/>
                <registered/>
                <registrations/>
                <destination/>
                <port/>
            '''
        })
        
        stats = {
            'total': len(trunks),
            'active': sum(1 for t in trunks if t.get('registered') == 'true'),
            'inactive': sum(1 for t in trunks if t.get('registered') != 'true'),
            'trunks': []
        }
        
        for trunk in trunks:
            stats['trunks'].append({
                'name': trunk.get('name'),
                'status': 'Active' if trunk.get('registered') == 'true' else 'Inactive',
                'registrations': trunk.get('registrations', 0),
                'destination': trunk.get('destination'),
                'port': trunk.get('port')
            })
        
        return stats
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas de troncos: {e}")
        return None

def get_user_department_distribution(self):
    """Retorna distribuição de usuários por departamento"""
    try:
        users = self._query_axl('listEndUser', {
            'searchCriteria': '<name>%</name>',
            'returnedTags': '<userId/><department/><primaryExtension/>'
        })
        
        distribution = {}
        for user in users:
            dept = user.get('department', 'Unknown')
            distribution[dept] = distribution.get(dept, 0) + 1
        
        return {
            'total_users': len(users),
            'by_department': distribution
        }
        
    except Exception as e:
        logger.error(f"Erro ao obter distribuição por departamento: {e}")
        return None
```

### Exemplo 2: Novo Endpoint no Dashboard

```python
# app.py - ADICIONAR NOVO ENDPOINT

@app.route('/api/extended-metrics')
@admin_required
def get_extended_metrics():
    """API com métricas estendidas do AXL"""
    try:
        collector = AXLCollector()
        
        data = {
            'phone_statistics': collector.get_phone_statistics(),
            'trunk_statistics': collector.get_trunk_statistics(),
            'user_distribution': collector.get_user_department_distribution(),
            'cluster_health': collector.get_cluster_nodes(),
            'media_resources': collector.get_media_resources(),
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify({'sucesso': True, 'dados': data})
    except Exception as e:
        return jsonify({'sucesso': False, 'erro': str(e)}), 500
```

### Exemplo 3: Novo Gráfico no Dashboard

```javascript
// static/js/dashboard.js - ADICIONAR NOVO GRÁFICO

async function renderPhonesByModel() {
    try {
        const response = await fetch('/api/extended-metrics');
        const data = await response.json();
        
        if (!data.sucesso) throw new Error(data.erro);
        
        const phoneStats = data.dados.phone_statistics;
        const models = Object.keys(phoneStats.by_model);
        const counts = Object.values(phoneStats.by_model);
        
        new Chart(document.getElementById('phonesByModelChart'), {
            type: 'bar',
            data: {
                labels: models,
                datasets: [{
                    label: 'Telefones por Modelo',
                    data: counts,
                    backgroundColor: '#0099ff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    } catch (err) {
        console.error('Erro ao renderizar gráfico:', err);
    }
}
```

---

## 6️⃣ ESTRUTURA DE ARQUIVOS PROPOSTA

```
Checklist Profissional/
├── modules/
│   ├── axl_collector.py (EXPANDIR com novos métodos)
│   ├── axl_integration.py (Classe base - manter)
│   ├── perfmon_integration.py (NOVO - para dados de performance)
│   ├── alert_engine.py (NOVO - para alertas)
│   └── metrics_storage.py (NOVO - para histórico)
├── static/
│   ├── js/
│   │   ├── dashboard-extended-metrics.js (NOVO - gráficos adicionais)
│   │   └── dashboard.js (Adicionar chamadas dos novos endpoints)
│   └── css/
│       └── dashboard-extended.css (NOVO - estilos dos novos gráficos)
├── templates/
│   └── dashboard-extended.html (NOVO - nova aba de métricas estendidas)
└── axlsqltoolkit/
    ├── schema/current/ (Atualizado para 8.5 ✓)
    └── mock_data/ (NOVO - arquivos XML para testes offline)
```

---

## 7️⃣ MOCK DATA PARA TESTES OFFLINE

Criar arquivo `axlsqltoolkit/mock_data/phone_list.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<phoneListResponse>
    <phone>
        <name>SEP001122334455</name>
        <model>CISCO7941G</model>
        <devicePoolName>Default_Pool</devicePoolName>
        <status>REGISTERED</status>
        <ipAddress>10.243.190.45</ipAddress>
        <userDN>
            <firstName>João</firstName>
            <lastName>Silva</lastName>
            <userId>jsilva</userId>
        </userDN>
    </phone>
    <phone>
        <name>SEP001122334456</name>
        <model>CISCO7945G</model>
        <devicePoolName>Default_Pool</devicePoolName>
        <status>REGISTERED</status>
        <ipAddress>10.243.190.46</ipAddress>
        <userDN>
            <firstName>Maria</firstName>
            <lastName>Santos</lastName>
            <userId>msantos</userId>
        </userDN>
    </phone>
    <!-- ... mais telefones ... -->
</phoneListResponse>
```

---

## 8️⃣ ROADMAP E TIMELINE

| Fase | Tarefa | Timeline | Prioridade |
|------|--------|----------|-----------|
| 1 | Expandir AXLCollector | Semana 1 | 🔴 Alta |
| 1 | Novos endpoints API | Semana 1 | 🔴 Alta |
| 1 | Novos gráficos (Modelos, Depts) | Semana 1 | 🔴 Alta |
| 2 | Integrar Perfmon | Semana 2-3 | 🟡 Média |
| 3 | Alertas Automáticos | Semana 3 | 🟡 Média |
| 4 | Histórico e Trending | Semana 4 | 🟢 Baixa |
| 5 | Relatórios PDF/CSV | Semana 5 | 🟢 Baixa |

---

## 9️⃣ PRÓXIMOS PASSOS

### ✅ Já Feito:
- ✓ Análise completa do AXL 8.5
- ✓ Identificação de dados disponíveis
- ✓ Plano de implementação

### 🔄 Próximo:
- Criar métodos expandidos no AXLCollector
- Implementar novos endpoints API
- Criar gráficos adicionais no dashboard

### 📌 Ação Recomendada:
Quer que eu implemente a **Fase 1** agora? Vou:
1. Expandir `axl_collector.py` com novos métodos
2. Criar novo endpoint `/api/extended-metrics`
3. Adicionar 5 novos gráficos ao dashboard

---

## 🔟 DÚVIDAS E SUGESTÕES

- **Perfmon está disponível no seu CUCM?** (Necessário para dados reais de CPU/Memória)
- **Prefere dados em tempo real ou histórico?**
- **Qual métrica é mais importante para seu caso de uso?**
- **Quer alertas automáticos?**

---

**Documento preparado em:** 01/07/2026  
**Versão:** 1.0  
**Autor:** GitHub Copilot  
**Status:** ✅ Pronto para Implementação
