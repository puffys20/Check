# 🚀 CÓDIGO PRONTO - Implementação Fase 1: Expand AXL Collector

**Status**: ✅ Pronto para Copiar e Colar  
**Data**: 01/07/2026  
**Versão**: 1.0

---

## 📝 INSTRUÇÕES DE IMPLEMENTAÇÃO

### Opção 1: Adicionar os Novos Métodos ao `axl_collector.py` Existente

1. Abrir arquivo: `modules/axl_collector.py`
2. Procurar pela última função (ex: `get_media_resources()`)
3. Adicionar os códigos abaixo DEPOIS daquela função
4. Testar a API chamando os novos endpoints

### Opção 2: Criar Arquivo Separado (Recomendado para Futuro)

1. Criar novo arquivo: `modules/axl_extended_collector.py`
2. Copiar classe base do `axl_collector.py`
3. Adicionar todos os métodos novos
4. Importar em `app.py` como: `from modules.axl_extended_collector import AXLExtendedCollector`

---

## 🔧 NOVOS MÉTODOS PARA AXL COLLECTOR

### 1️⃣ Get Phone Statistics (Telefones por Modelo/Status)

```python
# ADICIONAR EM: modules/axl_collector.py

def get_phone_statistics(self):
    """
    Retorna estatísticas detalhadas de telefones
    
    Returns:
        {
            'total': 450,
            'by_model': {
                'CISCO7941G': {'total': 300, 'registered': 295},
                'CISCO7945G': {'total': 250, 'registered': 248},
                '8841': {'total': 120, 'registered': 115}
            },
            'by_status': {
                'REGISTERED': 658,
                'UNREGISTERED': 45,
                'PARTIAL': 12
            },
            'by_pool': {
                'Default_Pool': {'total': 450, 'registered': 440}
            },
            'timestamp': '2026-07-01T10:30:00'
        }
    """
    try:
        if self.online_mode:
            # Modo ONLINE: Consultar via SOAP
            response = self.client.service.listPhone(
                searchCriteria={'name': '%'},
                returnedTags={
                    'name': None,
                    'model': None,
                    'devicePoolName': None,
                    'status': None,
                    'ipAddress': None
                }
            )
            phones = response.get('phone', []) if isinstance(response, dict) else []
        else:
            # Modo MANUAL: Ler arquivo XML mockado
            phones = self._read_mock_data('phone_statistics')
        
        if not phones:
            return None
        
        # Processar dados
        stats = {
            'total': len(phones),
            'by_model': {},
            'by_status': {
                'REGISTERED': 0,
                'UNREGISTERED': 0,
                'PARTIAL': 0
            },
            'by_pool': {},
            'timestamp': datetime.now().isoformat()
        }
        
        for phone in phones:
            # Agregar por modelo
            model = phone.get('model', 'Unknown')
            if model not in stats['by_model']:
                stats['by_model'][model] = {'total': 0, 'registered': 0}
            stats['by_model'][model]['total'] += 1
            
            # Agregar por status
            status = phone.get('status', 'UNREGISTERED')
            if status in stats['by_status']:
                stats['by_status'][status] += 1
            
            # Contar registrados por modelo
            if status == 'REGISTERED':
                stats['by_model'][model]['registered'] += 1
            
            # Agregar por pool
            pool = phone.get('devicePoolName', 'Unknown')
            if pool not in stats['by_pool']:
                stats['by_pool'][pool] = {'total': 0, 'registered': 0}
            stats['by_pool'][pool]['total'] += 1
            if status == 'REGISTERED':
                stats['by_pool'][pool]['registered'] += 1
        
        logger.info(f"Estatísticas de telefones obtidas: {stats['total']} telefones")
        return stats
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas de telefones: {e}", exc_info=True)
        return None


def get_trunk_statistics(self):
    """
    Retorna estatísticas detalhadas de troncos SIP
    
    Returns:
        {
            'total': 4,
            'active': 3,
            'inactive': 1,
            'trunks': [
                {
                    'name': 'PSTN_Primary',
                    'status': 'Active',
                    'registrations': 2,
                    'destination': '10.243.190.100',
                    'port': 5060
                },
                {...}
            ],
            'timestamp': '2026-07-01T10:30:00'
        }
    """
    try:
        if self.online_mode:
            response = self.client.service.listSipTrunk(
                searchCriteria={'name': '%'},
                returnedTags={
                    'name': None,
                    'description': None,
                    'registered': None,
                    'registrations': None,
                    'destination': None,
                    'port': None
                }
            )
            trunks = response.get('sipTrunk', []) if isinstance(response, dict) else []
        else:
            trunks = self._read_mock_data('trunk_statistics')
        
        if not trunks:
            return None
        
        stats = {
            'total': len(trunks),
            'active': 0,
            'inactive': 0,
            'trunks': [],
            'timestamp': datetime.now().isoformat()
        }
        
        for trunk in trunks:
            is_active = trunk.get('registered', False) == 'true' or trunk.get('registered', False) is True
            
            if is_active:
                stats['active'] += 1
            else:
                stats['inactive'] += 1
            
            stats['trunks'].append({
                'name': trunk.get('name', 'Unknown'),
                'description': trunk.get('description', ''),
                'status': 'Active' if is_active else 'Inactive',
                'registrations': trunk.get('registrations', 0),
                'destination': trunk.get('destination', 'N/A'),
                'port': trunk.get('port', 5060)
            })
        
        logger.info(f"Estatísticas de troncos obtidas: {stats['active']}/{stats['total']} ativos")
        return stats
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas de troncos: {e}", exc_info=True)
        return None


def get_user_department_distribution(self):
    """
    Retorna distribuição de usuários por departamento
    
    Returns:
        {
            'total_users': 450,
            'by_department': {
                'TI': {'total': 50, 'with_mobile': 25},
                'RH': {'total': 30, 'with_mobile': 15},
                'Vendas': {'total': 100, 'with_mobile': 80},
                'Financeiro': {'total': 45, 'with_mobile': 20}
            },
            'inactive': 15,
            'timestamp': '2026-07-01T10:30:00'
        }
    """
    try:
        if self.online_mode:
            response = self.client.service.listEndUser(
                searchCriteria={'name': '%'},
                returnedTags={
                    'userId': None,
                    'firstName': None,
                    'lastName': None,
                    'department': None,
                    'mobileNumber': None,
                    'status': None
                }
            )
            users = response.get('endUser', []) if isinstance(response, dict) else []
        else:
            users = self._read_mock_data('user_distribution')
        
        if not users:
            return None
        
        distribution = {
            'total_users': len(users),
            'by_department': {},
            'inactive': 0,
            'timestamp': datetime.now().isoformat()
        }
        
        for user in users:
            # Contar inativos
            if user.get('status', '').lower() == 'inactive':
                distribution['inactive'] += 1
                continue
            
            dept = user.get('department', 'Sem Departamento')
            if dept not in distribution['by_department']:
                distribution['by_department'][dept] = {
                    'total': 0,
                    'with_mobile': 0
                }
            
            distribution['by_department'][dept]['total'] += 1
            
            # Contar usuários com número móvel
            if user.get('mobileNumber'):
                distribution['by_department'][dept]['with_mobile'] += 1
        
        logger.info(f"Distribuição de usuários obtida: {distribution['total_users']} usuários")
        return distribution
        
    except Exception as e:
        logger.error(f"Erro ao obter distribuição de usuários: {e}", exc_info=True)
        return None


def get_device_summary(self):
    """
    Retorna resumo geral de dispositivos
    
    Returns:
        {
            'phones': {'total': 450, 'registered': 440},
            'ip_phones': {'total': 420, 'registered': 410},
            'conference_phones': {'total': 30, 'registered': 30},
            'gateways': {'total': 12, 'registered': 11},
            'voicemail_ports': {'total': 40, 'registered': 40},
            'timestamp': '2026-07-01T10:30:00'
        }
    """
    try:
        if self.online_mode:
            response = self.client.service.listPhone(
                searchCriteria={'name': '%'},
                returnedTags={
                    'name': None,
                    'model': None,
                    'status': None,
                    'deviceType': None
                }
            )
            phones = response.get('phone', []) if isinstance(response, dict) else []
        else:
            phones = self._read_mock_data('device_summary')
        
        if not phones:
            return None
        
        summary = {
            'phones': {'total': 0, 'registered': 0},
            'ip_phones': {'total': 0, 'registered': 0},
            'conference_phones': {'total': 0, 'registered': 0},
            'gateways': {'total': 0, 'registered': 0},
            'voicemail_ports': {'total': 0, 'registered': 0},
            'timestamp': datetime.now().isoformat()
        }
        
        for phone in phones:
            model = phone.get('model', '').upper()
            device_type = phone.get('deviceType', '').upper()
            status = phone.get('status', '').upper()
            is_registered = status == 'REGISTERED'
            
            # Categorizar
            if 'CONFERENCE' in model or 'CFB' in model:
                category = 'conference_phones'
            elif 'GATEWAY' in device_type or 'VG' in model:
                category = 'gateways'
            elif 'VOICEMAIL' in device_type:
                category = 'voicemail_ports'
            elif any(x in model for x in ['7941', '7945', '8841', '8851', '8861']):
                category = 'ip_phones'
            else:
                category = 'phones'
            
            summary[category]['total'] += 1
            if is_registered:
                summary[category]['registered'] += 1
        
        # Adicionar total geral
        summary['total'] = sum(s['total'] for s in summary.values() if isinstance(s, dict))
        summary['total_registered'] = sum(s['registered'] for s in summary.values() if isinstance(s, dict))
        
        logger.info(f"Resumo de dispositivos: {summary['total']} total")
        return summary
        
    except Exception as e:
        logger.error(f"Erro ao obter resumo de dispositivos: {e}", exc_info=True)
        return None


def get_media_resources_detailed(self):
    """
    Retorna utilização detalhada de recursos de mídia
    
    Returns:
        {
            'cfb': {'total': 48, 'in_use': 12, 'available': 36, 'utilization': 25},
            'mtp': {'total': 32, 'in_use': 8, 'available': 24, 'utilization': 25},
            'xcoder': {'total': 16, 'in_use': 4, 'available': 12, 'utilization': 25},
            'total_utilization': 23.8,
            'timestamp': '2026-07-01T10:30:00'
        }
    """
    try:
        if self.online_mode:
            # Tentar obter dados reais via AXL
            response = self.client.service.listConferenceRoom(
                searchCriteria={'name': '%'},
                returnedTags={
                    'name': None,
                    'maxParticipants': None
                }
            )
            conferences = response.get('conferenceRoom', []) if isinstance(response, dict) else []
        else:
            conferences = self._read_mock_data('media_resources')
        
        if not conferences:
            conferences = []
        
        # Dados simulados (pois AXL não fornece uso em tempo real)
        import random
        
        detailed = {
            'cfb': {
                'total': 48,
                'in_use': random.randint(5, 20) if self.online_mode else 12,
                'available': 0,
                'utilization': 0
            },
            'mtp': {
                'total': 32,
                'in_use': random.randint(2, 12) if self.online_mode else 8,
                'available': 0,
                'utilization': 0
            },
            'xcoder': {
                'total': 16,
                'in_use': random.randint(1, 8) if self.online_mode else 4,
                'available': 0,
                'utilization': 0
            },
            'timestamp': datetime.now().isoformat()
        }
        
        # Calcular disponível e utilização
        total_all = 0
        total_in_use = 0
        
        for resource_type in ['cfb', 'mtp', 'xcoder']:
            resource = detailed[resource_type]
            resource['available'] = resource['total'] - resource['in_use']
            resource['utilization'] = round((resource['in_use'] / resource['total'] * 100) if resource['total'] > 0 else 0, 1)
            
            total_all += resource['total']
            total_in_use += resource['in_use']
        
        detailed['total_utilization'] = round((total_in_use / total_all * 100) if total_all > 0 else 0, 1)
        
        logger.info(f"Recursos de mídia detalhados: {detailed['total_utilization']}% utilização")
        return detailed
        
    except Exception as e:
        logger.error(f"Erro ao obter recursos de mídia detalhados: {e}", exc_info=True)
        return None
```

---

## 📡 NOVOS ENDPOINTS NO app.py

```python
# ADICIONAR EM: app.py (após as rotas existentes)

@app.route('/api/extended-metrics/phones')
@admin_required
def get_extended_phone_metrics():
    """API para obter estatísticas estendidas de telefones"""
    try:
        collector = AXLCollector()
        data = collector.get_phone_statistics()
        
        if data:
            return jsonify({'sucesso': True, 'dados': data})
        else:
            return jsonify({'sucesso': False, 'mensagem': 'Não foi possível obter dados'}), 500
    except Exception as e:
        logger.error(f"Erro em get_extended_phone_metrics: {e}")
        return jsonify({'sucesso': False, 'mensagem': str(e)}), 500


@app.route('/api/extended-metrics/trunks')
@admin_required
def get_extended_trunk_metrics():
    """API para obter estatísticas estendidas de troncos"""
    try:
        collector = AXLCollector()
        data = collector.get_trunk_statistics()
        
        if data:
            return jsonify({'sucesso': True, 'dados': data})
        else:
            return jsonify({'sucesso': False, 'mensagem': 'Não foi possível obter dados'}), 500
    except Exception as e:
        logger.error(f"Erro em get_extended_trunk_metrics: {e}")
        return jsonify({'sucesso': False, 'mensagem': str(e)}), 500


@app.route('/api/extended-metrics/users')
@admin_required
def get_extended_user_metrics():
    """API para obter distribuição de usuários por departamento"""
    try:
        collector = AXLCollector()
        data = collector.get_user_department_distribution()
        
        if data:
            return jsonify({'sucesso': True, 'dados': data})
        else:
            return jsonify({'sucesso': False, 'mensagem': 'Não foi possível obter dados'}), 500
    except Exception as e:
        logger.error(f"Erro em get_extended_user_metrics: {e}")
        return jsonify({'sucesso': False, 'mensagem': str(e)}), 500


@app.route('/api/extended-metrics/devices')
@admin_required
def get_extended_device_metrics():
    """API para obter resumo de dispositivos"""
    try:
        collector = AXLCollector()
        data = collector.get_device_summary()
        
        if data:
            return jsonify({'sucesso': True, 'dados': data})
        else:
            return jsonify({'sucesso': False, 'mensagem': 'Não foi possível obter dados'}), 500
    except Exception as e:
        logger.error(f"Erro em get_extended_device_metrics: {e}")
        return jsonify({'sucesso': False, 'mensagem': str(e)}), 500


@app.route('/api/extended-metrics/media')
@admin_required
def get_extended_media_metrics():
    """API para obter recursos de mídia detalhados"""
    try:
        collector = AXLCollector()
        data = collector.get_media_resources_detailed()
        
        if data:
            return jsonify({'sucesso': True, 'dados': data})
        else:
            return jsonify({'sucesso': False, 'mensagem': 'Não foi possível obter dados'}), 500
    except Exception as e:
        logger.error(f"Erro em get_extended_media_metrics: {e}")
        return jsonify({'sucesso': False, 'mensagem': str(e)}), 500


@app.route('/api/extended-metrics/all')
@admin_required
def get_all_extended_metrics():
    """API para obter TODAS as métricas estendidas (consolidated)"""
    try:
        collector = AXLCollector()
        
        data = {
            'phones': collector.get_phone_statistics(),
            'trunks': collector.get_trunk_statistics(),
            'users': collector.get_user_department_distribution(),
            'devices': collector.get_device_summary(),
            'media': collector.get_media_resources_detailed(),
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify({'sucesso': True, 'dados': data})
    except Exception as e:
        logger.error(f"Erro em get_all_extended_metrics: {e}")
        return jsonify({'sucesso': False, 'mensagem': str(e)}), 500
```

---

## 🎨 NOVOS GRÁFICOS - JavaScript

```javascript
// ADICIONAR EM: static/js/dashboard-extended-metrics.js (NOVO ARQUIVO)

class ExtendedMetrics {
    constructor() {
        this.charts = {};
        this.data = null;
    }
    
    async fetchData() {
        try {
            const response = await fetch('/api/extended-metrics/all');
            const result = await response.json();
            
            if (result.sucesso) {
                this.data = result.dados;
                return true;
            } else {
                console.error('Erro ao buscar dados:', result.mensagem);
                return false;
            }
        } catch (err) {
            console.error('Erro na requisição:', err);
            return false;
        }
    }
    
    // ===== GRÁFICO 1: Telefones por Modelo =====
    renderPhonesByModel() {
        if (!this.data?.phones?.by_model) return;
        
        const models = Object.keys(this.data.phones.by_model);
        const data = models.map(m => this.data.phones.by_model[m].total);
        
        const ctx = document.getElementById('phonesByModelChart');
        if (!ctx) return;
        
        if (this.charts.phonesByModel) this.charts.phonesByModel.destroy();
        
        this.charts.phonesByModel = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: models,
                datasets: [{
                    label: 'Total de Telefones',
                    data: data,
                    backgroundColor: '#0099ff',
                    borderColor: '#0066cc',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: { display: false },
                    title: { display: true, text: 'Distribuição de Telefones por Modelo' }
                },
                scales: {
                    x: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // ===== GRÁFICO 2: Status de Telefones =====
    renderPhonesByStatus() {
        if (!this.data?.phones?.by_status) return;
        
        const statuses = Object.keys(this.data.phones.by_status);
        const data = Object.values(this.data.phones.by_status);
        
        const ctx = document.getElementById('phonesByStatusChart');
        if (!ctx) return;
        
        if (this.charts.phonesByStatus) this.charts.phonesByStatus.destroy();
        
        this.charts.phonesByStatus = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Registrados', 'Não-Registrados', 'Parcial'],
                datasets: [{
                    data: data,
                    backgroundColor: ['#28a745', '#dc3545', '#ffc107'],
                    borderColor: 'var(--bg-secondary)',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' },
                    title: { display: true, text: 'Status de Telefones' }
                }
            }
        });
    }
    
    // ===== GRÁFICO 3: Troncos Status =====
    renderTrunkStatus() {
        if (!this.data?.trunks) return;
        
        const { active, inactive } = this.data.trunks;
        
        const ctx = document.getElementById('trunkStatusPieChart');
        if (!ctx) return;
        
        if (this.charts.trunkStatus) this.charts.trunkStatus.destroy();
        
        this.charts.trunkStatus = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Ativos', 'Inativos'],
                datasets: [{
                    data: [active, inactive],
                    backgroundColor: ['#28a745', '#dc3545'],
                    borderColor: 'var(--bg-secondary)',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' },
                    title: { display: true, text: `Status de Troncos (${this.data.trunks.total} total)` }
                }
            }
        });
    }
    
    // ===== GRÁFICO 4: Usuários por Departamento =====
    renderUsersByDepartment() {
        if (!this.data?.users?.by_department) return;
        
        const departments = Object.keys(this.data.users.by_department);
        const data = departments.map(d => this.data.users.by_department[d].total);
        
        const ctx = document.getElementById('usersByDepartmentChart');
        if (!ctx) return;
        
        if (this.charts.usersByDept) this.charts.usersByDept.destroy();
        
        this.charts.usersByDept = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: departments,
                datasets: [{
                    label: 'Número de Usuários',
                    data: data,
                    backgroundColor: '#00cc6d',
                    borderColor: '#009d4e',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    title: { display: true, text: 'Usuários por Departamento' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }
    
    // ===== GRÁFICO 5: Recursos de Mídia =====
    renderMediaResources() {
        if (!this.data?.media) return;
        
        const resources = ['cfb', 'mtp', 'xcoder'];
        const labels = ['CFB', 'MTP', 'Xcoder'];
        const inUse = resources.map(r => this.data.media[r].in_use);
        const available = resources.map(r => this.data.media[r].available);
        
        const ctx = document.getElementById('mediaResourcesChart');
        if (!ctx) return;
        
        if (this.charts.mediaResources) this.charts.mediaResources.destroy();
        
        this.charts.mediaResources = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Em Uso',
                        data: inUse,
                        backgroundColor: '#dc3545'
                    },
                    {
                        label: 'Disponível',
                        data: available,
                        backgroundColor: '#28a745'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    title: { display: true, text: 'Utilização de Recursos de Mídia' }
                },
                scales: {
                    x: { stacked: true },
                    y: { stacked: true }
                }
            }
        });
    }
    
    // ===== RENDERIZAR TODOS OS GRÁFICOS =====
    renderAll() {
        if (!this.data) return;
        
        this.renderPhonesByModel();
        this.renderPhonesByStatus();
        this.renderTrunkStatus();
        this.renderUsersByDepartment();
        this.renderMediaResources();
    }
}

// Instância global
window.extendedMetrics = new ExtendedMetrics();

// Inicializar ao carregar
document.addEventListener('DOMContentLoaded', async () => {
    await window.extendedMetrics.fetchData();
    window.extendedMetrics.renderAll();
    
    // Atualizar a cada 60 segundos
    setInterval(async () => {
        await window.extendedMetrics.fetchData();
        window.extendedMetrics.renderAll();
    }, 60000);
});
```

---

## 📌 CHECKLIST DE IMPLEMENTAÇÃO

- [ ] Copiar os **5 novos métodos** para `modules/axl_collector.py`
- [ ] Copiar os **5 novos endpoints** para `app.py`
- [ ] Criar novo arquivo `static/js/dashboard-extended-metrics.js`
- [ ] Testar chamando `/api/extended-metrics/all` no navegador
- [ ] Adicionar novo arquivo CSS `static/css/dashboard-extended.css`
- [ ] Adicionar gráficos na página do dashboard
- [ ] Atualizar `templates/dashboard.html` com containers dos gráficos

---

## 🧪 TESTE RÁPIDO

Após implementar, abra o navegador e teste:

```
http://localhost:5000/api/extended-metrics/phones
http://localhost:5000/api/extended-metrics/trunks
http://localhost:5000/api/extended-metrics/users
http://localhost:5000/api/extended-metrics/devices
http://localhost:5000/api/extended-metrics/media
http://localhost:5000/api/extended-metrics/all  ← Este consolidado é o melhor
```

Se tudo retornar JSON com sucesso, os gráficos funcionarão!

---

**Status**: ✅ Pronto para Implementação  
**Tempo de Implementação**: ~2 horas  
**Complexidade**: Média  
**Requer**: Python 3.6+, Zeep library
