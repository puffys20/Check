# 🚀 Guia de Implementação - Integração AXL com Dashboard

## 📋 Índice
1. [Pré-requisitos](#pré-requisitos)
2. [Instalação](#instalação)
3. [Configuração](#configuração)
4. [Integração ao Dashboard](#integração-ao-dashboard)
5. [Testes](#testes)
6. [Troubleshooting](#troubleshooting)

---

## ✅ Pré-requisitos

### Verificações Necessárias
- [ ] Cisco CallManager acessível via rede
- [ ] Credenciais de admin do CallManager
- [ ] Python 3.8+
- [ ] pip atualizado

### Verificar Acesso ao CallManager
```bash
# Testar conectividade
ping 192.168.1.100  # Substitua pelo IP do seu CallManager

# Testar porta HTTPS
curl -k https://192.168.1.100:8443/axl/  # Deve retortar response SOAP
```

---

## 📦 Instalação

### 1. Instalar Dependências
```bash
# Instalar zeep (cliente SOAP) e requests
pip install zeep requests

# Ou adicionar ao requirements.txt:
zeep>=4.0.0
requests>=2.28.0
```

### 2. Copiar Arquivo de Integração
```bash
# O arquivo deve estar em:
modules/axl_integration.py
```

### 3. Verificar Arquivos WSDL
```bash
# Os arquivos já estão em:
ls axlsqltoolkit/
# AXLAPI.wsdl
# AXLEnums.xsd
# AXLSoap.xsd
```

---

## ⚙️ Configuração

### 1. Configurar Variáveis de Ambiente

Editar `.env`:
```env
# Cisco CallManager
CALLMANAGER_HOST=192.168.1.100      # IP do CallManager
CALLMANAGER_USER=admin               # Usuário admin
CALLMANAGER_PASS=sua_senha_aqui      # Senha
CALLMANAGER_PORT=8443                # Porta padrão
# Caminho local para a CA que assina o certificado HTTPS do CUCM
CUCM_CA_BUNDLE=C:\certs\cucm-ca.pem
# Prefira um hostname presente no certificado em vez de um IP.
```

### 2. Testar Conexão
```python
# Criar arquivo test_axl_connection.py

from modules.axl_integration import AXLAPIClient
import os

host = os.getenv('CALLMANAGER_HOST')
user = os.getenv('CALLMANAGER_USER')
passwd = os.getenv('CALLMANAGER_PASS')

client = AXLAPIClient(host, user, passwd)

# Testar conexão
devices = client.get_devices_stats()
print(f"Dispositivos: {devices}")

users = client.get_users_stats()
print(f"Usuários: {users}")
```

Executar:
```bash
python test_axl_connection.py
```

---

## 🎯 Integração ao Dashboard

### Opção 1: Integração Direta (Recomendado)

Editar `app.py`:
```python
from modules.axl_integration import AXLDashboardHelper

# Instanciar helper
axl_helper = AXLDashboardHelper()

# Adicionar rota
@app.route('/api/dashboard/axl-stats', methods=['GET'])
def get_axl_stats():
    result = axl_helper.get_dashboard_data()
    return jsonify(result), 200 if result['sucesso'] else 500
```

### Opção 2: Usar Blueprint

Criar arquivo `routes/axl_routes.py`:
```python
# Copiar conteúdo de EXEMPLO_ROUTES_AXL.py
```

Registrar em `app.py`:
```python
from routes.axl_routes import axl_bp
app.register_blueprint(axl_bp)
```

### 3. Atualizar JavaScript do Dashboard

Editar `static/js/dashboard.js`:
```javascript
// Adicionar função para carregar dados AXL
async function loadAXLData() {
    try {
        const response = await fetch('/api/dashboard/axl-stats');
        const result = await response.json();
        
        if (result.sucesso) {
            const { dados } = result;
            
            // Atualizar gráfico de dispositivos
            updateDevicesChart(dados.devices);
            
            // Atualizar gráfico de usuários
            updateUsersChart(dados.users);
            
            // Atualizar gráfico de troncos SIP
            updateSipTrunksChart(dados.sip_trunks);
            
            // Atualizar gráfico de conferências
            updateConferencesChart(dados.conferences);
            
            // Atualizar status do cluster
            updateClusterStatus(dados.cluster);
        }
    } catch (error) {
        console.error('Erro ao carregar dados AXL:', error);
    }
}

// Funções para atualizar gráficos
function updateDevicesChart(deviceData) {
    if (!deviceData) return;
    
    const ctx = document.getElementById('devicesChart');
    if (ctx) {
        // Criar ou atualizar gráfico com Chart.js
        // ou qualquer biblioteca que está usando
    }
}

// Chamar ao iniciar página
document.addEventListener('DOMContentLoaded', function() {
    loadAXLData();
    
    // Atualizar a cada 5 minutos
    setInterval(loadAXLData, 5 * 60 * 1000);
});
```

---

## 🧪 Testes

### 1. Testar Endpoints
```bash
# Teste 1: Status da conexão
curl http://localhost:5000/api/axl/status

# Teste 2: Dados gerais
curl http://localhost:5000/api/axl/dashboard-stats

# Teste 3: Dispositivos específicos
curl http://localhost:5000/api/axl/devices

# Teste 4: Usuários
curl http://localhost:5000/api/axl/users

# Teste 5: Troncos SIP
curl http://localhost:5000/api/axl/sip-trunks

# Teste 6: Conferências
curl http://localhost:5000/api/axl/conferences

# Teste 7: Status do Cluster
curl http://localhost:5000/api/axl/cluster
```

### 2. Verificar Logs
```bash
# Ver logs da aplicação
tail -f app.log

# Buscar por erros AXL
grep -i "axl\|callmanager" app.log
```

### 3. Teste de Carga
```python
# test_axl_performance.py
import time
from modules.axl_integration import AXLAPIClient
import os

client = AXLAPIClient(
    os.getenv('CALLMANAGER_HOST'),
    os.getenv('CALLMANAGER_USER'),
    os.getenv('CALLMANAGER_PASS')
)

# Testar tempo de resposta
start = time.time()
client.get_all_stats()
elapsed = time.time() - start
print(f"Tempo total: {elapsed:.2f}s")
```

---

## 🐛 Troubleshooting

### Problema 1: "Connection refused"
```
Erro: ConnectionError: Failed to establish connection
```

**Solução:**
```bash
# Verificar se CallManager está acessível
ping 192.168.1.100
telnet 192.168.1.100 8443

# Se não responder, verificar:
# 1. IP correto
# 2. Firewall permitindo porta 8443
# 3. CallManager está rodando
```

### Problema 2: "Authentication failed"
```
Erro: HTTPBasicAuth failed
```

**Solução:**
```bash
# Verificar credenciais
# 1. Usuario correto (admin)
# 2. Senha correta
# 3. Usuário tem permissões AXL

# Testar com curl:
curl -k -u admin:senha https://192.168.1.100:8443/axl/
```

### Problema 3: "SSL Certificate Error"
```
Erro: certificate verify failed
```

**Solução:**
- Exporte a CA que assina o certificado HTTPS do CUCM em formato PEM e informe o caminho no `.env`:
```env
CUCM_CA_BUNDLE=C:\certs\cucm-ca.pem
```
- Acesse o CUCM pelo hostname que aparece no certificado (SAN/CN), não pelo IP, se houver erro de hostname.
- Reinicie a aplicação após alterar o `.env`.
- Para confirmar temporariamente se o problema é apenas a validação do certificado:
```env
CUCM_VERIFY_SSL=false
```
Esse modo desativa a validação TLS e não deve ser usado em produção. Remova a variável após instalar a CA correta.

### Problema 4: "Timeout"
```
Erro: Connection timeout after 10 seconds
```

**Solução:**
- Aumentar timeout em `axl_integration.py`:
```python
self.timeout = 30  # Aumentar de 10 para 30
```

### Problema 5: "No data returned"
```
Resposta: { "sucesso": false, "erro": "No data" }
```

**Solução:**
```bash
# Verificar se há dispositivos/usuários registrados
# 1. Logar no CallManager admin
# 2. Verificar Phones, Users, SIP Trunks
# 3. Se vazio, criar dados de teste
```

---

## 📊 Exemplo de Resposta

```json
{
  "sucesso": true,
  "dados": {
    "devices": {
      "total": 45,
      "active": 43,
      "inactive": 2,
      "percentage_active": 95.56,
      "timestamp": "2024-01-15T10:30:45.123456"
    },
    "users": {
      "total": 128,
      "active_today": 128,
      "timestamp": "2024-01-15T10:30:45.123456"
    },
    "sip_trunks": {
      "total": 12,
      "active": 12,
      "inactive": 0,
      "percentage_active": 100.0,
      "timestamp": "2024-01-15T10:30:45.123456"
    },
    "conferences": {
      "total": 8,
      "in_use": 2,
      "available": 6,
      "timestamp": "2024-01-15T10:30:45.123456"
    },
    "cluster": {
      "version": "8.0",
      "status": "Active",
      "timestamp": "2024-01-15T10:30:45.123456"
    },
    "timestamp": "2024-01-15T10:30:45.123456"
  }
}
```

---

## 📱 Cache de Dados

O sistema implementa cache automático de **5 minutos** para evitar sobrecarga:

```python
# Configurar cache em axl_integration.py
self.cache_duration = 300  # 5 minutos

# Para forçar atualização imediata
client.cached_data = {}
client.last_update = {}
```

---

## ✨ Próximas Etapas

1. ✅ Integração básica
2. ⬜ Adicionar gráficos interativos
3. ⬜ Histórico de dados (banco de dados)
4. ⬜ Alertas de problemas
5. ⬜ Dashboard em tempo real (WebSockets)
6. ⬜ Exportar relatórios

