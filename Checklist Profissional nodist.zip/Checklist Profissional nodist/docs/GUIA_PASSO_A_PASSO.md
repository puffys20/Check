# 🚀 GUIA PASSO A PASSO - Implementação Fase 1

**Duração**: ~2 horas  
**Dificuldade**: Média  
**Status**: ✅ PRONTO

---

## 📋 CHECKLIST PRÉ-IMPLEMENTAÇÃO

- [ ] Entendi que vou adicionar 5 novos métodos em Python
- [ ] Entendi que vou criar 5 novos endpoints em Flask
- [ ] Entendi que vou criar 5 novos gráficos em JavaScript
- [ ] Tenho acesso aos arquivos (CODIGO_FASE_1_PRONTO.md)
- [ ] O Flask está rodando (`python app.py`)

Se tudo acima ✅, pode começar!

---

## 🔧 PASSO 1: EXPANDIR AXL COLLECTOR (30 min)

### O que fazer:
Adicionar 5 novos métodos ao arquivo `modules/axl_collector.py`

### Instruções:

1. **Abra o arquivo**:
   ```
   c:\Users\z616240\Videos\Checklist Profissional\modules\axl_collector.py
   ```

2. **Procure pela ÚLTIMA função** (provavelmente `get_service_status()`)

3. **Role para o final do arquivo** e localize o final da classe AXLCollector

4. **Copie os 5 novos métodos** de `CODIGO_FASE_1_PRONTO.md`:
   - `get_phone_statistics()`
   - `get_trunk_statistics()`
   - `get_user_department_distribution()`
   - `get_device_summary()`
   - `get_media_resources_detailed()`

5. **Cole os métodos ANTES do final da classe** (antes do último `pass` ou antes do final)

6. **Salve o arquivo** (Ctrl+S)

✅ **Teste Rápido**:
```
Abra terminal Python:
python -c "from modules.axl_collector import AXLCollector; c = AXLCollector(); print('OK')"
```

Se aparecer "OK", funcionou! ✅

---

## 🌐 PASSO 2: ADICIONAR ENDPOINTS EM app.py (20 min)

### O que fazer:
Adicionar 5 novos endpoints Flask para as APIs

### Instruções:

1. **Abra o arquivo**:
   ```
   c:\Users\z616240\Videos\Checklist Profissional\app.py
   ```

2. **Procure pelo último `@app.route`** (provavelmente `/api/rtmt-data/history`)

3. **Vá para o final daquele endpoint**

4. **Copie os 5 novos endpoints** de `CODIGO_FASE_1_PRONTO.md`:
   - `@app.route('/api/extended-metrics/phones')`
   - `@app.route('/api/extended-metrics/trunks')`
   - `@app.route('/api/extended-metrics/users')`
   - `@app.route('/api/extended-metrics/devices')`
   - `@app.route('/api/extended-metrics/media')`
   - `@app.route('/api/extended-metrics/all')` ← Este é consolidado

5. **Cole APÓS o último endpoint existente**

6. **Salve o arquivo** (Ctrl+S)

✅ **Teste Rápido**:
O Flask deve recarregar automaticamente e mostrar 0 erros

---

## 📊 PASSO 3: CRIAR ARQUIVO JAVASCRIPT (15 min)

### O que fazer:
Criar novo arquivo com classe ExtendedMetrics

### Instruções:

1. **Crie novo arquivo**:
   ```
   c:\Users\z616240\Videos\Checklist Profissional\static\js\dashboard-extended-metrics.js
   ```

2. **Copie TODO o conteúdo** da seção "NOVOS GRÁFICOS - JavaScript" de `CODIGO_FASE_1_PRONTO.md`

3. **Cole no novo arquivo**

4. **Salve** (Ctrl+S)

---

## 🎨 PASSO 4: ADICIONAR GRÁFICOS AO TEMPLATE (20 min)

### O que fazer:
Adicionar containers HTML para os novos gráficos

### Instruções:

1. **Abra**:
   ```
   c:\Users\z616240\Videos\Checklist Profissional\templates\dashboard.html
   ```

2. **Procure pela seção de gráficos** (procure por `<canvas id="callVolumeChart"`)

3. **Adicione os containers APÓS o último gráfico**:

```html
<!-- NOVOS GRÁFICOS FASE 1 -->
<div class="chart-panel full-width">
    <div class="panel-header">Análise Avançada de Dispositivos</div>
    <div class="grid grid-2" style="gap: 20px;">
        <!-- Gráfico 1: Telefones por Modelo -->
        <div>
            <h4 class="chart-title">Telefones por Modelo</h4>
            <div class="chart-container" style="width: 100%; height: 300px;">
                <canvas id="phonesByModelChart"></canvas>
            </div>
        </div>
        
        <!-- Gráfico 2: Status de Telefones -->
        <div>
            <h4 class="chart-title">Status de Telefones</h4>
            <div class="chart-container" style="width: 100%; height: 300px;">
                <canvas id="phonesByStatusChart"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="chart-panel full-width">
    <div class="panel-header">Análise de Troncos e Usuários</div>
    <div class="grid grid-2" style="gap: 20px;">
        <!-- Gráfico 3: Status de Troncos -->
        <div>
            <h4 class="chart-title">Status de Troncos</h4>
            <div class="chart-container" style="width: 100%; height: 300px;">
                <canvas id="trunkStatusPieChart"></canvas>
            </div>
        </div>
        
        <!-- Gráfico 4: Usuários por Departamento -->
        <div>
            <h4 class="chart-title">Usuários por Departamento</h4>
            <div class="chart-container" style="width: 100%; height: 300px;">
                <canvas id="usersByDepartmentChart"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="chart-panel full-width">
    <div class="panel-header">Recursos de Mídia</div>
    <div class="grid grid-1" style="gap: 20px;">
        <!-- Gráfico 5: Recursos de Mídia -->
        <div>
            <h4 class="chart-title">Utilização de Recursos (CFB, MTP, Xcoder)</h4>
            <div class="chart-container" style="width: 100%; height: 300px;">
                <canvas id="mediaResourcesChart"></canvas>
            </div>
        </div>
    </div>
</div>
```

4. **Procure pela seção de `<script>` (final do arquivo)**

5. **Adicione esta linha após os outros scripts**:
```html
<script src="{{ url_for('static', filename='js/dashboard-extended-metrics.js') }}" defer></script>
```

6. **Salve** (Ctrl+S)

---

## 🧪 PASSO 5: TESTAR (30 min)

### 5a: Teste dos Endpoints

1. **Abra navegador** e acesse:
```
http://localhost:5000/api/extended-metrics/all
```

2. **Se receber JSON com dados**, ✅ funcionou!

**Esperado:**
```json
{
  "sucesso": true,
  "dados": {
    "phones": {
      "total": 450,
      "by_model": {...},
      "by_status": {...}
    },
    "trunks": {...},
    "users": {...},
    "devices": {...},
    "media": {...}
  }
}
```

Se receber erro **401** ou **403**: Problema de autenticação
- Verifique se está logado como admin
- Tente Ctrl+Shift+Delete (limpar cookies)

### 5b: Teste do Dashboard

1. **Abra o Dashboard**:
```
http://localhost:5000/dashboard
```

2. **Role para baixo** e procure por:
   - "Análise Avançada de Dispositivos"
   - "Análise de Troncos e Usuários"
   - "Recursos de Mídia"

3. **Verifique se os gráficos aparecem**:
   - ✅ Telefones por Modelo (Bar Chart)
   - ✅ Status de Telefones (Pie Chart)
   - ✅ Status de Troncos (Pie Chart)
   - ✅ Usuários por Departamento (Bar Chart)
   - ✅ Recursos de Mídia (Stacked Bar Chart)

4. **Se não aparecerem**:
   - Abra console (F12)
   - Procure por erros em vermelho
   - Verifique se o arquivo `.js` foi carregado
   - Verifique console.log de sucesso

### 5c: Teste de Auto-refresh

1. **Os gráficos devem atualizar a cada 60 segundos**
2. **Veja no console**: Mensagens de "Fetching extended metrics..."

---

## 🐛 SOLUÇÃO DE PROBLEMAS

### Erro 1: "Cannot GET /api/extended-metrics/all"
**Causa**: Endpoints não foram adicionados em `app.py`  
**Solução**: Verificar se endpoints foram colados corretamente

### Erro 2: "TypeError: get_phone_statistics is not a function"
**Causa**: Métodos não foram adicionados em `axl_collector.py`  
**Solução**: Verificar se todos 5 métodos foram colados

### Erro 3: Gráficos aparecem vazios
**Causa**: JavaScript não foi carregado ou dados são nulos  
**Solução**:
- Abrir console (F12)
- Procurar erro em vermelho
- Verificar se `/api/extended-metrics/all` retorna dados
- Verificar se `dashboard-extended-metrics.js` foi incluído no HTML

### Erro 4: 403 Unauthorized
**Causa**: Não está logado como admin  
**Solução**: Fazer login como admin (usuário padrão: admin/123456)

---

## ✅ VALIDAÇÃO FINAL

Se tudo funcionar, você deve ver:

| Item | ✅ Funcionando |
|------|---|
| Endpoint `/api/extended-metrics/all` | Retorna JSON |
| Gráfico: Telefones por Modelo | Mostra dados |
| Gráfico: Status de Telefones | Mostra Pizza colorida |
| Gráfico: Status de Troncos | Mostra Pizza |
| Gráfico: Usuários por Departamento | Mostra Barras |
| Gráfico: Recursos de Mídia | Mostra Barras Stacked |
| Auto-refresh | Atualiza a cada 60s |

**Se todas as caixas ✅, PARABÉNS! Fase 1 está completa! 🎉**

---

## 📊 RESUMO DO QUE FOI ADICIONADO

### Python (axl_collector.py)
- ✅ 5 novos métodos (300+ linhas)
- ✅ Cache de dados (5 minutos)
- ✅ Tratamento de erros

### Flask (app.py)
- ✅ 6 novos endpoints
- ✅ Autenticação de admin
- ✅ Logging de requisições

### JavaScript (dashboard-extended-metrics.js)
- ✅ Classe ExtendedMetrics
- ✅ 5 métodos de renderização
- ✅ Auto-refresh a cada 60s

### HTML (dashboard.html)
- ✅ 5 containers de gráficos
- ✅ Estilo responsivo
- ✅ Inclusão do JS novo

---

## 🎯 PRÓXIMO PASSO (Opcional)

Após Fase 1 funcionar perfeitamente:
- **Fase 2**: Integrar Perfmon para CPU/Memória/Disco reais
- **Fase 3**: Alertas automáticos
- **Fase 4**: Histórico e Trending

Veja em `ANALISE_AXL_8.5_COMPLETA.md` para próximas fases.

---

## 💬 DÚVIDAS?

1. Verifique primeiro em `CODIGO_FASE_1_PRONTO.md` (checklist)
2. Abra console do navegador (F12) para ver erros
3. Verifique terminal Python para erros do Flask
4. Compare seu código com o modelo em `CODIGO_FASE_1_PRONTO.md`

---

**Tempo Estimado**: 2 horas  
**Complexidade**: Média (copiar + colar)  
**Status**: ✅ PRONTO PARA COMEÇAR

Boa sorte! 🚀
