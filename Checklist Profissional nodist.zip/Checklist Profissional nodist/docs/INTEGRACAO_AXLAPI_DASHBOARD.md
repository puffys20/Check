# 📊 Integração AXL API com Dashboard

## 🎯 O que pode ser extraído do Cisco CallManager via AXL API

Os arquivos na pasta `axlsqltoolkit/` definem operações disponíveis no CallManager:

### 1. **Informações de Sistema**
- Status do CallManager
- Versão do software
- Nós do cluster
- Disk usage
- CPU utilization

### 2. **Usuários e Dispositivos**
- Total de usuários registrados
- Telefones conectados/desconectados
- Linhas ativas
- Extensões em uso
- Modelos de dispositivos

### 3. **Troncos SIP**
- SIP Profiles ativos
- Troncos registrados
- Status de conexão
- Chamadas SIP ativas

### 4. **Conferências**
- Salas de conferência
- Capacidade de cada sala
- Status de utilização
- Ponte de áudio

### 5. **Chamadas e Atividade**
- Chamadas ativas
- Chamadas em espera
- Taxa de chamadas por hora
- Picos de utilização

---

## 🔧 Como Integrar ao Dashboard

### Passo 1: Instalar Cliente SOAP Python
```bash
pip install zeep
```

### Passo 2: Criar Módulo de Coleta AXL
```python
# modules/axl_collector.py

from zeep import Client
from zeep.wsdl import wsdl
from zeep.exceptions import TransportError
import xml.etree.ElementTree as ET

class AXLCollector:
    def __init__(self, host, username, password):
        self.host = host
        self.username = username
        self.password = password
        self.client = None
        self._initialize_client()
    
    def _initialize_client(self):
        """Inicializa cliente SOAP WSDL"""
        wsdl_url = f"https://{self.host}:8443/axl/axlapi.wsdl"
        self.client = Client(wsdl=wsdl_url, 
                           settings=Settings(strict=False),
                           transport=Transport(verify=False,
                                             http_auth=HTTPBasicAuth(self.username, self.password)))
    
    def get_device_stats(self):
        """Retorna estatísticas de dispositivos"""
        try:
            response = self.client.service.listPhone(
                searchCriteria={'name': '%'},
                returnedTags={'name': True, 'model': True, 'status': True}
            )
            return {
                'total': response['@count'],
                'devices': response.get('phone', [])
            }
        except Exception as e:
            print(f"Erro ao buscar dispositivos: {e}")
            return None
    
    def get_user_stats(self):
        """Retorna estatísticas de usuários"""
        try:
            response = self.client.service.listEndUser(
                searchCriteria={'name': '%'}
            )
            return {
                'total': response['@count'],
                'users': response.get('endUser', [])
            }
        except Exception as e:
            print(f"Erro ao buscar usuários: {e}")
            return None
    
    def get_sip_trunks(self):
        """Retorna estatísticas de troncos SIP"""
        try:
            response = self.client.service.listSipTrunk(
                searchCriteria={'name': '%'}
            )
            return {
                'total': response['@count'],
                'trunks': response.get('sipTrunk', [])
            }
        except Exception as e:
            print(f"Erro ao buscar troncos SIP: {e}")
            return None
    
    def get_conferences(self):
        """Retorna estatísticas de conferências"""
        try:
            response = self.client.service.listConferenceRoom(
                searchCriteria={'name': '%'}
            )
            return {
                'total': response['@count'],
                'rooms': response.get('conferenceRoom', [])
            }
        except Exception as e:
            print(f"Erro ao buscar conferências: {e}")
            return None
```

### Passo 3: Atualizar Flask para Coletar Dados
```python
# app.py ou routes relacionado

from modules.axl_collector import AXLCollector

# Configurar credenciais do CallManager
AXL_CONFIG = {
    'host': os.getenv('CALLMANAGER_HOST', '192.168.1.100'),
    'username': os.getenv('CALLMANAGER_USER', 'admin'),
    'password': os.getenv('CALLMANAGER_PASS', 'senha')
}

@app.route('/api/dashboard/axl-stats')
def get_axl_stats():
    """Retorna estatísticas do CallManager via AXL"""
    try:
        axl = AXLCollector(**AXL_CONFIG)
        
        data = {
            'devices': axl.get_device_stats(),
            'users': axl.get_user_stats(),
            'sip_trunks': axl.get_sip_trunks(),
            'conferences': axl.get_conferences(),
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify({
            'sucesso': True,
            'dados': data
        })
    except Exception as e:
        return jsonify({
            'sucesso': False,
            'erro': str(e)
        }), 500
```

### Passo 4: Atualizar Dashboard HTML
```javascript
// static/js/dashboard.js

async function loadAXLStats() {
    try {
        const response = await fetch('/api/dashboard/axl-stats');
        const data = await response.json();
        
        if (data.sucesso) {
            updateChartsWithAXL(data.dados);
        }
    } catch (error) {
        console.error('Erro ao carregar estatísticas AXL:', error);
    }
}

function updateChartsWithAXL(axlData) {
    // Atualizar gráficos com dados reais do CallManager
    const deviceStats = {
        label: 'Dispositivos CallManager',
        data: [axlData.devices.total],
        backgroundColor: '#e63946'
    };
    
    const userStats = {
        label: 'Usuários Registrados',
        data: [axlData.users.total],
        backgroundColor: '#f1faee'
    };
    
    // Atualizar charts...
}

// Carregar dados ao iniciar
document.addEventListener('DOMContentLoaded', () => {
    loadAXLStats();
    // Atualizar a cada 5 minutos
    setInterval(loadAXLStats, 5 * 60 * 1000);
});
```

---

## 📈 Métricas para Dashboard

### Gráfico 1: Dispositivos Ativos
- Total de telefones
- Desconectados
- Registrados
- Por modelo

### Gráfico 2: Usuários
- Total registrado
- Ativos agora
- Com extensão
- Com voicemail

### Gráfico 3: Troncos SIP
- Troncos disponíveis
- Em uso
- Taxa de utilização
- Status

### Gráfico 4: Conferências
- Salas disponíveis
- Em uso agora
- Taxa de ocupação
- Capacidade total

---

## ⚙️ Configuração de Ambiente

Adicionar ao `.env`:
```env
CALLMANAGER_HOST=192.168.1.100
CALLMANAGER_USER=admin
CALLMANAGER_PASS=sua_senha
CALLMANAGER_PORT=8443
```

---

## 🔐 Segurança

1. Usar SSL/TLS para conexão
2. Armazenar credenciais em variáveis de ambiente
3. Validar certificados (opcional em dev)
4. Limitar frequência de requisições
5. Cache de dados (5-10 minutos)

---

## 📚 Referências de Operações AXL

Disponíveis nos arquivos WSDL:
- `getPhone` / `listPhone` - Informações de telefones
- `getEndUser` / `listEndUser` - Usuários
- `getSipTrunk` / `listSipTrunk` - Troncos SIP
- `getConferenceRoom` / `listConferenceRoom` - Conferências
- `getCCMCluster` - Status do cluster
- `getSystemPerformance` - Performance do sistema

