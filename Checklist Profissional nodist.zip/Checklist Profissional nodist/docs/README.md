# 📋 Checklist Profissional - Plataforma Consolidada

Plataforma unificada para gerenciamento de checklists com três módulos integrados: **Claro**, **Cisco** e **Salas**.

## 🎯 Características Principais

### ✅ Sistema Centralizado
- **Login Unificado**: Uma única credencial para acessar todos os módulos
- **Banco de Dados Centralizado**: SQLite único com informações de todos os usuários
- **Menu Principal**: Interface intuitiva para navegar entre módulos

### 📦 Módulos Integrados

#### 1. **Checklist Claro** 
- Inspeção de infraestrutura Claro
- Upload de imagens
- Geração de relatórios em PDF
- Histórico de inspeções

#### 2. **Checklist Cisco**
- Inspeção de infraestrutura Cisco
- Upload de imagens
- Geração de relatórios em PDF
- Histórico de inspeções

#### 3. **Checklist Salas**
- Gerenciamento de salas de reunião
- Registro de inspeções por sala
- Verificação de status de equipamentos
- Estatísticas de manutenção

### 🎨 Design Profissional
- Interface moderna e responsiva
- Gradientes sofisticados
- Design mobile-friendly
- Temas por módulo (cores distintas)

---

## 📂 Estrutura do Projeto

```
Checklist Profissional/
├── app.py                      # Aplicação principal
├── config.py                   # Configurações
├── requirements.txt            # Dependências Python
├── modules/                    # Módulos da aplicação
│   ├── __init__.py
│   ├── auth.py                # Autenticação
│   ├── database.py            # Gerenciamento BD
│   ├── claro.py               # Módulo Claro
│   ├── cisco.py               # Módulo Cisco
│   └── salas.py               # Módulo Salas
├── templates/                 # Templates HTML
│   ├── auth/
│   │   ├── login.html
│   │   └── cadastro.html
│   ├── modulos/
│   │   ├── claro/
│   │   │   ├── index.html
│   │   │   └── upload.html
│   │   ├── cisco/
│   │   │   ├── index.html
│   │   │   └── upload.html
│   │   └── salas/
│   │       └── index.html
│   ├── menu.html
│   ├── perfil.html
│   ├── dashboard.html
│   └── erros/
│       ├── 404.html
│       ├── 500.html
│       └── 403.html
├── static/                    # Arquivos estáticos
│   ├── css/
│   ├── js/
│   └── images/
├── uploads/                   # Arquivos enviados
│   ├── claro/
│   └── cisco/
├── pdfs/                      # Relatórios gerados
└── usuarios.db               # Banco de dados SQLite
```

---

## 🚀 Como Usar

### 1. **Instalação das Dependências**

```bash
pip install -r requirements.txt
```

### 2. **Executar a Aplicação**

```bash
python app.py
```

A aplicação será iniciada em: `http://localhost:5000`

### 3. **Primeiro Acesso**

1. Clique em **"Crie uma agora"** na página de login
2. Preencha os dados de cadastro
3. Faça login com suas credenciais
4. Selecione um dos 3 módulos no menu principal

### 4. **Criar Usuário de Teste (Modo Debug)**

```bash
# Acesse a URL de debug para criar usuário de teste
curl http://localhost:5000/debug/criar-usuario-teste
```

**Credenciais padrão:**
- Email: `teste@example.com`
- Senha: `123456`

---

## 🔐 Autenticação

### Recursos de Segurança
- Senhas criptografadas (werkzeug.security)
- Sessões protegidas com timeout
- Proteção contra CSRF
- Validação de emails
- Requisitos mínimos de senha

### Fluxo de Autenticação
1. Login/Cadastro → 2. Criação de sessão → 3. Acesso aos módulos

---

## 💾 Banco de Dados

### Tabelas Principais

#### `usuarios`
- ID
- Nome completo
- Email (único)
- Senha (hash)
- Departamento
- Data de criação
- Status (ativo/inativo)

#### `relatorios`
- ID
- Usuário ID
- Módulo (Claro/Cisco)
- Nome do arquivo
- Observações
- Data de geração

#### `inspecoes_salas`
- ID
- Usuário ID
- Sala ID
- Nome da sala
- Cidade
- Status
- Observações
- Data da inspeção

---

## 🛠️ APIs Disponíveis

### Autenticação
- `POST /login` - Login
- `POST /cadastro` - Cadastro
- `GET /logout` - Logout
- `GET /api/perfil` - Dados do usuário

### Módulo Claro
- `GET /claro/` - Página principal
- `POST /claro/upload` - Upload de imagens
- `GET /claro/relatorios` - Lista de relatórios
- `POST /claro/gerar-relatorio` - Gerar PDF

### Módulo Cisco
- `GET /cisco/` - Página principal
- `POST /cisco/upload` - Upload de imagens
- `GET /cisco/relatorios` - Lista de relatórios
- `POST /cisco/gerar-relatorio` - Gerar PDF

### Módulo Salas
- `GET /salas/` - Página principal
- `GET /salas/api/rooms` - Lista de salas
- `GET /salas/api/rooms/<id>` - Detalhes de uma sala
- `PUT /salas/api/rooms/<id>/status` - Atualizar status
- `GET /salas/api/inspecoes` - Histórico de inspeções

---

## 📊 Funcionalidades por Módulo

### Claro & Cisco (Similares)
- ✅ Checklist de inspeção
- ✅ Upload de múltiplas imagens
- ✅ Geração de relatórios em PDF
- ✅ Histórico de atividades
- ✅ Observações e notas

### Salas
- ✅ Cadastro de salas
- ✅ Status de equipamentos
- ✅ Registro de inspeções
- ✅ Histórico de manutenção
- ✅ Estatísticas por sala

---

## 🎯 Próximas Melhorias

- [ ] Dashboard com gráficos de atividades
- [ ] Exportação em Excel
- [ ] Autenticação LDAP/AD
- [ ] Controle de acesso por role
- [ ] Notificações por email
- [ ] Sincronização em nuvem
- [ ] Aplicativo mobile
- [ ] Integração com sistemas externos

---

## 🐛 Debug

### Modo Debug Ativado
```python
# Para desativar modo debug, edite app.py:
app.run(debug=False)
```

### Rotas de Debug
- `GET /debug/criar-usuario-teste` - Cria usuário de teste
- `GET /debug/limpar-banco` - Limpa banco de dados

⚠️ **Aviso**: Essas rotas apenas funcionam em modo debug!

---

## 📝 Configuração

Editar `config.py` para customizar:
- Chave secreta
- Tamanho máximo de upload
- Tempo de sessão
- Extensões permitidas

---

## 🔧 Requisitos Técnicos

- **Python**: 3.8+
- **Flask**: 3.0.0
- **SQLite**: Incluído no Python
- **Dependências**: Ver `requirements.txt`

---

## 📧 Suporte

Para problemas ou sugestões:
1. Consulte a documentação acima
2. Verifique o arquivo `app.log`
3. Ative o modo debug para mais detalhes

---

## 📄 Licença

© 2024 Checklist Profissional. Todos os direitos reservados.

---

**Versão**: 1.0.0  
**Última atualização**: 2024
