# ✅ Verificação de Gráficos do Dashboard

## 🎯 Objetivo

Verificar se todos os gráficos estão sendo renderizados corretamente e se as atualizações automáticas estão funcionando.

---

## 📊 Gráficos que Devem Aparecer

### 1. **Distribuição de Atividades por Módulo**
- **Tipo**: Pizza/Donut Chart
- **Dados**: Cisco, Claro, Salas
- **Cores**: Azul (#0099ff), Verde (#00cc6d), Laranja (#ff9900)
- **Localização**: Topo, após os cards de resumo

### 2. **Uso de CPU (%)**
- **Tipo**: Bar Chart (horizontal)
- **Dados**: Um bar por nó do cluster (Publisher, Subscriber 1, etc)
- **Localização**: Seção "Monitoramento RTMT Cisco" > primeiro painel

### 3. **Uso de Memória (%)**
- **Tipo**: Bar Chart (horizontal)
- **Dados**: Um bar por nó do cluster
- **Localização**: Seção "Monitoramento RTMT Cisco" > segundo painel

### 4. **Uso de Disco (%)**
- **Tipo**: Bar Chart (horizontal)
- **Dados**: Um bar por nó do cluster
- **Localização**: Seção "Monitoramento RTMT Cisco" > terceiro painel

### 5. **Volume de Chamadas (Última Hora)**
- **Tipo**: Line Chart
- **Dados**: Pontos de chamadas por minuto
- **Localização**: Seção "Atividade de Chamadas" > lado esquerdo

### 6. **Status dos Telefones**
- **Tipo**: Doughnut Chart
- **Dados**: Registrados, Não Registrados, Parcial
- **Centro**: Número total de telefones
- **Cores**: Verde (#28a745), Vermelho (#dc3545), Amarelo (#ffc107)
- **Localização**: Seção "Atividade de Chamadas" > lado direito

### 7. **Status dos Trunks SIP**
- **Tipo**: Tabela com status
- **Dados**: Nome do trunk e status (Online/Offline)
- **Localização**: Painel "Status dos Trunks SIP"

### 8. **Recursos de Mídia**
- **Tipo**: Gauges Radiais (múltiplos)
- **Dados**: Conference Bridges, Transcoders, MTPs
- **Exibe**: Quantidade em uso / total
- **Localização**: Painel "Uso de Recursos de Mídia"

### 9. **Status dos Serviços CUCM**
- **Tipo**: Badges com status
- **Dados**: Cada serviço com indicador verde (Started) ou vermelho (Stopped)
- **Localização**: Painel "Status dos Serviços CUCM"

### 10. **Histórico (30 dias) - Se Admin**
Aparecem apenas se o usuário é admin e seleciona "Últimos 30 Dias":
- CPU - Line Chart
- Memória - Line Chart
- Volume de Chamadas - Line Chart
- Status dos Telefones - Stacked Area Chart
- Recursos de Mídia - Stacked Area Chart

---

## 🔍 Como Verificar Usando o Dashboard Monitor

### 1. Abrir o Monitor
- Procure pelo botão roxo **📊** no canto inferior direito da página
- Clique para abrir o painel de monitoramento

### 2. Verificar Status
O monitor mostra:
- **✅ Ativo**: Atualização recebida há menos de 65 segundos
- **⚠️ Atrasado**: Atualização há mais de 65 segundos
- **❌ Inativo**: Sem atualização há mais de 5 minutos

### 3. Visualizar Logs
Cada atualização de gráfico aparece no log:
```
✅ [10:30:45] CPU Graph: 2 nós
✅ [10:30:45] Memory Graph: 2 nós
✅ [10:30:45] Disk Graph: 2 nós
✅ [10:30:45] Call Volume Chart: 60 pontos
...
```

### 4. Interpretar Dados
- **Total**: Quantidade de atualizações recebidas
- **Erros**: Quantidade de falhas no carregamento
- **Status**: ✅ Ativo, ⚠️ Atrasado, ou ❌ Inativo

---

## 📈 Gráficos por Modo

### Modo Tempo Real (Padrão)
```
✅ Module Activity Chart
✅ CPU Graph
✅ Memory Graph
✅ Disk Graph
✅ Call Volume Chart
✅ Phone Status Chart
✅ Trunk Status Table
✅ Media Resources (Gauges)
✅ CUCM Services Status
```

### Modo Histórico (Admin Only)
```
✅ CPU History (Line)
✅ Memory History (Line)
✅ Call Volume History (Line)
✅ Phone Status History (Stacked)
✅ Media Resources History (Stacked)
```

---

## 🐛 Troubleshooting

### Problema 1: Nenhum gráfico aparece
```
❌ Status: Inativo
❌ Erro: "Connection refused"
```

**Solução:**
1. Abra o console (F12) > Network
2. Procure por requisições para `/api/rtmt/data`
3. Verifique se retorna status 200
4. Se 500: Erro no backend (verificar logs do Flask)

### Problema 2: Gráficos aparecem mas não atualizam
```
⚠️ Status: Atrasado (300+ segundos)
```

**Solução:**
1. Verifique se a atualização automática está ativa:
   - Intervalo: 60 segundos
   - Função: `startAutoUpdate()`
2. Abra console > Network > filtre por "rtmt"
3. Deve haver requisições a cada 60 segundos
4. Se não houver: Desative/Reative modo Tempo Real

### Problema 3: Um gráfico específico não renderiza
Exemplo: "❌ Phone Status Chart"

**Solução:**
1. Verifique se os dados estão vindo da API:
   - Console: `fetch('/api/rtmt/data')` e veja a resposta
2. Procure por `phoneStatus` nos dados
3. Verifique se não há erros na renderização:
   - Console > Errors
   - Procure por "Canvas" ou o nome do gráfico

### Problema 4: Erros aparecem no monitor
```
❌ [10:31:00] RTMT API: Network error
```

**Solução:**
1. Verifique conectividade com o backend
2. Verifique se a API `/api/rtmt/data` está funcionando
3. Verificar credenciais do CallManager no `.env`
4. Verificar logs do Flask: `tail -f app.log`

---

## 📱 Checklist de Verificação

### Carregamento Inicial
- [ ] Página carrega sem erros
- [ ] Card de resumo (Cisco, Claro, Salas) exibe números
- [ ] Gráfico de "Distribuição de Atividades" aparece

### Monitoramento RTMT
- [ ] Indicadores de status mostram (Online/Offline)
- [ ] Versão do CUCM aparece
- [ ] Timestamp de última atualização é exibido

### Gráficos de Tempo Real
- [ ] Gráfico de CPU aparece com barras
- [ ] Gráfico de Memória aparece com barras
- [ ] Gráfico de Disco aparece com barras
- [ ] Gráfico de Volume de Chamadas aparece
- [ ] Gráfico de Status de Telefones aparece (com total no centro)
- [ ] Tabela de Trunks SIP aparece

### Gráficos de Recursos
- [ ] Gauges de Recursos de Mídia aparecem
- [ ] Badges de Status de Serviços aparecem

### Atualização Automática
- [ ] Monitor mostra "Ativo" (verde)
- [ ] Contadores aumentam a cada 60 segundos
- [ ] Nenhum erro no console
- [ ] Última atualização é recente

### Modo Histórico (Admin)
- [ ] Dropdown de "Tempo Real / Últimos 30 Dias" aparece
- [ ] Ao selecionar "Últimos 30 Dias":
  - [ ] Gráficos de histórico carregam
  - [ ] Linhas de tendência são exibidas
  - [ ] Dados cobrem o período correto

---

## 📊 Exemplo de Resposta OK

```json
{
  "sucesso": true,
  "dados": {
    "clusterHealth": [
      {
        "name": "Publisher",
        "cpu": 45.2,
        "memory": 68.5,
        "disk": 42.1
      }
    ],
    "callVolume": {
      "labels": ["10:00", "10:01", ..., "11:00"],
      "data": [120, 115, 130, ...]
    },
    "phoneStatus": {
      "registered": 125,
      "unregistered": 8,
      "partial": 2
    },
    "trunkStatus": [...],
    "mediaResources": {...},
    "serviceStatus": [...],
    "connectionMode": "Online (API)",
    "cucmVersion": "8.3.4"
  }
}
```

---

## 🎯 Conclusão

✅ Quando todos os itens do checklist estão verdes, o dashboard está funcionando corretamente!

Se algum gráfico está faltando ou não atualiza, use o **Dashboard Monitor** para diagnosticar o problema.

