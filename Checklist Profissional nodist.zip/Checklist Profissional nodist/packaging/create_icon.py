from pathlib import Path

from PIL import Image, ImageDraw


def create_icon(output_path: Path) -> None:
    sizes = (16, 24, 32, 48, 64, 128, 256)
    images = []

    for size in sizes:
        image = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        scale = size / 64
        shield = [(int(x * scale), int(y * scale)) for x, y in ((32, 4), (52, 12), (52, 30), (48, 42), (40, 52), (32, 60), (24, 52), (16, 42), (12, 30), (12, 12))]
        draw.polygon(shield, fill='#e63946')
        draw.rectangle((int(28 * scale), int(18 * scale), int(36 * scale), int(46 * scale)), fill='white')
        draw.rectangle((int(16 * scale), int(30 * scale), int(48 * scale), int(38 * scale)), fill='white')
        images.append(image)

    images[-1].save(output_path, format='ICO', sizes=[(size, size) for size in sizes])


if __name__ == '__main__':
    create_icon(Path(__file__).with_name('checklist.ico'))