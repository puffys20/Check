#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script de inicialização da aplicação Checklist Profissional
Localizado na raiz do projeto para facilitar execução
"""
import sys
import os
import site
import threading
import time
import webbrowser

# Definir o diretório do projeto
project_root = os.path.dirname(os.path.abspath(__file__))

# Adicionar src/ ao path
sys.path.insert(0, os.path.join(project_root, 'src'))

# Garantir que o venv site-packages está no path
venv_path = os.path.join(project_root, 'venv')
if os.path.exists(venv_path):
    # Adicionar venv site-packages
    site_packages = os.path.join(venv_path, 'Lib', 'site-packages')
    if os.path.exists(site_packages):
        sys.path.insert(0, site_packages)
        print(f"✓ venv site-packages adicionado ao path: {site_packages}")

# Verificar se psutil está disponível
try:
    import psutil
    print(f"✓ psutil {psutil.__version__} disponível")
except ImportError:
    print("⚠ AVISO: psutil não encontrado. Instale com: pip install psutil")

# Importar e executar a aplicação
if __name__ == '__main__':
    from app import app

    def abrir_navegador():
        time.sleep(1.5)
        webbrowser.open('http://127.0.0.1:5000')

    threading.Thread(target=abrir_navegador, daemon=True).start()
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=False,
        use_reloader=False
    )
