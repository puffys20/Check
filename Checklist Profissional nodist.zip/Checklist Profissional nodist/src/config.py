"""
Configuração centralizada da aplicação
"""
import os
import sys
from pathlib import Path

def get_base_path():
    """Detecta o caminho base (compatível com .exe e desenvolvimento)"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

BASE_DIR = get_base_path()
UPLOADS_DIR = os.path.join(BASE_DIR, "data", "uploads")
PDFS_DIR = os.path.join(BASE_DIR, "data", "pdfs")
DATABASE_PATH = os.path.join(BASE_DIR, "data", "usuarios.db")


def get_cucm_ssl_verify():
    """Resolve a validação TLS do CUCM a partir do ambiente."""
    ca_bundle = os.getenv('CUCM_CA_BUNDLE')
    if ca_bundle:
        ca_path = os.path.abspath(os.path.expandvars(os.path.expanduser(ca_bundle)))
        if not os.path.isfile(ca_path):
            raise FileNotFoundError(f"CA do CUCM não encontrada: {ca_path}")
        return ca_path

    verify_ssl = os.getenv('CUCM_VERIFY_SSL', 'true').strip().lower()
    if verify_ssl in {'0', 'false', 'no', 'off'}:
        return False
    return True

# Criar diretórios se não existirem
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(os.path.join(UPLOADS_DIR, "claro"), exist_ok=True)
os.makedirs(os.path.join(UPLOADS_DIR, "cisco"), exist_ok=True)
os.makedirs(os.path.join(UPLOADS_DIR, "perfil"), exist_ok=True)
os.makedirs(PDFS_DIR, exist_ok=True)

class Config:
    """Configurações padrão"""
    SECRET_KEY = os.getenv('SECRET_KEY', 'chave_secreta_consolidada_2024')
    UPLOAD_FOLDER = UPLOADS_DIR
    PDFS_FOLDER = PDFS_DIR
    MAX_CONTENT_LENGTH = 500 * 1024 * 1024  # 500MB
    DATABASE = DATABASE_PATH
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'}
    JSON_SORT_KEYS = False
    
    # Configurações de sessão
    PERMANENT_SESSION_LIFETIME = 1800  # 30 minutos
    SESSION_COOKIE_SECURE = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Configurações de email (usar variáveis de ambiente em produção)
    MAIL_SERVER = os.getenv('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.getenv('MAIL_PORT', 587))
    MAIL_USE_TLS = os.getenv('MAIL_USE_TLS', 'True') == 'True'
    MAIL_USERNAME = os.getenv('MAIL_USERNAME', '')
    MAIL_PASSWORD = os.getenv('MAIL_PASSWORD', '')
    MAIL_DEFAULT_SENDER = os.getenv('MAIL_DEFAULT_SENDER', 'noreply@checklistprofissional.com')

    # Destinatários pré-preenchidos para a composição no Outlook Web
    OUTLOOK_TO = os.getenv('OUTLOOK_TO', 'marco.agostinelli@claro.com.br')
    OUTLOOK_CC = os.getenv(
        'OUTLOOK_CC',
        'jcesar@interatell.com.br,acampos@interatell.com.br,'
        'wblucas@interatell.com.br,fernando.perlin.terceiros@claro.com.br,'
        'gandrade@interatell.com.br,victor.agrela.terceiros@claro.com.br'
    )

    # Credenciais do Admin Padrão
    ADMIN_EMAIL = os.getenv('ADMIN_EMAIL', 'admin@checklist.pro')
    ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'Admin@2024')

    # Proteção adicional do dashboard
    DASHBOARD_PASSWORD = os.getenv('DASHBOARD_PASSWORD', 'S@kura9923')

class DevelopmentConfig(Config):
    """Configuração de desenvolvimento"""
    DEBUG = True
    TESTING = False

class ProductionConfig(Config):
    """Configuração de produção"""
    DEBUG = False
    TESTING = False
    SESSION_COOKIE_SECURE = True

class TestingConfig(Config):
    """Configuração de testes"""
    DEBUG = True
    TESTING = True

# Selecionar configuração baseada no ambiente
config = DevelopmentConfig()
