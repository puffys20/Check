"""
Blueprint de Autenticação (Login, Cadastro, Logout)
"""
from flask import Blueprint, render_template, request, session, redirect, url_for, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
from modules.database import (
    get_db_connection, get_usuario_info, verificar_email_exists
)
import logging
import re

logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__)

def validar_email(email):
    """Valida formato de email"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validar_senha(senha):
    """Valida força da senha"""
    if len(senha) < 6:
        return False, "Senha deve ter no mínimo 6 caracteres"
    return True, "OK"

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Página de login"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        senha = request.form.get('senha', '')
        
        if not email or not senha:
            return render_template('auth/login.html', 
                                   erro="Email e senha são obrigatórios")
        
        conn = get_db_connection()
        usuario = conn.execute(
            'SELECT * FROM usuarios WHERE email = ? AND ativo = 1',
            (email,)
        ).fetchone()
        conn.close()
        
        if usuario and check_password_hash(usuario['senha'], senha):
            session['usuario_id'] = usuario['id']
            session['usuario_nome'] = usuario['nome_completo']
            session['usuario_email'] = usuario['email']
            session.permanent = True
            logger.info(f"LOGIN: Usuário '{usuario['nome_completo']}' autenticado com sucesso")
            return redirect(url_for('menu'))
        else:
            logger.warning(f"LOGIN FALHOU: Email '{email}' - credenciais inválidas")
            return render_template('auth/login.html', 
                                   erro="Email ou senha inválidos")
    
    return render_template('auth/login.html')

@auth_bp.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    """Página de cadastro de novo usuário"""
    if request.method == 'POST':
        nome = request.form.get('nome_completo', '').strip()
        email = request.form.get('email', '').strip()
        senha = request.form.get('senha', '')
        confirmar_senha = request.form.get('confirmar_senha', '')
        # Tenta obter 'departamento' ou 'department' para compatibilidade
        departamento = request.form.get('departamento') or request.form.get('department', '')
        
        # Validações
        if not all([nome, email, senha, confirmar_senha, departamento]):
            return render_template('auth/cadastro.html', 
                                   erro="Todos os campos são obrigatórios")
        
        if not validar_email(email):
            return render_template('auth/cadastro.html', 
                                   erro="Email inválido")
        
        valido, msg = validar_senha(senha)
        if not valido:
            return render_template('auth/cadastro.html', erro=msg)
        
        if senha != confirmar_senha:
            return render_template('auth/cadastro.html', 
                                   erro="Senhas não conferem")
        
        if verificar_email_exists(email):
            return render_template('auth/cadastro.html', 
                                   erro="Este email já está cadastrado")
        
        # Salvar novo usuário
        try:
            conn = get_db_connection()
            conn.execute(
                '''INSERT INTO usuarios 
                   (nome_completo, email, senha, departamento) 
                   VALUES (?, ?, ?, ?)''',
                (nome, email, generate_password_hash(senha), departamento)
            )
            conn.commit()
            conn.close()
            
            logger.info(f"CADASTRO: Novo usuário registrado - {email}")
            return render_template('auth/cadastro.html', 
                                   sucesso="Cadastro realizado com sucesso! Faça login.")
        except Exception as e:
            logger.error(f"Erro ao cadastrar usuário: {e}")
            return render_template('auth/cadastro.html', 
                                   erro=f"Erro ao realizar cadastro: {str(e)}")
    
    return render_template('auth/cadastro.html')

@auth_bp.route('/logout')
def logout():
    """Logout do usuário"""
    usuario_nome = session.get('usuario_nome', 'Usuário')
    session.clear()
    logger.info(f"LOGOUT: Usuário '{usuario_nome}' desconectado")
    return redirect(url_for('auth.login'))

@auth_bp.route('/api/perfil')
def api_perfil():
    """API para obter dados do usuário logado"""
    usuario_id = session.get('usuario_id')
    if not usuario_id:
        return jsonify({'erro': 'Não autenticado'}), 401
    
    usuario = get_usuario_info(usuario_id)
    if usuario:
        return jsonify({
            'id': usuario['id'],
            'nome': usuario['nome_completo'],
            'email': usuario['email'],
            'departamento': usuario.get('departamento', '')
        })
    
    return jsonify({'erro': 'Usuário não encontrado'}), 404
