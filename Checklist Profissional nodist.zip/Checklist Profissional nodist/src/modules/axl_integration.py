# modules/axl_integration.py
"""
Integração com API AXL do Cisco CallManager
Extrai dados para alimentar gráficos do dashboard
"""

import os
from datetime import datetime, timedelta
import logging
from typing import Dict, Any, Optional
import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET
from functools import lru_cache
import time
from config import get_cucm_ssl_verify

logger = logging.getLogger(__name__)


class AXLAPIClient:
    """Cliente para comunicação com API AXL do Cisco CallManager"""
    
    def __init__(self, host: str, username: str, password: str, port: int = 8443):
        """
        Inicializa cliente AXL
        
        Args:
            host: IP/hostname do CallManager
            username: Usuário administrativo
            password: Senha do usuário
            port: Porta HTTPS (padrão 8443)
        """
        self.host = host
        self.username = username
        self.password = password
        self.port = port
        self.base_url = f"https://{host}:{port}/axl/"
        self.timeout = 10
        self.cache_duration = 300  # 5 minutos
        self.last_update = {}
        self.cached_data = {}
        
    def _make_soap_request(self, method: str, params: Dict[str, Any]) -> Optional[str]:
        """
        Realiza requisição SOAP para CallManager
        
        Args:
            method: Nome do método AXL
            params: Parâmetros do método
            
        Returns:
            XML response como string
        """
        try:
            # Construir envelope SOAP
            soap_body = self._build_soap_envelope(method, params)
            
            headers = {
                'Content-Type': 'text/xml; charset=utf-8',
                'SOAPAction': f'CUCM:DB ver={self._get_version()}'
            }
            
            response = requests.post(
                self.base_url,
                data=soap_body,
                headers=headers,
                auth=HTTPBasicAuth(self.username, self.password),
                verify=get_cucm_ssl_verify(),
                timeout=self.timeout
            )
            
            response.raise_for_status()
            return response.text
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Erro na requisição AXL: {e}")
            return None
    
    def _build_soap_envelope(self, method: str, params: Dict) -> str:
        """Constrói envelope SOAP para o método"""
        params_xml = ''.join([
            f"<{k}>{v}</{k}>" for k, v in params.items()
        ])
        
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                 xmlns:axl="http://www.cisco.com/AXL/API/8.0">
    <soapenv:Header/>
    <soapenv:Body>
        <axl:{method}>
            {params_xml}
        </axl:{method}>
    </soapenv:Body>
</soapenv:Envelope>"""
    
    def _get_version(self) -> str:
        """Retorna versão AXL (padrão 8.0)"""
        return "8.0"
    
    def _parse_response(self, response_xml: str) -> Optional[Dict]:
        """Parse XML response"""
        try:
            root = ET.fromstring(response_xml)
            return root
        except ET.ParseError as e:
            logger.error(f"Erro ao parsear XML: {e}")
            return None
    
    def _is_cache_valid(self, key: str) -> bool:
        """Verifica se cache ainda é válido"""
        if key not in self.last_update:
            return False
        
        elapsed = time.time() - self.last_update[key]
        return elapsed < self.cache_duration
    
    def _update_cache(self, key: str, data: Dict):
        """Atualiza cache com timestamp"""
        self.cached_data[key] = data
        self.last_update[key] = time.time()
    
    def get_devices_stats(self) -> Optional[Dict[str, Any]]:
        """
        Retorna estatísticas de dispositivos (telefones)
        
        Returns:
            Dict com contagem e lista de dispositivos
        """
        cache_key = 'devices'
        
        if self._is_cache_valid(cache_key):
            return self.cached_data[cache_key]
        
        try:
            response = self._make_soap_request('listPhone', {
                'searchCriteria': '<name>%</name>',
                'returnedTags': '<name/><model/><devicePoolName/><status/>'
            })
            
            if not response:
                return None
            
            # Parse e contar
            total = self._count_elements(response, 'phone')
            active = self._count_elements(response, 'status', '.*REGISTERED.*')
            
            data = {
                'total': total,
                'active': active,
                'inactive': total - active,
                'percentage_active': (active / total * 100) if total > 0 else 0,
                'timestamp': datetime.now().isoformat()
            }
            
            self._update_cache(cache_key, data)
            return data
            
        except Exception as e:
            logger.error(f"Erro ao obter stats de dispositivos: {e}")
            return None
    
    def get_users_stats(self) -> Optional[Dict[str, Any]]:
        """
        Retorna estatísticas de usuários
        
        Returns:
            Dict com contagem de usuários
        """
        cache_key = 'users'
        
        if self._is_cache_valid(cache_key):
            return self.cached_data[cache_key]
        
        try:
            response = self._make_soap_request('listEndUser', {
                'searchCriteria': '<name>%</name>',
                'returnedTags': '<userId/><firstName/><lastName/>'
            })
            
            if not response:
                return None
            
            total = self._count_elements(response, 'endUser')
            
            data = {
                'total': total,
                'active_today': total,  # Requer tracking adicional
                'timestamp': datetime.now().isoformat()
            }
            
            self._update_cache(cache_key, data)
            return data
            
        except Exception as e:
            logger.error(f"Erro ao obter stats de usuários: {e}")
            return None
    
    def get_sip_trunks_stats(self) -> Optional[Dict[str, Any]]:
        """
        Retorna estatísticas de troncos SIP
        
        Returns:
            Dict com contagem de troncos
        """
        cache_key = 'sip_trunks'
        
        if self._is_cache_valid(cache_key):
            return self.cached_data[cache_key]
        
        try:
            response = self._make_soap_request('listSipTrunk', {
                'searchCriteria': '<name>%</name>',
                'returnedTags': '<name/><status/>'
            })
            
            if not response:
                return None
            
            total = self._count_elements(response, 'sipTrunk')
            active = self._count_elements(response, 'status', '.*REGISTERED.*')
            
            data = {
                'total': total,
                'active': active,
                'inactive': total - active,
                'percentage_active': (active / total * 100) if total > 0 else 0,
                'timestamp': datetime.now().isoformat()
            }
            
            self._update_cache(cache_key, data)
            return data
            
        except Exception as e:
            logger.error(f"Erro ao obter stats de troncos SIP: {e}")
            return None
    
    def get_conferences_stats(self) -> Optional[Dict[str, Any]]:
        """
        Retorna estatísticas de conferências
        
        Returns:
            Dict com informações de conferências
        """
        cache_key = 'conferences'
        
        if self._is_cache_valid(cache_key):
            return self.cached_data[cache_key]
        
        try:
            response = self._make_soap_request('listConferenceRoom', {
                'searchCriteria': '<name>%</name>',
                'returnedTags': '<name/><maxParticipants/>'
            })
            
            if not response:
                return None
            
            total = self._count_elements(response, 'conferenceRoom')
            
            data = {
                'total': total,
                'in_use': 0,  # Requer tracking adicional
                'available': total,
                'timestamp': datetime.now().isoformat()
            }
            
            self._update_cache(cache_key, data)
            return data
            
        except Exception as e:
            logger.error(f"Erro ao obter stats de conferências: {e}")
            return None
    
    def get_cluster_stats(self) -> Optional[Dict[str, Any]]:
        """
        Retorna status do cluster CallManager
        
        Returns:
            Dict com informações do cluster
        """
        cache_key = 'cluster'
        
        if self._is_cache_valid(cache_key):
            return self.cached_data[cache_key]
        
        try:
            response = self._make_soap_request('getCCMCluster', {})
            
            if not response:
                return None
            
            # Parse versão e status
            version = self._extract_value(response, 'version')
            
            data = {
                'version': version,
                'status': 'Active',
                'timestamp': datetime.now().isoformat()
            }
            
            self._update_cache(cache_key, data)
            return data
            
        except Exception as e:
            logger.error(f"Erro ao obter stats do cluster: {e}")
            return None
    
    def _count_elements(self, xml_response: str, element: str, pattern: str = '.*') -> int:
        """Conta elementos no XML"""
        try:
            root = ET.fromstring(xml_response)
            ns = {'axl': 'http://www.cisco.com/AXL/API/8.0'}
            elements = root.findall(f'.//axl:{element}', ns)
            return len(elements) if elements else 0
        except:
            return 0
    
    def _extract_value(self, xml_response: str, tag: str) -> Optional[str]:
        """Extrai valor de tag XML"""
        try:
            root = ET.fromstring(xml_response)
            ns = {'axl': 'http://www.cisco.com/AXL/API/8.0'}
            element = root.find(f'.//axl:{tag}', ns)
            return element.text if element is not None else None
        except:
            return None
    
    def get_all_stats(self) -> Dict[str, Any]:
        """
        Retorna todas as estatísticas para dashboard
        
        Returns:
            Dict com todas as estatísticas
        """
        return {
            'devices': self.get_devices_stats(),
            'users': self.get_users_stats(),
            'sip_trunks': self.get_sip_trunks_stats(),
            'conferences': self.get_conferences_stats(),
            'cluster': self.get_cluster_stats(),
            'timestamp': datetime.now().isoformat()
        }


class AXLDashboardHelper:
    """Helper para integração AXL com Dashboard"""
    
    def __init__(self):
        self.client = None
        self._initialize()
    
    def _initialize(self):
        """Inicializa cliente AXL com variáveis de ambiente"""
        try:
            host = os.getenv('CALLMANAGER_HOST')
            user = os.getenv('CALLMANAGER_USER')
            passwd = os.getenv('CALLMANAGER_PASS')
            
            if all([host, user, passwd]):
                self.client = AXLAPIClient(host, user, passwd)
                logger.info("Cliente AXL inicializado com sucesso")
            else:
                logger.warning("Variáveis AXL não configuradas")
        except Exception as e:
            logger.error(f"Erro ao inicializar AXL: {e}")
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """Retorna dados formatados para dashboard"""
        if not self.client:
            return {
                'sucesso': False,
                'erro': 'AXL não configurado'
            }
        
        try:
            all_stats = self.client.get_all_stats()
            
            return {
                'sucesso': True,
                'dados': all_stats
            }
        except Exception as e:
            logger.error(f"Erro ao obter dados dashboard: {e}")
            return {
                'sucesso': False,
                'erro': str(e)
            }

