"""
Blueprint para Checklist Claro
Reutiliza funcionalidades de relatório e upload de imagens
"""
from flask import Blueprint, render_template, request, jsonify, send_file, session, Response
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash
from modules.database import login_required, get_db_connection, get_usuario_info
from config import config
from io import BytesIO
import os
import logging
from datetime import datetime, timedelta
from reportlab.platypus import SimpleDocTemplate, Image, PageBreak, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib import colors
from PIL import Image as PILImage
import urllib.request

logger = logging.getLogger(__name__)

claro_bp = Blueprint('claro', __name__, url_prefix='/claro')

@claro_bp.route('/')
@login_required
def index():
    """Página inicial do módulo Claro"""
    usuario_id = session['usuario_id']
    usuario = get_usuario_info(usuario_id)
    
    conn = get_db_connection()
    ultimo_relatorio = conn.execute(
        'SELECT MAX(data_geracao) as ultima_data FROM relatorios WHERE usuario_id = ? AND modulo = ?',
        (usuario_id, 'Claro')
    ).fetchone()
    conn.close()

    pode_gerar = True
    tempo_restante_segundos = 0
    dias_bloqueio = 365

    if ultimo_relatorio and ultimo_relatorio['ultima_data']:
        ultima_data = datetime.strptime(ultimo_relatorio['ultima_data'], '%Y-%m-%d %H:%M:%S')
        agora = datetime.now()
        tempo_passado = agora - ultima_data
        
        if tempo_passado.total_seconds() < dias_bloqueio * 24 * 3600:
            pode_gerar = False
            tempo_restante = (ultima_data + timedelta(days=dias_bloqueio)) - agora
            tempo_restante_segundos = int(tempo_restante.total_seconds())

    return render_template('modulos/claro/index.html', usuario=usuario,
                           pode_gerar=pode_gerar,
                           tempo_restante=tempo_restante_segundos)

@claro_bp.route('/inspecao')
@login_required
def inspecao():
    """Página de inspeção com upload de imagens"""
    usuario = get_usuario_info(session['usuario_id'])
    return render_template('modulos/claro/inspecao.html', usuario=usuario)

@claro_bp.route('/upload-imagens')
@login_required
def upload_imagens():
    """Página para fazer upload de imagens"""
    usuario = get_usuario_info(session['usuario_id'])
    return render_template('modulos/claro/upload.html', usuario=usuario)

@claro_bp.route('/upload', methods=['POST'])
@login_required
def upload_arquivo():
    """Processa upload de múltiplas imagens e gera PDF profissional"""
    try:
        arquivos = request.files.getlist('imagem')
        nomes = request.form.getlist('nomes')
        observacao = request.form.get('observacao', '').strip()
        localidade = request.form.get('localidade', '').strip()
        tipo_inspecao = request.form.get('tipo', '').strip()
        usuario_id = session['usuario_id']
        usuario = get_usuario_info(usuario_id)
        usuario_nome = usuario['nome_completo']

        logger.info(f"Upload iniciado por {usuario_nome} com {len(arquivos)} arquivo(s)")
        
        if not arquivos or all(f.filename == '' for f in arquivos):
            logger.warning("Nenhuma imagem foi enviada")
            return jsonify({"erro": "Nenhuma imagem foi selecionada"}), 400
        
        dados = []
        upload_dir = os.path.join(config.UPLOAD_FOLDER, 'claro')
        os.makedirs(upload_dir, exist_ok=True)
        
        for i, file in enumerate(arquivos):
            if file and file.filename != '':
                # Validar extensão
                ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
                if ext not in config.ALLOWED_EXTENSIONS:
                    logger.warning(f"Arquivo com extensão não permitida: {file.filename}")
                    continue
                
                # Gerar nome seguro
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
                nome_arquivo_seguro = f"img_{timestamp}_{i}.{ext}"
                caminho = os.path.join(upload_dir, nome_arquivo_seguro)
                
                # Salvar arquivo
                file.save(caminho)
                logger.info(f"Imagem salva: {nome_arquivo_seguro}")
                
                # Obter nome da imagem
                nome_imagem = nomes[i].strip() if i < len(nomes) and nomes[i].strip() else f"Imagem {i + 1}"
                dados.append((caminho, nome_imagem))
        
        if not dados:
            logger.warning("Nenhuma imagem válida foi processada")
            return jsonify({"erro": "Nenhuma imagem válida foi processada"}), 400
        
        # Ordenar imagens por nome
        dados.sort(key=lambda x: x[1].lower())
        logger.info(f"Imagens ordenadas por nome: {[nome for _, nome in dados]}")
        
        # Gerar PDF
        data_hora = datetime.now().strftime("%Y%m%d_%H%M%S")
        nome_pdf = f"relatorio_claro_{data_hora}.pdf"
        caminho_pdf = os.path.join(config.UPLOAD_FOLDER, 'claro', nome_pdf)
        
        criar_pdf(dados, caminho_pdf, observacao, usuario_nome, localidade, tipo_inspecao)
        logger.info(f"PDF gerado com sucesso: {nome_pdf}")
        
        # Salvar referência no banco de dados
        try:
            conn = get_db_connection()
            data_geracao = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            conn.execute(
                'INSERT INTO relatorios (usuario_id, modulo, nome_arquivo, data_geracao, observacao) VALUES (?, ?, ?, ?, ?)',
                (usuario_id, 'Claro', nome_pdf, data_geracao, observacao)
            )
            conn.commit()
            conn.close()
            logger.info(f"✓ Relatório Claro registrado no banco para usuário {usuario_id}")
        except Exception as e:
            logger.error(f"Erro ao registrar relatório: {str(e)}", exc_info=True)
        
        # Formatar data para download: Checklist-Claro DD-MM-YYYY.pdf
        data_obj = datetime.strptime(data_geracao, "%Y-%m-%d %H:%M:%S")
        data_formatada = data_obj.strftime("%d-%m-%Y")
        download_filename = f"Checklist-Claro {data_formatada}.pdf"
        
        # Ler arquivo e enviar com nome formatado
        with open(caminho_pdf, 'rb') as f:
            pdf_data = f.read()
        
        response = Response(pdf_data, mimetype='application/pdf')
        response.headers['Content-Disposition'] = f'attachment; filename="{download_filename}"'
        return response
    
    except Exception as e:
        logger.error(f"Erro ao processar upload: {str(e)}", exc_info=True)
        return jsonify({"erro": f"Erro ao gerar PDF: {str(e)}"}), 500


def draw_background(canvas, doc):
    """Desenha o fundo preto em cada página"""
    canvas.saveState()
    canvas.setFillColor(colors.black)
    canvas.rect(0, 0, doc.width + doc.leftMargin * 2, doc.height + doc.topMargin * 2, fill=1, stroke=0)
    canvas.restoreState()

def criar_pdf(dados, caminho_pdf, observacao, usuario_nome, localidade, tipo_inspecao):
    """Cria um PDF profissional com capa e imagens nas páginas seguintes"""
    try:
        doc = SimpleDocTemplate(
            caminho_pdf,
            pagesize=landscape(A4),
            topMargin=0.8 * cm,
            bottomMargin=1.5 * cm,
            leftMargin=1.5 * cm,
            rightMargin=1.5 * cm
        )
        story = []
        styles = getSampleStyleSheet()
        
        # Estilos personalizados
        estilo_titulo = ParagraphStyle(
            name='Titulo',
            parent=styles['Heading1'],
            alignment=TA_CENTER,
            fontSize=20,
            textColor=colors.HexColor("#e63946"), # Cor do título Claro
            spaceAfter=20,
            fontName='Helvetica-Bold'
        )
        
        estilo_inspetor = ParagraphStyle(
            name='Inspetor',
            parent=styles['Normal'],
            alignment=TA_CENTER,
            fontSize=14,
            textColor=colors.white,
            spaceAfter=15
        )
        
        estilo_data = ParagraphStyle(
            name='DataCapa',
            parent=styles['Normal'],
            alignment=TA_CENTER,
            fontSize=12,
            textColor=colors.lightgrey,
            spaceAfter=10
        )
        
        estilo_info_inspecao = ParagraphStyle(
            name='InfoInspecao',
            parent=styles['Normal'],
            alignment=TA_CENTER,
            fontSize=12,
            textColor=colors.white,
            spaceAfter=5
        )
        
        estilo_nome_imagem = ParagraphStyle(
            name='NomeImagem',
            parent=styles['Heading3'],
            alignment=TA_CENTER,
            fontSize=14,
            textColor=colors.white,
            spaceAfter=8
        )
        
        estilo_obs = ParagraphStyle(
            name='Observacao',
            parent=styles['Normal'],
            alignment=TA_CENTER,
            fontSize=10,
            textColor=colors.lightgrey,
            spaceAfter=10
        )
        
        largura_max = 24 * cm
        altura_max = 14 * cm
        total = len(dados)
        
        # ============ PÁGINA DE CAPA ============
        # Título
        story.append(Paragraph("<b>CLARO - Relatório de Inspeção</b>", estilo_titulo))
        story.append(Spacer(1, 1 * cm))
        
        # Informações
        story.append(Paragraph(f"Inspetor: <b>{usuario_nome}</b>", estilo_inspetor))
        story.append(Spacer(1, 0.5 * cm))
        story.append(Paragraph(f"Data: <b>{datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}</b>", estilo_data))
        story.append(Spacer(1, 1 * cm))

        if localidade:
            story.append(Paragraph(f"<b>Localidade:</b> {localidade}", estilo_info_inspecao))
        if tipo_inspecao:
            story.append(Paragraph(f"<b>Tipo de Inspeção:</b> {tipo_inspecao}", estilo_info_inspecao))
        
        # Quebra de página após capa
        story.append(PageBreak())
        
        # ============ PÁGINAS COM IMAGENS ============
        for i, (caminho, nome) in enumerate(dados):
            # Nome da imagem
            story.append(Paragraph(f"<b>{nome}</b>", estilo_nome_imagem))
            story.append(Spacer(1, 0.2 * cm))
            
            # Obter dimensões da imagem e calcular proporção
            try:
                with PILImage.open(caminho) as img:
                    largura, altura = img.size
                    proporcao = min(largura_max / largura, altura_max / altura)
                    nova_largura = int(largura * proporcao)
                    nova_altura = int(altura * proporcao)
            except Exception as e:
                logger.error(f"Erro ao processar imagem {caminho}: {str(e)}")
                continue
            
            # Adicionar imagem ao PDF
            img_pdf = Image(caminho, width=nova_largura, height=nova_altura)
            img_pdf.hAlign = 'CENTER'
            story.append(img_pdf)
            story.append(Spacer(1, 0.3 * cm))

            # Quebra de página entre imagens
            if i < total - 1:
                story.append(PageBreak())

        if observacao:
            story.append(Spacer(1, 0.5 * cm))
            story.append(Paragraph("<b>Observação:</b>", estilo_nome_imagem))
            story.append(Paragraph(f"{observacao}", estilo_obs))
        
        # Gerar PDF
        doc.build(story, onFirstPage=draw_background, onLaterPages=draw_background)
        logger.info(f"PDF criado com sucesso: {caminho_pdf}")
    
    except Exception as e:
        logger.error(f"Erro ao criar PDF: {str(e)}", exc_info=True)
        raise

@claro_bp.route('/gerar-relatorio', methods=['POST'])
@login_required
def gerar_relatorio():
    """Gera relatório em PDF com os dados do checklist"""
    try:
        usuario_id = session['usuario_id']
        usuario = get_usuario_info(usuario_id)
        
        # Dados do request
        dados = request.get_json()
        titulo = dados.get('titulo', 'Relatório de Inspeção Claro')
        observacoes = dados.get('observacoes', '')
        imagens = dados.get('imagens', [])
        
        # Criar PDF
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4)
        story = []
        styles = getSampleStyleSheet()
        
        # Cabeçalho
        titulo_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#00cc6d'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        story.append(Paragraph(titulo, titulo_style))
        story.append(Spacer(1, 0.3*cm))
        
        # Informações do usuário
        info_text = f"<b>Inspetor:</b> {usuario['nome_completo']}<br/><b>Data:</b> {datetime.now().strftime('%d/%m/%Y %H:%M')}"
        story.append(Paragraph(info_text, styles['Normal']))
        story.append(Spacer(1, 0.5*cm))
        
        # Observações
        if observacoes:
            story.append(Paragraph("<b>Observações:</b>", styles['Heading3']))
            story.append(Paragraph(observacoes, styles['Normal']))
            story.append(Spacer(1, 0.5*cm))
        
        # Imagens
        if imagens:
            story.append(Paragraph("<b>Imagens da Inspeção:</b>", styles['Heading3']))
            story.append(Spacer(1, 0.2*cm))
            
            for img_name in imagens:
                try:
                    img_path = os.path.join(config.UPLOAD_FOLDER, 'claro', img_name)
                    if os.path.exists(img_path):
                        img = Image(img_path, width=15*cm, height=10*cm)
                        story.append(img)
                        story.append(Spacer(1, 0.3*cm))
                        story.append(PageBreak())
                except Exception as e:
                    logger.error(f"Erro ao adicionar imagem ao PDF: {e}")
        
        # Gerar PDF
        doc.build(story)
        buffer.seek(0)
        
        # Salvar referência no banco de dados
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO relatorios (usuario_id, modulo, nome_arquivo, observacao)
               VALUES (?, ?, ?, ?)''',
            (usuario_id, 'Claro', f'relatorio_claro_{datetime.now().strftime("%Y%m%d_%H%M%S")}.pdf', observacoes)
        )
        conn.commit()
        conn.close()
        
        logger.info(f"Relatório Claro gerado por usuário {usuario_id}")
        
        return send_file(
            buffer,
            mimetype='application/pdf',
            as_attachment=True,
            download_name=f'relatorio_claro_{datetime.now().strftime("%Y%m%d_%H%M%S")}.pdf'
        )
    
    except Exception as e:
        logger.error(f"Erro ao gerar relatório: {e}")
        return jsonify({'erro': f'Erro ao gerar relatório: {str(e)}'}), 500

@claro_bp.route('/relatorios')
@login_required
def listar_relatorios():
    """Lista relatórios gerados do usuário"""
    usuario_id = session['usuario_id']
    
    conn = get_db_connection()
    relatorios = conn.execute(
        'SELECT * FROM relatorios WHERE usuario_id = ? AND modulo = ? ORDER BY data_geracao DESC',
        (usuario_id, 'Claro')
    ).fetchall()
    conn.close()
    
    return jsonify({
        'relatorios': [dict(r) for r in relatorios]
    })

@claro_bp.route('/api/dados')
@login_required
def api_dados():
    """API para obter dados do módulo Claro"""
    usuario_id = session['usuario_id']
    usuario = get_usuario_info(usuario_id)
    
    conn = get_db_connection()
    relatorios = conn.execute(
        'SELECT COUNT(*) as total FROM relatorios WHERE usuario_id = ? AND modulo = ?',
        (usuario_id, 'Claro')
    ).fetchone()
    conn.close()
    
    return jsonify({
        'modulo': 'Claro',
        'usuario': usuario['nome_completo'],
        'relatorios_gerados': relatorios['total']
    })
