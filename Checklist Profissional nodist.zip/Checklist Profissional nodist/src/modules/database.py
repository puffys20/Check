"""
Gerenciamento centralizado do banco de dados SQLite
"""
import sqlite3
import logging
from config import config
from functools import wraps
from flask import session, redirect, url_for

logger = logging.getLogger(__name__)

def get_db_connection():
    """Cria e retorna uma conexão com o banco de dados"""
    conn = sqlite3.connect(config.DATABASE, timeout=30.0, check_same_thread=False)
    conn.execute('PRAGMA foreign_keys = ON')
    conn.execute('PRAGMA journal_mode = WAL')
    conn.execute('PRAGMA synchronous = NORMAL')
    conn.execute('PRAGMA cache_size = -64000')
    conn.row_factory = sqlite3.Row
    conn.isolation_level = None  # Autocommit mode
    return conn

def _run_migrations(cursor):
    """Executa migrações simples no banco de dados, como adicionar colunas."""
    try:
        cursor.execute("PRAGMA table_info(usuarios)")
        columns = [col['name'] for col in cursor.fetchall()]

        if 'is_admin' not in columns:
            cursor.execute("ALTER TABLE usuarios ADD COLUMN is_admin INTEGER DEFAULT 0")
            logger.info("MIGRAÇÃO: Coluna 'is_admin' adicionada à tabela 'usuarios'.")

        if 'foto_perfil' not in columns:
            cursor.execute("ALTER TABLE usuarios ADD COLUMN foto_perfil TEXT")
            logger.info("MIGRAÇÃO: Coluna 'foto_perfil' adicionada à tabela 'usuarios'.")

    except Exception as e:
        logger.error(f"Erro durante a migração do banco de dados: {e}")
        raise

def init_db():
    """Inicializa o banco de dados com as tabelas necessárias"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Tabela de usuários
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome_completo TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                senha TEXT NOT NULL,
                departamento TEXT,
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ativo INTEGER DEFAULT 1,
                is_admin INTEGER DEFAULT 0,
                foto_perfil TEXT
            )
        ''')
        
        # Tabela de relatórios (Claro e Cisco)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS relatorios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER NOT NULL,
                modulo TEXT NOT NULL,
                nome_arquivo TEXT NOT NULL,
                observacao TEXT,
                data_geracao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
            )
        ''')
        
        # Tabela de inspeções de salas
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS inspecoes_salas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER NOT NULL,
                sala_id TEXT NOT NULL,
                sala_nome TEXT,
                cidade TEXT,
                status TEXT,
                observacoes TEXT,
                data_inspecao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
            )
        ''')
        
        # Tabela de eventos do sistema
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS eventos_sistema (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER NOT NULL,
                tipo_evento TEXT NOT NULL,
                detalhe TEXT,
                data_evento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
            )
        ''')
        
        # Executar migrações para garantir que a estrutura esteja atualizada
        _run_migrations(cursor)
        
        conn.commit()
        logger.info(f"[OK] Banco de dados inicializado com sucesso em: {config.DATABASE}")
        
    except Exception as e:
        logger.error(f"Erro ao inicializar banco de dados: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

def login_required(f):
    """Decorator para proteger rotas que requerem login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

def get_usuario_info(usuario_id):
    """Obtém informações do usuário"""
    conn = get_db_connection()
    usuario = conn.execute(
        'SELECT * FROM usuarios WHERE id = ? AND ativo = 1', 
        (usuario_id,)
    ).fetchone()
    conn.close()
    return dict(usuario) if usuario else None

def verificar_email_exists(email, exclude_id=None):
    """Verifica se um email já está cadastrado"""
    conn = get_db_connection()
    query = 'SELECT id FROM usuarios WHERE email = ?'
    params = [email]
    
    if exclude_id:
        query += ' AND id != ?'
        params.append(exclude_id)
    
    result = conn.execute(query, params).fetchone()
    conn.close()
    return result is not None
