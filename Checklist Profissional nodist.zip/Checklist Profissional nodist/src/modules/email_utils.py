# -*- coding: utf-8 -*-
"""
Utilitário para envio de emails
"""
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.utils import formatdate
from email import encoders
import os
from config import config
import logging

logger = logging.getLogger(__name__)

def enviar_email_com_anexo(destinatario, assunto, corpo, arquivo_path=None, arquivo_nome=None):
    """
    Envia email com opcional anexo
    
    Args:
        destinatario: email do destinatário
        assunto: assunto do email
        corpo: corpo do email em HTML
        arquivo_path: caminho do arquivo a anexar (opcional)
        arquivo_nome: nome do arquivo anexado (opcional)
    
    Returns:
        dict com sucesso e mensagem
    """
    try:
        # Validar configurações
        if not config.MAIL_USERNAME or not config.MAIL_PASSWORD:
            return {
                'sucesso': False,
                'mensagem': 'Email não configurado. Verifique MAIL_USERNAME e MAIL_PASSWORD'
            }
        
        # Criar mensagem
        msg = MIMEMultipart('alternative')
        msg['From'] = config.MAIL_DEFAULT_SENDER
        msg['To'] = destinatario
        msg['Subject'] = assunto
        msg['Date'] = formatdate(localtime=True)
        
        # Adicionar corpo em HTML
        parte_html = MIMEText(corpo, 'html', 'utf-8')
        msg.attach(parte_html)
        
        # Adicionar anexo se fornecido
        if arquivo_path and os.path.exists(arquivo_path):
            try:
                with open(arquivo_path, 'rb') as anexo_file:
                    parte = MIMEBase('application', 'octet-stream')
                    parte.set_payload(anexo_file.read())
                    encoders.encode_base64(parte)
                    parte.add_header('Content-Disposition', 'attachment', 
                                   filename=arquivo_nome or os.path.basename(arquivo_path))
                    msg.attach(parte)
            except Exception as e:
                logger.warning(f"Erro ao anexar arquivo: {e}")
                # Continuar enviando mesmo sem anexo
        
        # Conectar e enviar
        with smtplib.SMTP(config.MAIL_SERVER, config.MAIL_PORT, timeout=10) as server:
            if config.MAIL_USE_TLS:
                server.starttls()
            
            server.login(config.MAIL_USERNAME, config.MAIL_PASSWORD)
            server.send_message(msg)
        
        logger.info(f"Email enviado para {destinatario}")
        return {
            'sucesso': True,
            'mensagem': 'Email enviado com sucesso'
        }
    
    except smtplib.SMTPAuthenticationError:
        logger.error("Erro de autenticação SMTP")
        return {
            'sucesso': False,
            'mensagem': 'Erro ao autenticar no servidor de email'
        }
    except smtplib.SMTPException as e:
        logger.error(f"Erro SMTP: {e}")
        return {
            'sucesso': False,
            'mensagem': f'Erro ao enviar email: {str(e)}'
        }
    except Exception as e:
        logger.error(f"Erro ao enviar email: {e}")
        return {
            'sucesso': False,
            'mensagem': f'Erro ao enviar email: {str(e)}'
        }

def enviar_screenshot_salas(usuario_email, tab_tipo, dados_screenshot):
    """
    Envia screenshot da página de salas por email
    
    Args:
        usuario_email: email do usuário
        tab_tipo: tipo de aba ('videoconference' ou 'cisco')
        dados_screenshot: dict com imageData (base64)
    
    Returns:
        dict com resultado
    """
    try:
        from datetime import datetime
        import base64
        import os
        
        # Criar pasta temporária se não existir
        temp_folder = os.path.join(os.path.dirname(__file__), '..', 'temp_screenshots')
        os.makedirs(temp_folder, exist_ok=True)
        
        # Gerar nome do arquivo com timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        tab_nome = 'Videoconferência' if tab_tipo == 'videoconference' else 'Cisco'
        arquivo_nome = f"screenshot_{tab_nome}_{timestamp}.png"
        arquivo_path = os.path.join(temp_folder, arquivo_nome)
        
        # Decodificar imagem base64 e salvar
        if 'imageData' in dados_screenshot:
            image_data = dados_screenshot['imageData']
            # Remover prefixo data:image/png;base64, se existir
            if ',' in image_data:
                image_data = image_data.split(',')[1]
            
            with open(arquivo_path, 'wb') as f:
                f.write(base64.b64decode(image_data))
        
        # Preparar corpo do email
        assunto = f"Screenshot - {tab_nome} - {timestamp}"
        corpo = f"""
        <html>
            <body style="font-family: Arial, sans-serif;">
                <h2>Screenshot da Página: {tab_nome}</h2>
                <p><strong>Data/Hora:</strong> {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</p>
                <p>Screenshot em anexo.</p>
                <hr>
                <p style="color: #666; font-size: 12px;">
                    Checklist Profissional - Sistema de Inspeção
                </p>
            </body>
        </html>
        """
        
        # Enviar email
        resultado = enviar_email_com_anexo(
            usuario_email,
            assunto,
            corpo,
            arquivo_path,
            arquivo_nome
        )
        
        # Limpar arquivo temporário
        try:
            if os.path.exists(arquivo_path):
                os.remove(arquivo_path)
        except:
            pass
        
        return resultado
    
    except Exception as e:
        logger.error(f"Erro ao enviar screenshot: {e}")
        return {
            'sucesso': False,
            'mensagem': f'Erro ao processar screenshot: {str(e)}'
        }
