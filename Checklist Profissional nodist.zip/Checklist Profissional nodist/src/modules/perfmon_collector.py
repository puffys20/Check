# -*- coding: utf-8 -*-
"""
Módulo para coletar métricas de performance via psutil.
Coleta dados reais de CPU, Memória e Disco em tempo real.
"""
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class PerfmonCollector:
    """Coleta dados de performance do Windows/Linux/Mac via psutil."""
    
    def __init__(self):
        # Não fazer import global - fazer dinamicamente em cada função
        pass
    
    def get_cpu_usage(self):
        """Retorna o uso de CPU em percentual."""
        try:
            import psutil
            # Coleta com intervalo de 0.1 segundo
            cpu_percent = psutil.cpu_percent(interval=0.1)
            logger.debug(f"CPU Usage: {cpu_percent}%")
            return cpu_percent
        except ImportError:
            logger.error("psutil não instalado! Execute: pip install psutil")
            return 0
        except Exception as e:
            logger.error(f"Erro ao coletar CPU: {e}")
            return 0
    
    def get_memory_usage(self):
        """Retorna o uso de memória em percentual."""
        try:
            import psutil
            mem = psutil.virtual_memory()
            logger.debug(f"Memory Usage: {mem.percent}%")
            return mem.percent
        except ImportError:
            logger.error("psutil não instalado! Execute: pip install psutil")
            return 0
        except Exception as e:
            logger.error(f"Erro ao coletar memória: {e}")
            return 0
    
    def get_disk_usage(self, path='C:\\'):
        """Retorna o uso de disco em percentual."""
        try:
            import psutil
            disk = psutil.disk_usage(path)
            logger.debug(f"Disk Usage ({path}): {disk.percent}%")
            return disk.percent
        except ImportError:
            logger.error("psutil não instalado! Execute: pip install psutil")
            return 0
        except Exception as e:
            logger.error(f"Erro ao coletar disco: {e}")
            return 0
    
    def get_all_metrics(self):
        """Retorna todos os métricas de performance."""
        metrics = {
            'cpu': round(self.get_cpu_usage(), 2),
            'memory': round(self.get_memory_usage(), 2),
            'disk': round(self.get_disk_usage(), 2),
            'timestamp': datetime.now().isoformat()
        }
        
        logger.debug(f"Perfmon Metrics: {metrics}")
        return metrics
    
    def get_node_metrics(self, node_name):
        """Retorna métricas para um nó específico."""
        metrics = self.get_all_metrics()
        return {
            'node': node_name,
            'cpu': metrics['cpu'],
            'memory': metrics['memory'],
            'disk': metrics['disk']
        }


# Instância global para uso rápido
perfmon = PerfmonCollector()
