# -*- coding: utf-8 -*-
"""
Módulo para coletar dados de performance do CUCM executando um script .bat externo.
"""
import os
import logging
import subprocess
import random

logger = logging.getLogger(__name__)

class RTMTCollector:
    def __init__(self):
        # O caminho para o seu script .bat.
        # Coloque o script na raiz do projeto ou em um local conhecido.
        self.script_path = os.path.join(os.path.dirname(__file__), '..', 'coletar_dados_cucm.bat')
        self.data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')

        if not os.path.exists(self.script_path):
            raise FileNotFoundError(f"Script coletor não encontrado em: {self.script_path}")
            
        # Garante que o diretório de dados exista
        os.makedirs(self.data_dir, exist_ok=True)
        logger.info(f"Cliente RTMT (via script .bat) inicializado. Script: {self.script_path}")

    def _read_data_file(self, filename, default="0"):
        """Lê um valor de um arquivo de dados, com um valor padrão em caso de erro."""
        try:
            with open(os.path.join(self.data_dir, filename), 'r') as f:
                return f.read().strip()
        except FileNotFoundError:
            logger.warning(f"Arquivo de dados '{filename}' não encontrado. Usando valor padrão.")
            return default
        except Exception as e:
            logger.error(f"Erro ao ler o arquivo '{filename}': {e}")
            return default

    def get_perfmon_data(self):
        """
        Executa o script .bat e depois lê os arquivos de saída para montar os dados.
        """
        try:
            logger.info(f"Executando script externo: {self.script_path}")
            # Executa o script .bat e espera ele terminar.
            # O `capture_output=True` e `text=True` ajudam a depurar, vendo a saída do script.
            result = subprocess.run([self.script_path], check=True, capture_output=True, text=True, shell=True)
            logger.info(f"Script executado com sucesso. Saída: {result.stdout}")

            # Agora, lê os arquivos que o script .bat gerou.
            # Esta parte é um exemplo, você precisará ajustar os nomes dos arquivos
            # e como os dados são lidos (parsing) de acordo com o que seu script gera.
            dados_coletados = {
                'clusterHealth': [
                    { 'id': 'pub', 'name': 'Publisher', 'cpu': int(self._read_data_file('pub_cpu.txt')), 'memory': int(self._read_data_file('pub_mem.txt')), 'disk': int(self._read_data_file('pub_disk.txt')) },
                    { 'id': 'sub1', 'name': 'Subscriber 1', 'cpu': int(self._read_data_file('sub1_cpu.txt')), 'memory': int(self._read_data_file('sub1_mem.txt')), 'disk': int(self._read_data_file('sub1_disk.txt')) }
                ],
                'callVolume': {
                    'labels': ['-60m', '-50m', '-40m', '-30m', '-20m', '-10m', 'Agora'],
                    'data': [random.randint(20, 150) for _ in range(7)] # Simulado por enquanto
                },
                'phoneStatus': {
                    'registered': int(self._read_data_file('phones_registered.txt')),
                    'unregistered': int(self._read_data_file('phones_unregistered.txt')),
                    'partial': int(self._read_data_file('phones_partial.txt', default="0"))
                },
                'trunkStatus': [
                    { 'name': 'Trunk-Claro-SP', 'status': 'Ativo' },
                    { 'name': 'Trunk-EMBRATEL-RJ', 'status': 'Ativo' },
                    { 'name': 'Trunk-Claro-BSB', 'status': 'Inativo' }
                ], # Simulado por enquanto
                'mediaResources': {
                    'cfb': int(self._read_data_file('resources_cfb.txt')),
                    'xcoder': int(self._read_data_file('resources_xcoder.txt')),
                    'mtp': int(self._read_data_file('resources_mtp.txt'))
                }
            }
            
            return {'sucesso': True, 'dados': dados_coletados}

        except subprocess.CalledProcessError as e:
            logger.error(f"Erro ao executar o script .bat: {e.stderr}", exc_info=True)
            return {'sucesso': False, 'mensagem': f"O script coletor falhou: {e.stderr}"}
        except Exception as e:
            logger.error(f"Erro inesperado ao processar dados do script: {e}", exc_info=True)
            return {'sucesso': False, 'mensagem': f"Erro ao processar dados: {str(e)}"}