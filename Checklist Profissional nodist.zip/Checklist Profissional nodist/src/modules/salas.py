# -*- coding: utf-8 -*-
"""
Blueprint para Checklist de Salas
"""
from flask import Blueprint, render_template, request, jsonify, session
from modules.database import login_required, get_usuario_info, get_db_connection
from modules.email_utils import enviar_screenshot_salas
from config import config
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

salas_bp = Blueprint('salas', __name__, url_prefix='/salas')

@salas_bp.route('/')
@login_required
def index():
    """Página inicial do módulo Salas"""
    usuario = get_usuario_info(session['usuario_id'])
    conn = get_db_connection()
    
    # Busca estatísticas reais do banco de dados
    stats = {
        'ativas': conn.execute("SELECT COUNT(*) FROM inspecoes_salas WHERE status = 'Ativo'").fetchone()[0],
        'pendentes': conn.execute("SELECT COUNT(*) FROM inspecoes_salas WHERE status = 'Pendente'").fetchone()[0],
        'total': conn.execute("SELECT COUNT(*) FROM inspecoes_salas").fetchone()[0]
    }
    conn.close()
    
    return render_template(
        'modulos/salas/index.html',
        usuario=usuario,
        stats=stats,
        outlook_to=config.OUTLOOK_TO or (usuario.get('email') if usuario else ''),
        outlook_cc=config.OUTLOOK_CC,
    )


@salas_bp.route('/api/screenshot', methods=['POST'])
@login_required
def api_screenshot():
    """Recebe o screenshot do frontend e envia por email"""
    try:
        dados = request.get_json()
        if not dados or 'imageData' not in dados:
            return jsonify({'sucesso': False, 'mensagem': 'Dados da imagem não recebidos.'}), 400

        usuario = get_usuario_info(session['usuario_id'])
        if not usuario or not usuario.get('email'):
            return jsonify({'sucesso': False, 'mensagem': 'Usuário não encontrado ou sem email.'}), 404

        resultado = enviar_screenshot_salas(
            usuario_email=usuario['email'],
            tab_tipo=dados.get('tipo', 'salas'),
            dados_screenshot=dados
        )
        
        return jsonify(resultado)

    except Exception as e:
        logger.error(f"Erro na API de screenshot: {e}", exc_info=True)
        return jsonify({'sucesso': False, 'mensagem': 'Erro interno no servidor.'}), 500

@salas_bp.route('/api/inspecoes')
@login_required
def get_inspecoes():
    """Retorna todas as inspeções de salas"""
    try:
        conn = get_db_connection()
        inspecoes = conn.execute('SELECT * FROM inspecoes_salas ORDER BY data_inspecao DESC').fetchall()
        conn.close()
        return jsonify({'sucesso': True, 'inspecoes': [dict(i) for i in inspecoes]})
    except Exception as e:
        logger.error(f"Erro ao buscar inspeções: {e}", exc_info=True)
        return jsonify({'sucesso': False, 'mensagem': 'Erro interno ao buscar dados.'}), 500

@salas_bp.route('/api/inspecoes/<item_id>')
@login_required
def get_inspecoes_por_item(item_id):
    """Retorna o histórico de inspeções por dia ou por mês."""
    try:
        dia = request.args.get('dia')
        mes = request.args.get('mes')
        query = 'SELECT * FROM inspecoes_salas WHERE sala_id = ?'
        params = [item_id]

        if dia:
            try:
                inicio = datetime.strptime(dia, '%Y-%m-%d')
            except ValueError:
                return jsonify({'sucesso': False, 'mensagem': 'Dia inválido. Use o formato AAAA-MM-DD.'}), 400

            fim = inicio + timedelta(days=1)
            query += ' AND data_inspecao >= ? AND data_inspecao < ?'
            params.extend((inicio.strftime('%Y-%m-%d %H:%M:%S'), fim.strftime('%Y-%m-%d %H:%M:%S')))
        elif mes:
            try:
                inicio = datetime.strptime(mes, '%Y-%m')
            except ValueError:
                return jsonify({'sucesso': False, 'mensagem': 'Mês inválido. Use o formato AAAA-MM.'}), 400

            if inicio.month == 12:
                fim = inicio.replace(year=inicio.year + 1, month=1)
            else:
                fim = inicio.replace(month=inicio.month + 1)

            query += ' AND data_inspecao >= ? AND data_inspecao < ?'
            params.extend((inicio.strftime('%Y-%m-%d %H:%M:%S'), fim.strftime('%Y-%m-%d %H:%M:%S')))

        conn = get_db_connection()
        inspecoes = conn.execute(query + ' ORDER BY data_inspecao DESC', params).fetchall()
        conn.close()
        return jsonify({'sucesso': True, 'inspecoes': [dict(i) for i in inspecoes]})
    except Exception as e:
        logger.error(f"Erro ao buscar histórico do item {item_id}: {e}", exc_info=True)
        return jsonify({'sucesso': False, 'mensagem': 'Erro interno ao buscar histórico.'}), 500

@salas_bp.route('/api/registrar-inspecao', methods=['POST'])
@login_required
def registrar_inspecao():
    """Registra uma nova inspeção no banco de dados"""
    try:
        data = request.get_json()
        conn = get_db_connection()
        conn.execute("INSERT INTO inspecoes_salas (usuario_id, sala_id, sala_nome, status, observacoes) VALUES (?, ?, ?, ?, ?)",
                     (session['usuario_id'], data['item_id'], data['item_nome'], data['status'], data['observacoes']))
        conn.commit()
        conn.close()
        return jsonify({'sucesso': True, 'mensagem': 'Inspeção registrada com sucesso!'})
    except Exception as e:
        logger.error(f"Erro ao registrar inspeção: {e}", exc_info=True)
        return jsonify({'sucesso': False, 'mensagem': 'Erro interno ao registrar inspeção.'}), 500