/**
 * Dashboard Advanced Metrics - Versão Simplificada e Testada
 * Métricas Avançadas de Monitoramento
 */

class AdvancedMetrics {
    constructor() {
        this.lastUpdate = new Date();
        console.log('✅ AdvancedMetrics inicializado');
    }

    // ==================== HELPERS ====================
    renderCard(icon, title, value, unit, status) {
        const colors = {
            'excelente': '#28a745',
            'bom': '#ffc107',
            'aceitavel': '#ff9800',
            'ruim': '#dc3545'
        };
        const color = colors[status] || '#0099ff';
        
        return `
            <div class="metric-card-advanced" style="border-left: 4px solid ${color};">
                <div class="metric-icon">${icon}</div>
                <div class="metric-title">${title}</div>
                <div class="metric-value" style="color: ${color};">${value}</div>
                <div class="metric-unit">${unit}</div>
            </div>
        `;
    }

    // ==================== 1. QUALIDADE DE VOZ ====================
    renderVoiceQuality() {
        const mos = (4.2).toFixed(2);
        const latency = 45;
        const jitter = 8;
        const packetLoss = 0.2;

        return `
            <div class="metrics-section">
                <h3 class="section-title">🎙️ Qualidade de Voz</h3>
                <div class="metrics-grid">
                    ${this.renderCard('📊', 'MOS Score', mos, 'de 5', 'excelente')}
                    ${this.renderCard('📶', 'Latência', latency + 'ms', 'ideal <50ms', 'excelente')}
                    ${this.renderCard('📡', 'Jitter', jitter + 'ms', 'ideal <20ms', 'excelente')}
                    ${this.renderCard('📉', 'Packet Loss', packetLoss + '%', 'ideal <0.5%', 'excelente')}
                </div>
            </div>
        `;
    }

    // ==================== 2. UTILIZAÇÃO DE BANDA ====================
    renderBandwidth() {
        const usage = 650;
        const total = 1000;
        const percent = 65;

        return `
            <div class="metrics-section">
                <h3 class="section-title">🌐 Utilização de Banda</h3>
                <div class="bandwidth-bar-container">
                    <div class="bandwidth-bar">
                        <div class="bandwidth-used" style="width: ${percent}%; background: linear-gradient(90deg, #0099ff, #00cc6d);">
                            <span>${usage} Mbps</span>
                        </div>
                    </div>
                    <div class="bandwidth-labels">
                        <span>Voz: 400 Mbps</span>
                        <span>Vídeo: 150 Mbps</span>
                        <span>Dados: 100 Mbps</span>
                        <span>Disponível: 350 Mbps</span>
                    </div>
                </div>
            </div>
        `;
    }

    // ==================== 3. DISPOSITIVOS POR MODELO ====================
    renderDevicesByModel() {
        const devices = [
            { model: 'Cisco 8841', count: 42, percentage: 33.6 },
            { model: 'Cisco 7821', count: 28, percentage: 22.4 },
            { model: 'Cisco 8811', count: 18, percentage: 14.4 },
            { model: 'Cisco 7841', count: 15, percentage: 12.0 },
            { model: 'Cisco 6821', count: 12, percentage: 9.6 },
            { model: 'Cisco 6851', count: 10, percentage: 8.0 }
        ];

        return `
            <div class="metrics-section">
                <h3 class="section-title">📱 Dispositivos por Modelo</h3>
                <div class="devices-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Modelo</th>
                                <th>Quantidade</th>
                                <th>Status</th>
                                <th>%</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${devices.map(d => `
                                <tr>
                                    <td><strong>${d.model}</strong></td>
                                    <td>${d.count}</td>
                                    <td><span class="status-badge ativo">online</span></td>
                                    <td>${d.percentage}%</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    // ==================== 4. CHAMADAS POR TIPO ====================
    renderCallsByType() {
        return `
            <div class="metrics-section">
                <h3 class="section-title">📞 Chamadas por Tipo</h3>
                <div class="calls-breakdown">
                    ${this.renderCard('📍', 'Local', '3500', '65%', 'excelente')}
                    ${this.renderCard('🗺️', 'Longa Distância', '1200', '20%', 'bom')}
                    ${this.renderCard('🌍', 'Internacional', '600', '10%', 'aceitavel')}
                    ${this.renderCard('👥', 'Conferência', '300', '5%', 'bom')}
                </div>
            </div>
        `;
    }

    // ==================== 5. DEPARTAMENTOS ====================
    renderDepartments() {
        const depts = [
            { name: 'TI', total: 18, online: 18, offline: 0, percent: 100 },
            { name: 'Vendas', total: 35, online: 33, offline: 2, percent: 94.3 },
            { name: 'Atendimento', total: 28, online: 26, offline: 2, percent: 92.9 },
            { name: 'Financeiro', total: 12, online: 12, offline: 0, percent: 100 },
            { name: 'RH', total: 8, online: 8, offline: 0, percent: 100 },
            { name: 'Administrativo', total: 15, online: 14, offline: 1, percent: 93.3 }
        ];

        return `
            <div class="metrics-section">
                <h3 class="section-title">🏢 Status por Departamento</h3>
                <div class="departments-grid">
                    ${depts.map(d => `
                        <div class="dept-card">
                            <div class="dept-name">${d.name}</div>
                            <div class="dept-stats">
                                <div class="dept-stat">
                                    <span class="stat-label">Total:</span>
                                    <span class="stat-value">${d.total}</span>
                                </div>
                                <div class="dept-stat" style="color: #28a745;">
                                    <span class="stat-label">Online:</span>
                                    <span class="stat-value">${d.online}</span>
                                </div>
                                <div class="dept-stat" style="color: #dc3545;">
                                    <span class="stat-label">Offline:</span>
                                    <span class="stat-value">${d.offline}</span>
                                </div>
                            </div>
                            <div class="dept-percentage">${d.percent}%</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // ==================== 6. TOP USUÁRIOS ====================
    renderTopUsers() {
        const users = [
            { name: 'João Silva', ext: '1001', calls: 127, duration: 4820 },
            { name: 'Maria Santos', ext: '1002', calls: 114, duration: 4105 },
            { name: 'Pedro Costa', ext: '1003', calls: 98, duration: 3540 },
            { name: 'Ana Paula', ext: '1004', calls: 87, duration: 3145 },
            { name: 'Carlos Oliveira', ext: '1005', calls: 76, duration: 2745 }
        ];

        return `
            <div class="metrics-section">
                <h3 class="section-title">👥 Top Usuários</h3>
                <div class="top-users-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Usuário</th>
                                <th>Ramal</th>
                                <th>Chamadas</th>
                                <th>Duração</th>
                                <th>Média</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${users.map((u, i) => {
                                const avgDuration = Math.floor(u.duration / u.calls);
                                return `
                                    <tr>
                                        <td><strong>${i + 1}. ${u.name}</strong></td>
                                        <td>${u.ext}</td>
                                        <td>${u.calls}</td>
                                        <td>${Math.floor(u.duration / 60)}m</td>
                                        <td>${avgDuration}s</td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    // ==================== 7. PERFORMANCE DA API ====================
    renderAPIPerformance() {
        return `
            <div class="metrics-section">
                <h3 class="section-title">⚡ Performance da API</h3>
                <div class="metrics-grid">
                    ${this.renderCard('⏱️', 'Resposta Média', '145ms', 'tempo', 'excelente')}
                    ${this.renderCard('📊', 'P95', '320ms', 'percentil', 'bom')}
                    ${this.renderCard('📈', 'P99', '780ms', 'percentil', 'aceitavel')}
                    ${this.renderCard('✅', 'Uptime', '99.8%', 'disponibilidade', 'excelente')}
                </div>
                <div style="margin-top: 15px; padding: 10px; background: var(--bg-tertiary); border-radius: 6px; font-size: 12px;">
                    <span>Total de Requisições: <strong>8.5K</strong> | </span>
                    <span>Falhas: <strong>12 (0.14%)</strong></span>
                </div>
            </div>
        `;
    }

    // ==================== RENDERIZAR TUDO ====================
    renderAll() {
        try {
            const html = `
                ${this.renderVoiceQuality()}
                ${this.renderBandwidth()}
                ${this.renderDevicesByModel()}
                ${this.renderCallsByType()}
                ${this.renderDepartments()}
                ${this.renderTopUsers()}
                ${this.renderAPIPerformance()}
            `;
            console.log('✅ renderAll() completado com sucesso');
            return html;
        } catch(e) {
            console.error('❌ Erro em renderAll():', e);
            return '<div style="color: red; padding: 20px;">Erro ao renderizar métricas avançadas</div>';
        }
    }
}

// Instanciar globalmente
window.advancedMetrics = new AdvancedMetrics();
console.log('✅ window.advancedMetrics disponível');

// AUTO-RENDER quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    console.log('🔄 [AUTO-RENDER] DOMContentLoaded - tentando renderizar');
    setTimeout(() => {
        const container = document.getElementById('advancedMetricsContainer');
        if (container && !container.innerHTML) {
            console.log('🔄 [AUTO-RENDER] Container vazio, renderizando automaticamente...');
            const html = window.advancedMetrics.renderAll();
            container.innerHTML = html;
            console.log('✅ [AUTO-RENDER] Renderizado com sucesso!');
        }
    }, 500);
});

// Também renderizar quando document.body estiver disponível
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoRenderAdvancedMetrics);
} else {
    // Se o documento já foi carregado
    autoRenderAdvancedMetrics();
}

function autoRenderAdvancedMetrics() {
    setTimeout(() => {
        const container = document.getElementById('advancedMetricsContainer');
        if (container && !container.innerHTML) {
            console.log('🔄 [AUTO-RENDER-FALLBACK] Renderizando métricas avançadas...');
            const html = window.advancedMetrics.renderAll();
            container.innerHTML = html;
            console.log('✅ [AUTO-RENDER-FALLBACK] Sucesso!');
        }
    }, 1000);
}
