/**
 * Dashboard Advanced Metrics - Métricas Avançadas de Monitoramento
 * Expande o monitoramento com métricas profundas e detalhadas
 */

class AdvancedMetrics {
    constructor() {
        this.metrics = {};
        this.history = [];
        this.updateInterval = 60000; // 60 segundos
    }

    // ==================== QUALIDADE DE VOZ ====================
    /**
     * Calcula MOS Score (Mean Opinion Score - 1 a 5)
     * Baseado em latência, jitter e packet loss
     */
    calculateMOS(latency, jitter, packetLoss) {
        // Fórmula adaptada ITU-T G.107
        let R = 93.2 - (latency / 40) - (jitter * 10) - (packetLoss * 2.5);
        
        // Converter R para MOS (1-5)
        let MOS;
        if (R < 0) MOS = 1;
        else if (R > 100) R = 100;
        MOS = 1 + 0.035 * R + 0.000007 * R * (R - 60) * (100 - R);
        
        return Math.min(5, Math.max(1, MOS)).toFixed(2);
    }

    /**
     * Retorna status de qualidade de voz
     */
    getVoiceQualityStatus(mos) {
        mos = parseFloat(mos);
        if (mos >= 4.0) return { status: 'Excelente', color: '#28a745', icon: '🟢' };
        if (mos >= 3.5) return { status: 'Bom', color: '#ffc107', icon: '🟡' };
        if (mos >= 3.0) return { status: 'Aceitável', color: '#ff9800', icon: '🟠' };
        return { status: 'Ruim', color: '#dc3545', icon: '🔴' };
    }

    // ==================== DISPOSITIVOS POR MODELO ====================
    /**
     * Agrupa dispositivos por modelo/tipo
     */
    getDevicesByModel(phoneStatus) {
        // Dados simulados - seria preenchido pela API real
        return {
            'Cisco 8841': { count: 42, status: 'online', percentage: 33.6 },
            'Cisco 7821': { count: 28, status: 'online', percentage: 22.4 },
            'Cisco 8811': { count: 18, status: 'online', percentage: 14.4 },
            'Cisco 7841': { count: 15, status: 'online', percentage: 12.0 },
            'Cisco 6821': { count: 12, status: 'online', percentage: 9.6 },
            'Cisco 6851': { count: 10, status: 'online', percentage: 8.0 }
        };
    }

    // ==================== UTILIZAÇÃO DE BANDA ====================
    /**
     * Simula utilização de banda em tempo real
     */
    getBandwidthUtilization() {
        return {
            total_capacity: 1000,  // Mbps
            current_usage: Math.floor(Math.random() * 650) + 100,  // 100-750 Mbps
            voice_calls: Math.floor(Math.random() * 400) + 50,
            video_calls: Math.floor(Math.random() * 150) + 20,
            data: Math.floor(Math.random() * 200) + 30,
            reserved: 100,
            available: 0  // Calculado abaixo
        };
    }

    // ==================== QUALIDADE DE REDE ====================
    /**
     * Métricas de qualidade de rede
     */
    getNetworkQuality() {
        return {
            packet_loss: (Math.random() * 2).toFixed(2),  // %
            jitter: Math.floor(Math.random() * 15) + 1,   // ms
            latency: Math.floor(Math.random() * 60) + 20,  // ms
            rtt: Math.floor(Math.random() * 80) + 30,      // ms
            dns_response: Math.floor(Math.random() * 100) + 10  // ms
        };
    }

    // ==================== ATIVIDADE POR HORÁRIO ====================
    /**
     * Simula padrão de chamadas por hora do dia
     */
    getActivityByHour() {
        const hours = [];
        for (let i = 8; i < 18; i++) {
            const baseActivity = Math.sin((i - 8) / 10 * Math.PI) * 300 + 200;
            hours.push({
                hour: `${i}:00`,
                calls: Math.floor(baseActivity + Math.random() * 100),
                duration: Math.floor(Math.random() * 300) + 180
            });
        }
        return hours;
    }

    // ==================== TOP USUÁRIOS ====================
    /**
     * Top usuários por volume de chamadas
     */
    getTopUsers() {
        return [
            { name: 'João Silva', extension: '1001', calls: 127, duration: 4820 },
            { name: 'Maria Santos', extension: '1002', calls: 114, duration: 4105 },
            { name: 'Pedro Costa', extension: '1003', calls: 98, duration: 3540 },
            { name: 'Ana Paula', extension: '1004', calls: 87, duration: 3145 },
            { name: 'Carlos Oliveira', extension: '1005', calls: 76, duration: 2745 }
        ];
    }

    // ==================== CHAMADAS POR TIPO ====================
    /**
     * Breakdown de chamadas por tipo
     */
    getCallsByType() {
        const total = Math.floor(Math.random() * 500) + 300;
        return {
            local: { count: Math.floor(total * 0.65), percentage: 65 },
            long_distance: { count: Math.floor(total * 0.20), percentage: 20 },
            international: { count: Math.floor(total * 0.10), percentage: 10 },
            conference: { count: Math.floor(total * 0.05), percentage: 5 },
            total: total
        };
    }

    // ==================== STATUS POR DEPARTAMENTO ====================
    /**
     * Agrega status de dispositivos por departamento
     */
    getStatusByDepartment() {
        return [
            { name: 'TI', total: 18, online: 18, offline: 0, percentage: 100 },
            { name: 'Financeiro', total: 12, online: 12, offline: 0, percentage: 100 },
            { name: 'Vendas', total: 35, online: 33, offline: 2, percentage: 94.3 },
            { name: 'Atendimento', total: 28, online: 26, offline: 2, percentage: 92.9 },
            { name: 'RH', total: 8, online: 8, offline: 0, percentage: 100 },
            { name: 'Administrativo', total: 15, online: 14, offline: 1, percentage: 93.3 }
        ];
    }

    // ==================== PERFORMANCE DA API ====================
    /**
     * Tempo de resposta da API de monitoramento
     */
    getAPIPerformance() {
        return {
            average_response_time: Math.floor(Math.random() * 300) + 50,  // ms
            p95_response_time: Math.floor(Math.random() * 500) + 200,     // ms
            p99_response_time: Math.floor(Math.random() * 1000) + 400,    // ms
            total_requests: Math.floor(Math.random() * 10000) + 5000,
            failed_requests: Math.floor(Math.random() * 50),
            uptime_percentage: (99.5 + Math.random() * 0.5).toFixed(2)
        };
    }

    // ==================== ALERTAS DE SAÚDE ====================
    /**
     * Gera alertas baseado em métricas
     */
    generateHealthAlerts(data) {
        const alerts = [];
        
        const quality = this.getNetworkQuality();
        
        if (quality.packet_loss > 1.0) {
            alerts.push({
                severity: 'warning',
                message: `Packet Loss alto: ${quality.packet_loss}%`,
                metric: 'packet_loss'
            });
        }
        
        if (quality.jitter > 20) {
            alerts.push({
                severity: 'warning',
                message: `Jitter elevado: ${quality.jitter}ms`,
                metric: 'jitter'
            });
        }

        return alerts;
    }

    // ==================== RENDER MÉTRICA GENÉRICA ====================
    /**
     * Renderiza card genérico de métrica
     */
    renderMetricCard(title, value, unit, status, icon) {
        const statusColors = {
            'excelente': '#28a745',
            'bom': '#ffc107',
            'aceitavel': '#ff9800',
            'ruim': '#dc3545',
            'neutro': '#0099ff'
        };

        const color = statusColors[status] || '#0099ff';

        return `
            <div class="metric-card-advanced" style="border-left: 4px solid ${color};">
                <div class="metric-icon">${icon}</div>
                <div class="metric-title">${title}</div>
                <div class="metric-value" style="color: ${color};">${value}</div>
                <div class="metric-unit">${unit}</div>
            </div>
        `;
    }

    // ==================== RENDER TODOS OS COMPONENTES ====================
    /**
     * Renderiza seção de Qualidade de Voz
     */
    renderVoiceQuality() {
        const quality = this.getNetworkQuality();
        const mos = this.calculateMOS(quality.latency, quality.jitter, parseFloat(quality.packet_loss));
        const status = this.getVoiceQualityStatus(mos);

        return `
            <div class="metrics-section">
                <h3 class="section-title">🎙️ Qualidade de Voz</h3>
                <div class="metrics-grid">
                    ${this.renderMetricCard('MOS Score', mos, 'de 5', status.status.toLowerCase(), status.icon)}
                    ${this.renderMetricCard('Latência', quality.latency + 'ms', 'ideal < 50ms', quality.latency < 50 ? 'excelente' : quality.latency < 100 ? 'bom' : 'ruim', '📶')}
                    ${this.renderMetricCard('Jitter', quality.jitter + 'ms', 'ideal < 20ms', quality.jitter < 20 ? 'excelente' : quality.jitter < 40 ? 'bom' : 'ruim', '📡')}
                    ${this.renderMetricCard('Packet Loss', quality.packet_loss + '%', 'ideal < 0.5%', parseFloat(quality.packet_loss) < 0.5 ? 'excelente' : parseFloat(quality.packet_loss) < 1 ? 'bom' : 'ruim', '📉')}
                </div>
            </div>
        `;
    }

    /**
     * Renderiza seção de Banda
     */
    renderBandwidth() {
        const bw = this.getBandwidthUtilization();
        const usage_percent = ((bw.current_usage / (bw.total_capacity - bw.reserved)) * 100).toFixed(1);
        bw.available = bw.total_capacity - bw.reserved - bw.current_usage;

        return `
            <div class="metrics-section">
                <h3 class="section-title">🌐 Utilização de Banda</h3>
                <div class="bandwidth-bar-container">
                    <div class="bandwidth-bar">
                        <div class="bandwidth-used" style="width: ${usage_percent}%; background: linear-gradient(90deg, #0099ff, #00cc6d);">
                            <span>${bw.current_usage} Mbps</span>
                        </div>
                    </div>
                    <div class="bandwidth-labels">
                        <span>Voz: ${bw.voice_calls} Mbps</span>
                        <span>Vídeo: ${bw.video_calls} Mbps</span>
                        <span>Dados: ${bw.data} Mbps</span>
                        <span>Disponível: ${bw.available} Mbps</span>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Renderiza seção de Dispositivos por Modelo
     */
    renderDevicesByModel() {
        const devices = this.getDevicesByModel();
        
        return `
            <div class="metrics-section">
                <h3 class="section-title">📱 Dispositivos por Modelo</h3>
                <div class="devices-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Modelo</th>
                                <th>Quantidade</th>
                                <th>Status</th>
                                <th>%</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${Object.entries(devices).map(([model, data]) => `
                                <tr>
                                    <td><strong>${model}</strong></td>
                                    <td>${data.count}</td>
                                    <td><span class="status-badge ativo">${data.status}</span></td>
                                    <td>${data.percentage}%</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    /**
     * Renderiza seção de Chamadas por Tipo
     */
    renderCallsByType() {
        const calls = this.getCallsByType();
        
        return `
            <div class="metrics-section">
                <h3 class="section-title">📞 Chamadas por Tipo</h3>
                <div class="calls-breakdown">
                    ${this.renderMetricCard('Local', calls.local.count, `${calls.local.percentage}%`, 'excelente', '📍')}
                    ${this.renderMetricCard('Longa Distância', calls.long_distance.count, `${calls.long_distance.percentage}%`, 'bom', '🗺️')}
                    ${this.renderMetricCard('Internacional', calls.international.count, `${calls.international.percentage}%`, 'aceitavel', '🌍')}
                    ${this.renderMetricCard('Conferência', calls.conference.count, `${calls.conference.percentage}%`, 'neutro', '👥')}
                </div>
            </div>
        `;
    }

    /**
     * Renderiza seção de Departamentos
     */
    renderDepartments() {
        const departments = this.getStatusByDepartment();
        
        return `
            <div class="metrics-section">
                <h3 class="section-title">🏢 Status por Departamento</h3>
                <div class="departments-grid">
                    ${departments.map(dept => `
                        <div class="dept-card">
                            <div class="dept-name">${dept.name}</div>
                            <div class="dept-stats">
                                <div class="dept-stat">
                                    <span class="stat-label">Total:</span>
                                    <span class="stat-value">${dept.total}</span>
                                </div>
                                <div class="dept-stat" style="color: #28a745;">
                                    <span class="stat-label">Online:</span>
                                    <span class="stat-value">${dept.online}</span>
                                </div>
                                <div class="dept-stat" style="color: #dc3545;">
                                    <span class="stat-label">Offline:</span>
                                    <span class="stat-value">${dept.offline}</span>
                                </div>
                            </div>
                            <div class="dept-percentage">${dept.percentage}%</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    /**
     * Renderiza seção de Top Usuários
     */
    renderTopUsers() {
        const users = this.getTopUsers();
        
        return `
            <div class="metrics-section">
                <h3 class="section-title">👥 Top Usuários</h3>
                <div class="top-users-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Usuário</th>
                                <th>Ramal</th>
                                <th>Chamadas</th>
                                <th>Duração</th>
                                <th>Média</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${users.map((user, idx) => {
                                const avgDuration = Math.floor(user.duration / user.calls);
                                return `
                                    <tr>
                                        <td><strong>${idx + 1}. ${user.name}</strong></td>
                                        <td>${user.extension}</td>
                                        <td>${user.calls}</td>
                                        <td>${Math.floor(user.duration / 60)}m</td>
                                        <td>${avgDuration}s</td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    /**
     * Renderiza seção de Performance da API
     */
    renderAPIPerformance() {
        const perf = this.getAPIPerformance();
        
        return `
            <div class="metrics-section">
                <h3 class="section-title">⚡ Performance da API</h3>
                <div class="metrics-grid">
                    ${this.renderMetricCard('Resposta Média', perf.average_response_time + 'ms', 'tempo', 'excelente', '⏱️')}
                    ${this.renderMetricCard('P95', perf.p95_response_time + 'ms', 'percentil', 'bom', '📊')}
                    ${this.renderMetricCard('P99', perf.p99_response_time + 'ms', 'percentil', 'aceitavel', '📈')}
                    ${this.renderMetricCard('Uptime', perf.uptime_percentage + '%', 'disponibilidade', 'excelente', '✅')}
                </div>
                <div style="margin-top: 15px; padding: 10px; background: var(--bg-tertiary); border-radius: 6px; font-size: 12px;">
                    <span>Total de Requisições: <strong>${perf.total_requests}</strong> | </span>
                    <span>Falhas: <strong>${perf.failed_requests}</strong></span>
                </div>
            </div>
        `;
    }

    /**
     * Renderiza tudo de uma vez
     */
    renderAll() {
        return `
            ${this.renderVoiceQuality()}
            ${this.renderBandwidth()}
            ${this.renderDevicesByModel()}
            ${this.renderCallsByType()}
            ${this.renderDepartments()}
            ${this.renderTopUsers()}
            ${this.renderAPIPerformance()}
        `;
    }
}

// Instanciar globalmente
window.advancedMetrics = new AdvancedMetrics();

// DEBUG: Confirmar que a classe foi instanciada
console.log('✅ AdvancedMetrics carregado e instanciado', window.advancedMetrics);
console.log('✅ renderAll() disponível:', typeof window.advancedMetrics.renderAll === 'function');
