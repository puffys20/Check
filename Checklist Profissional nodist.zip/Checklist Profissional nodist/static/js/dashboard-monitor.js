/**
 * Dashboard Monitor - Rastreia atualizações de gráficos
 * Permite verificar em tempo real se os gráficos estão sendo atualizados
 */

class DashboardMonitor {
    constructor() {
        this.updateLog = [];
        this.chartStatus = {};
        this.isMonitoring = false;
        this.maxLogEntries = 100;
        this.lastUpdateTime = null;
        this.totalUpdates = 0;
        this.errorCount = 0;
        
        // Elementos de monitoramento
        this.monitorContainer = null;
        this.createMonitorUI();
    }

    /**
     * Cria a interface de monitoramento
     */
    createMonitorUI() {
        // Botão flutuante para abrir monitor
        const floatingBtn = document.createElement('div');
        floatingBtn.id = 'dashboard-monitor-btn';
        floatingBtn.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            z-index: 9999;
            transition: all 0.3s ease;
        `;
        floatingBtn.innerHTML = '<i class="fas fa-chart-area"></i>';
        floatingBtn.addEventListener('click', () => this.toggleMonitor());
        floatingBtn.addEventListener('mouseover', (e) => {
            e.target.style.transform = 'scale(1.1)';
        });
        floatingBtn.addEventListener('mouseout', (e) => {
            e.target.style.transform = 'scale(1)';
        });
        document.body.appendChild(floatingBtn);

        // Painel de monitoramento
        this.monitorContainer = document.createElement('div');
        this.monitorContainer.id = 'dashboard-monitor-panel';
        this.monitorContainer.className = 'hidden';
        this.monitorContainer.style.cssText = `
            position: fixed;
            bottom: 80px;
            right: 20px;
            width: 500px;
            max-height: 600px;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
            z-index: 9998;
            display: flex;
            flex-direction: column;
            font-family: 'Courier New', monospace;
            font-size: 12px;
        `;
        this.monitorContainer.innerHTML = `
            <div style="
                padding: 12px;
                border-bottom: 1px solid var(--border-color);
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border-radius: 10px 10px 0 0;
            ">
                <div>
                    <div style="font-weight: bold; margin-bottom: 4px;">📊 Dashboard Monitor</div>
                    <div style="font-size: 11px; opacity: 0.9;">
                        Total: <span id="monitor-total-updates">0</span> | 
                        Erros: <span id="monitor-error-count" style="color: #ff6b6b;">0</span> | 
                        Status: <span id="monitor-status">Iniciando...</span>
                    </div>
                </div>
                <button id="monitor-close-btn" style="
                    background: rgba(255, 255, 255, 0.2);
                    border: none;
                    color: white;
                    cursor: pointer;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 14px;
                ">✕</button>
            </div>
            <div id="monitor-status-list" style="
                flex: 1;
                overflow-y: auto;
                padding: 12px;
                display: flex;
                flex-direction: column;
                gap: 8px;
            "></div>
            <div id="monitor-log" style="
                flex: 0 0 200px;
                overflow-y: auto;
                padding: 12px;
                border-top: 1px solid var(--border-color);
                background: var(--bg-tertiary);
                border-radius: 0 0 10px 10px;
            "></div>
        `;
        document.body.appendChild(this.monitorContainer);

        // Fechar monitor
        document.getElementById('monitor-close-btn').addEventListener('click', () => {
            this.toggleMonitor();
        });
    }

    /**
     * Alterna visibilidade do monitor
     */
    toggleMonitor() {
        this.monitorContainer.classList.toggle('hidden');
        if (!this.monitorContainer.classList.contains('hidden') && !this.isMonitoring) {
            this.startMonitoring();
        }
    }

    /**
     * Registra uma atualização de gráfico
     */
    logUpdate(chartName, status = 'success', details = '') {
        const timestamp = new Date().toLocaleTimeString('pt-BR', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

        this.totalUpdates++;
        this.lastUpdateTime = new Date();

        const logEntry = {
            timestamp,
            chart: chartName,
            status,
            details,
            time: new Date()
        };

        this.updateLog.push(logEntry);
        if (this.updateLog.length > this.maxLogEntries) {
            this.updateLog.shift();
        }

        // Atualizar status do gráfico
        if (!this.chartStatus[chartName]) {
            this.chartStatus[chartName] = {
                lastUpdate: timestamp,
                count: 0,
                errors: 0,
                status: 'Aguardando...'
            };
        }

        this.chartStatus[chartName].lastUpdate = timestamp;
        this.chartStatus[chartName].count++;
        this.chartStatus[chartName].status = status;

        if (status === 'error') {
            this.chartStatus[chartName].errors++;
            this.errorCount++;
        }

        this.updateMonitorDisplay();
    }

    /**
     * Atualiza a exibição do monitor
     */
    updateMonitorDisplay() {
        // Atualizar contadores
        document.getElementById('monitor-total-updates').textContent = this.totalUpdates;
        document.getElementById('monitor-error-count').textContent = this.errorCount;

        const statusEl = document.getElementById('monitor-status');
        const timeSinceUpdate = this.lastUpdateTime ? 
            Math.round((new Date() - this.lastUpdateTime) / 1000) : 0;
        
        if (timeSinceUpdate < 65) {
            statusEl.textContent = `✅ Ativo (${timeSinceUpdate}s)`;
            statusEl.style.color = '#28a745';
        } else if (timeSinceUpdate < 300) {
            statusEl.textContent = `⚠️  Atrasado (${timeSinceUpdate}s)`;
            statusEl.style.color = '#ffc107';
        } else {
            statusEl.textContent = `❌ Inativo (${timeSinceUpdate}s)`;
            statusEl.style.color = '#dc3545';
        }

        // Atualizar lista de status
        const statusList = document.getElementById('monitor-status-list');
        statusList.innerHTML = Object.entries(this.chartStatus)
            .sort((a, b) => new Date(b[1].lastUpdate) - new Date(a[1].lastUpdate))
            .map(([chartName, data]) => {
                const statusIcon = data.status === 'success' ? '✅' : 
                                 data.status === 'error' ? '❌' : '⏳';
                const errorBadge = data.errors > 0 ? 
                    `<span style="color: #ff6b6b; margin-left: auto;">${data.errors} erros</span>` : '';
                
                return `
                    <div style="
                        background: var(--bg-tertiary);
                        padding: 8px;
                        border-radius: 4px;
                        border-left: 3px solid ${
                            data.status === 'success' ? '#28a745' : 
                            data.status === 'error' ? '#dc3545' : '#ffc107'
                        };
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    ">
                        <div>
                            <div style="font-weight: bold;">${statusIcon} ${chartName}</div>
                            <div style="font-size: 11px; color: var(--text-secondary);">
                                Atualizado: ${data.lastUpdate} | Contagem: ${data.count}
                            </div>
                        </div>
                        ${errorBadge}
                    </div>
                `;
            })
            .join('');

        // Atualizar log
        const logEl = document.getElementById('monitor-log');
        logEl.innerHTML = this.updateLog
            .slice()
            .reverse()
            .map(entry => {
                const icon = entry.status === 'success' ? '✅' : '❌';
                const color = entry.status === 'success' ? '#28a745' : '#dc3545';
                return `
                    <div style="
                        margin-bottom: 4px;
                        padding: 4px;
                        border-left: 2px solid ${color};
                        color: ${color};
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    ">
                        ${icon} [${entry.timestamp}] ${entry.chart}${entry.details ? ': ' + entry.details : ''}
                    </div>
                `;
            })
            .join('');
    }

    /**
     * Inicia o monitoramento
     */
    startMonitoring() {
        this.isMonitoring = true;
        console.log('🔍 Dashboard Monitor iniciado');
        this.updateMonitorDisplay();
    }

    /**
     * Para o monitoramento
     */
    stopMonitoring() {
        this.isMonitoring = false;
        console.log('⏹️  Dashboard Monitor parado');
    }

    /**
     * Limpa o log
     */
    clearLog() {
        this.updateLog = [];
        this.chartStatus = {};
        this.totalUpdates = 0;
        this.errorCount = 0;
        this.updateMonitorDisplay();
        console.log('🗑️  Log do monitor limpo');
    }
}

// Instanciar o monitor globalmente
window.dashboardMonitor = new DashboardMonitor();

// Exportar para uso nos gráficos
window.logChartUpdate = (chartName, status = 'success', details = '') => {
    window.dashboardMonitor.logUpdate(chartName, status, details);
};
