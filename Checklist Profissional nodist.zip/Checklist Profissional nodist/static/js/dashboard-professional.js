/**
 * Dashboard Professional Extensions - Fase 1
 * Alertas, Health Score e Call Metrics
 * 
 * Adiciona funcionalidades profissionais ao dashboard
 */

class DashboardProfessional {
    constructor() {
        this.alerts = [];
        this.maxAlerts = 10;
        this.thresholds = this.getDefaultThresholds();
        this.healthHistory = [];
        this.callMetricsHistory = [];
    }

    // ==================== THRESHOLDS ====================
    getDefaultThresholds() {
        return {
            cpu: { warning: 70, critical: 85, alarm: 95 },
            memory: { warning: 75, critical: 88, alarm: 95 },
            disk: { warning: 80, critical: 90, alarm: 98 },
            callSuccessRate: { warning: 99, critical: 95, alarm: 90 },
            latency: { warning: 100, critical: 150, alarm: 250 },
            phonesUnregistered: { warning: 5, critical: 15, alarm: 30 },
            trunksDown: { warning: 1, critical: 2, alarm: -1 }
        };
    }

    // ==================== ALERTAS ====================
    /**
     * Verifica thresholds e gera alertas
     */
    checkAndGenerateAlerts(data) {
        this.alerts = [];

        // Verificar CPU
        if (data.clusterHealth) {
            data.clusterHealth.forEach(node => {
                this.checkMetric('cpu', node.name, node.cpu);
                this.checkMetric('memory', node.name, node.memory);
                this.checkMetric('disk', node.name, node.disk);
            });
        }

        // Verificar Telefones
        if (data.phoneStatus) {
            const totalPhones = data.phoneStatus.registered + 
                              data.phoneStatus.unregistered + 
                              data.phoneStatus.partial;
            const unregisteredPercent = (data.phoneStatus.unregistered / totalPhones) * 100;
            this.checkMetric('phonesUnregistered', 'Global', unregisteredPercent);
        }

        // Verificar Trunks
        if (data.trunkStatus) {
            const trunkDown = data.trunkStatus.filter(t => t.status.toLowerCase() !== 'online').length;
            if (trunkDown > 0) {
                this.checkMetric('trunksDown', 'Global', trunkDown);
            }
        }

        return this.alerts;
    }

    /**
     * Verifica uma métrica específica contra thresholds
     */
    checkMetric(metricName, nodeName, value) {
        const threshold = this.thresholds[metricName];
        if (!threshold) return;

        let severity = null;
        if (value >= threshold.alarm) severity = 'alarm';
        else if (value >= threshold.critical) severity = 'critical';
        else if (value >= threshold.warning) severity = 'warning';

        if (severity) {
            const alert = {
                id: `${metricName}_${nodeName}_${Date.now()}`,
                severity: severity,
                metric: metricName,
                node: nodeName,
                value: value.toFixed(1),
                threshold: threshold[severity],
                message: this.generateAlertMessage(metricName, nodeName, value, severity),
                timestamp: new Date().toLocaleTimeString('pt-BR', { hour12: false }),
                read: false
            };

            this.alerts.push(alert);
            window.logChartUpdate('Alert System', 'success', `${severity.toUpperCase()}: ${alert.message}`);
        }
    }

    /**
     * Gera mensagem descritiva para alerta
     */
    generateAlertMessage(metric, node, value, severity) {
        const severityText = {
            warning: '⚠️ Aviso',
            critical: '🔴 Crítico',
            alarm: '🚨 Alerta'
        }[severity];

        const metricLabel = {
            cpu: 'CPU',
            memory: 'Memória',
            disk: 'Disco',
            phonesUnregistered: 'Telefones Não Registrados',
            trunksDown: 'Trunks Down',
            callSuccessRate: 'Taxa de Sucesso',
            latency: 'Latência'
        }[metric];

        return `${severityText}: ${metricLabel} em ${node} = ${value}%`;
    }

    /**
     * Renderiza alertas no DOM
     */
    renderAlerts() {
        const banner = document.getElementById('alertBanner');
        if (!banner) return;

        if (this.alerts.length === 0) {
            banner.innerHTML = '<div class="alert-success">✅ Todos os sistemas operacionais normalmente</div>';
            banner.classList.remove('has-alerts');
            return;
        }

        banner.classList.add('has-alerts');
        
        // Agrupar por severidade
        const byType = {
            alarm: this.alerts.filter(a => a.severity === 'alarm'),
            critical: this.alerts.filter(a => a.severity === 'critical'),
            warning: this.alerts.filter(a => a.severity === 'warning')
        };

        let html = '';
        
        // Renderizar por ordem de severidade
        if (byType.alarm.length > 0) {
            html += this.renderAlertGroup(byType.alarm, 'alarm');
        }
        if (byType.critical.length > 0) {
            html += this.renderAlertGroup(byType.critical, 'critical');
        }
        if (byType.warning.length > 0) {
            html += this.renderAlertGroup(byType.warning, 'warning');
        }

        banner.innerHTML = html;
    }

    /**
     * Renderiza grupo de alertas
     */
    renderAlertGroup(alerts, severity) {
        const colors = {
            alarm: '#dc3545',
            critical: '#ff6b35',
            warning: '#ffc107'
        };

        const icons = {
            alarm: '🚨',
            critical: '🔴',
            warning: '⚠️'
        };

        return `
            <div class="alert-group" style="border-left: 4px solid ${colors[severity]};">
                <div class="alert-header">
                    <span>${icons[severity]} ${alerts.length} ${severity.toUpperCase()}</span>
                    <button class="alert-toggle" onclick="this.closest('.alert-group').classList.toggle('collapsed')">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div class="alert-items">
                    ${alerts.map(alert => `
                        <div class="alert-item" data-alert-id="${alert.id}">
                            <span>${alert.message}</span>
                            <span class="alert-time">${alert.timestamp}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // ==================== HEALTH SCORE ====================
    /**
     * Calcula Health Score (0-100)
     */
    calculateHealthScore(data) {
        const weights = {
            cluster: 0.25,      // CPU + MEM + DISK
            callQuality: 0.35,  // Taxa sucesso + Latência
            availability: 0.25, // Uptime + Services
            resources: 0.15     // Recursos disponíveis
        };

        // 1. Cluster Score
        let clusterUsage = 0;
        if (data.clusterHealth && data.clusterHealth.length > 0) {
            const avg = data.clusterHealth.reduce((sum, node) => {
                return sum + ((node.cpu + node.memory + node.disk) / 3);
            }, 0) / data.clusterHealth.length;
            clusterUsage = avg;
        }
        const clusterScore = Math.max(0, 100 - clusterUsage) * weights.cluster;

        // 2. Call Quality Score (assumir 99.5% padrão se não tiver dados)
        const callQuality = 99.5;
        const callScore = callQuality * weights.callQuality;

        // 3. Availability Score (baseado em serviços)
        let availScore = 100;
        if (data.serviceStatus) {
            const running = data.serviceStatus.filter(s => s.status === 'Started').length;
            const availPercent = (running / data.serviceStatus.length) * 100;
            availScore = availPercent * weights.availability;
        } else {
            availScore = 100 * weights.availability;
        }

        // 4. Resources Score
        let resourceUsage = 0;
        if (data.mediaResources) {
            const resources = Object.values(data.mediaResources);
            const usagePercent = resources.reduce((sum, r) => {
                return sum + ((r.inUse / r.total) * 100);
            }, 0) / resources.length;
            resourceUsage = usagePercent;
        }
        const resourceScore = Math.max(0, 100 - resourceUsage) * weights.resources;

        // Score final
        const finalScore = Math.round(clusterScore + callScore + availScore + resourceScore);
        
        // Guardar histórico
        this.healthHistory.push({
            timestamp: new Date(),
            score: finalScore
        });

        return finalScore;
    }

    /**
     * Obtém status do Health Score
     */
    getHealthStatus(score) {
        if (score >= 90) return { status: 'Excelente', color: '#28a745', icon: '🟢' };
        if (score >= 80) return { status: 'Bom', color: '#ffc107', icon: '🟡' };
        if (score >= 70) return { status: 'Aceitável', color: '#ff9800', icon: '🟠' };
        return { status: 'Crítico', color: '#dc3545', icon: '🔴' };
    }

    /**
     * Renderiza card de Health Score
     */
    renderHealthScore(score) {
        const health = this.getHealthStatus(score);
        const trend = this.calculateTrend();
        const trendIcon = trend > 0 ? '📈 ↑' : trend < 0 ? '📉 ↓' : '➡️';

        return `
            <div class="health-score-card" style="border-left: 4px solid ${health.color};">
                <div class="health-header">
                    <span class="health-title">${health.icon} Health Score</span>
                    <span class="health-score" style="color: ${health.color};">${score}</span>
                </div>
                <div class="health-status" style="color: ${health.color};">${health.status}</div>
                <div class="health-trend">${trendIcon} ${Math.abs(trend).toFixed(1)}% vs última hora</div>
            </div>
        `;
    }

    /**
     * Calcula tendência do Health Score
     */
    calculateTrend() {
        if (this.healthHistory.length < 2) return 0;
        
        const last = this.healthHistory[this.healthHistory.length - 1].score;
        const previous = this.healthHistory[Math.max(0, this.healthHistory.length - 10)].score;
        
        return ((last - previous) / previous) * 100;
    }

    // ==================== CALL METRICS ====================
    /**
     * Calcula e retorna métricas de chamadas
     */
    calculateCallMetrics(data) {
        // Dados simulados (seria preenchido pela API real)
        const metrics = {
            totalAttempts: data.callVolume?.data?.[data.callVolume.data.length - 1] * 10 || 5430,
            successful: 0,
            failed: 0,
            successRate: 99.08,
            dropped: Math.floor(Math.random() * 15),
            authFailures: Math.floor(Math.random() * 5),
            avgDuration: 185,  // segundos
            avgLatency: 45,     // ms
            peakHour: '11:00-12:00'
        };

        // Calcular successful/failed
        metrics.successful = Math.floor(metrics.totalAttempts * (metrics.successRate / 100));
        metrics.failed = metrics.totalAttempts - metrics.successful;

        this.callMetricsHistory.push({
            timestamp: new Date(),
            metrics: metrics
        });

        return metrics;
    }

    /**
     * Renderiza cards de Call Metrics
     */
    /**
     * Renderiza resumo rápido de métricas de chamadas (para "Últimas Chamadas")
     */
    renderCallMetricsQuick(metrics) {
        const successPercent = metrics.successRate.toFixed(2);
        const successColor = metrics.successRate > 99 ? '#28a745' : 
                           metrics.successRate > 95 ? '#ffc107' : '#dc3545';

        return `
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div style="text-align: center;">
                    <div style="font-size: 20px; font-weight: 900; color: ${successColor};">${successPercent}%</div>
                    <div style="font-size: 11px; color: var(--text-secondary); margin-top: 4px;">Taxa de Sucesso</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 20px; font-weight: 900; color: #0099ff;">${metrics.totalAttempts}</div>
                    <div style="font-size: 11px; color: var(--text-secondary); margin-top: 4px;">Total Chamadas</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 18px; font-weight: 900; color: #28a745;">${metrics.successful}</div>
                    <div style="font-size: 11px; color: var(--text-secondary); margin-top: 4px;">Bem-sucedidas</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 18px; font-weight: 900; color: #dc3545;">${metrics.failed}</div>
                    <div style="font-size: 11px; color: var(--text-secondary); margin-top: 4px;">Falhadas</div>
                </div>
            </div>
        `;
    }

    renderCallMetrics(metrics) {
        const successPercent = metrics.successRate.toFixed(2);
        const successColor = metrics.successRate > 99 ? '#28a745' : 
                           metrics.successRate > 95 ? '#ffc107' : '#dc3545';

        return `
            <div class="call-metrics-container">
                <div class="metric-card">
                    <div class="metric-value" style="color: ${successColor};">${successPercent}%</div>
                    <div class="metric-label">Taxa de Sucesso</div>
                    <div class="metric-detail">de ${metrics.totalAttempts} tentativas</div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-value" style="color: #28a745;">${metrics.successful}</div>
                    <div class="metric-label">Chamadas OK</div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-value" style="color: #dc3545;">${metrics.failed}</div>
                    <div class="metric-label">Falhadas</div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-value" style="color: #ffc107;">${metrics.dropped}</div>
                    <div class="metric-label">Desconectadas</div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-value" style="color: #0099ff;">${metrics.avgDuration}s</div>
                    <div class="metric-label">Duração Média</div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-value" style="color: #00cc6d;">${metrics.avgLatency}ms</div>
                    <div class="metric-label">Latência Média</div>
                </div>
            </div>
        `;
    }

    // ==================== SLA ====================
    /**
     * Calcula SLA Uptime
     */
    calculateSLA() {
        // Simulado - seria baseado em dados reais
        const downtime = Math.random() * 2;  // minutos
        const totalMinutes = 24 * 60;  // um dia
        const uptime = ((totalMinutes - downtime) / totalMinutes) * 100;

        return {
            uptime: uptime.toFixed(2),
            downtime: downtime.toFixed(2),
            status: uptime >= 99.8 ? 'OK' : 'DEGRADED'
        };
    }

    /**
     * Renderiza card SLA
     */
    renderSLA() {
        const sla = this.calculateSLA();
        const color = sla.uptime >= 99.8 ? '#28a745' : '#ffc107';

        return `
            <div class="sla-card" style="border-left: 4px solid ${color};">
                <div class="sla-header">SLA Uptime</div>
                <div class="sla-value" style="color: ${color};">${sla.uptime}%</div>
                <div class="sla-target">Meta: 99.8%</div>
                <div class="sla-status">${sla.status === 'OK' ? '✅ Dentro da meta' : '⚠️ Abaixo da meta'}</div>
            </div>
        `;
    }

    // ==================== RENDER TUDO ====================
    /**
     * Renderiza todos os elementos profissionais
     */
    renderAll(data) {
        // 1. Renderizar Alertas
        const alerts = this.checkAndGenerateAlerts(data);
        this.renderAlerts();

        // 2. Renderizar Health Score
        const healthScore = this.calculateHealthScore(data);
        const healthHtml = this.renderHealthScore(healthScore);
        const healthContainer = document.getElementById('healthScoreContainer');
        if (healthContainer) {
            healthContainer.innerHTML = healthHtml;
        }

        // 3. Renderizar Call Metrics (ambos os containers)
        const callMetrics = this.calculateCallMetrics(data);
        const callHtml = this.renderCallMetrics(callMetrics);
        const callContainer = document.getElementById('callMetricsContainer');
        if (callContainer) {
            callContainer.innerHTML = callHtml;
        }
        
        // 3.1 Renderizar Call Metrics Quick (Últimas Chamadas)
        const callHtmlQuick = this.renderCallMetricsQuick(callMetrics);
        const callContainerQuick = document.getElementById('callMetricsContainerQuick');
        if (callContainerQuick) {
            callContainerQuick.innerHTML = callHtmlQuick;
        }

        // 4. Renderizar SLA
        const slaHtml = this.renderSLA();
        const slaContainer = document.getElementById('slaContainer');
        if (slaContainer) {
            slaContainer.innerHTML = slaHtml;
        }

        return {
            alerts,
            healthScore,
            callMetrics,
            sla: this.calculateSLA()
        };
    }
}

// Instanciar globalmente
window.dashboardProfessional = new DashboardProfessional();
