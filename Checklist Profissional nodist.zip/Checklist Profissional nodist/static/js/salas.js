document.addEventListener('DOMContentLoaded', function() {

    const roomGrid = document.getElementById('room-grid');
    const statusFilter = document.getElementById('status-filter');

    async function fetchAndRenderRooms() {
        try {
            // Idealmente, a URL da API viria do backend, como no dashboard.
            // Por enquanto, usaremos um caminho relativo.
            const response = await fetch('/salas/api/rooms'); 
            if (!response.ok) {
                throw new Error('Falha ao buscar dados das salas.');
            }
            const rooms = await response.json();
            renderRooms(rooms);
        } catch (error) {
            console.error('Erro:', error);
            roomGrid.innerHTML = `<p class="error-message">${error.message}</p>`;
        }
    }

    function renderRooms(rooms) {
        if (!roomGrid) return;
        roomGrid.innerHTML = ''; // Limpa o grid antes de renderizar

        const filterValue = statusFilter.value;

        const filteredRooms = rooms.filter(room => {
            if (filterValue === 'todos') return true;
            return room.status === filterValue;
        });

        if (filteredRooms.length === 0) {
            roomGrid.innerHTML = '<div class="alert alert-info" style="grid-column: 1 / -1;">Nenhuma sala encontrada com o filtro selecionado.</div>';
            return;
        }

        filteredRooms.forEach(room => {
            let statusClass = 'status-ok';
            if (room.status === 'Manutenção') {
                statusClass = 'status-manutencao';
            } else if (room.status === 'Incidente') {
                statusClass = 'status-incidente';
            }

            const card = `
                <div class="room-card ${statusClass}" data-room-id="${room.id}">
                    <div class="room-card-header">
                        <div class="room-card-title">${room.nome}</div>
                        <span class="room-card-status">${room.status}</span>
                    </div>
                    <div class="room-card-body">
                        <p><strong>Local:</strong> ${room.cidade}</p>
                        <p><strong>Última Inspeção:</strong> ${new Date(room.ultima_inspecao).toLocaleDateString('pt-BR')}</p>
                    </div>
                </div>
            `;
            roomGrid.insertAdjacentHTML('beforeend', card);
        });
    }

    // Event Listeners
    statusFilter.addEventListener('change', fetchAndRenderRooms);

    // Carga inicial
    fetchAndRenderRooms();
});