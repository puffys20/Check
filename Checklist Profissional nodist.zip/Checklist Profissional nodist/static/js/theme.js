(function () {
    const storageKey = 'checklist-pro-theme';
    const root = document.documentElement;

    function getStoredTheme() {
        try {
            return localStorage.getItem(storageKey);
        } catch (error) {
            return null;
        }
    }

    function applyTheme(theme) {
        const isLight = theme === 'light';
        root.dataset.theme = isLight ? 'light' : 'dark';

        const toggle = document.getElementById('themeToggle');
        if (!toggle) return;

        toggle.setAttribute('aria-pressed', String(isLight));
        toggle.setAttribute('aria-label', isLight ? 'Ativar modo escuro' : 'Ativar modo claro');
        toggle.title = isLight ? 'Ativar modo escuro' : 'Ativar modo claro';

        const label = toggle.querySelector('.theme-toggle-label');
        if (label) label.textContent = isLight ? 'Claro' : 'Escuro';
    }

    function saveTheme(theme) {
        try {
            localStorage.setItem(storageKey, theme);
        } catch (error) {
        }
    }

    const preferredTheme = getStoredTheme() || 'dark';
    applyTheme(preferredTheme);

    document.addEventListener('DOMContentLoaded', function () {
        const toggle = document.getElementById('themeToggle');
        if (!toggle) return;

        applyTheme(root.dataset.theme || preferredTheme);
        toggle.addEventListener('click', function () {
            const nextTheme = root.dataset.theme === 'light' ? 'dark' : 'light';
            applyTheme(nextTheme);
            saveTheme(nextTheme);
        });
    });
})();
