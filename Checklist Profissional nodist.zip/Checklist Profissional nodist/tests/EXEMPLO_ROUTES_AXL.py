# Exemplos de integração AXL com Flask
# Adicionar ao seu app.py ou criar um novo blueprint

from flask import Blueprint, jsonify, current_app
from modules.axl_integration import AXLDashboardHelper
import logging

# Criar blueprint
axl_bp = Blueprint('axl', __name__, url_prefix='/api/axl')

logger = logging.getLogger(__name__)

# Instância global do helper
axl_helper = AXLDashboardHelper()


@axl_bp.route('/dashboard-stats', methods=['GET'])
def get_dashboard_stats():
    """
    Endpoint para obter estatísticas do CallManager
    Retorna dados formatados para os gráficos do dashboard
    """
    result = axl_helper.get_dashboard_data()
    
    if result['sucesso']:
        return jsonify({
            'sucesso': True,
            'dados': result['dados']
        }), 200
    else:
        return jsonify({
            'sucesso': False,
            'mensagem': result.get('erro', 'Erro desconhecido')
        }), 500


@axl_bp.route('/devices', methods=['GET'])
def get_devices():
    """Retorna apenas estatísticas de dispositivos"""
    if not axl_helper.client:
        return jsonify({'erro': 'AXL não configurado'}), 400
    
    data = axl_helper.client.get_devices_stats()
    return jsonify(data) if data else jsonify({'erro': 'Erro ao obter dados'}), 500


@axl_bp.route('/users', methods=['GET'])
def get_users():
    """Retorna apenas estatísticas de usuários"""
    if not axl_helper.client:
        return jsonify({'erro': 'AXL não configurado'}), 400
    
    data = axl_helper.client.get_users_stats()
    return jsonify(data) if data else jsonify({'erro': 'Erro ao obter dados'}), 500


@axl_bp.route('/sip-trunks', methods=['GET'])
def get_sip_trunks():
    """Retorna apenas estatísticas de troncos SIP"""
    if not axl_helper.client:
        return jsonify({'erro': 'AXL não configurado'}), 400
    
    data = axl_helper.client.get_sip_trunks_stats()
    return jsonify(data) if data else jsonify({'erro': 'Erro ao obter dados'}), 500


@axl_bp.route('/conferences', methods=['GET'])
def get_conferences():
    """Retorna apenas estatísticas de conferências"""
    if not axl_helper.client:
        return jsonify({'erro': 'AXL não configurado'}), 400
    
    data = axl_helper.client.get_conferences_stats()
    return jsonify(data) if data else jsonify({'erro': 'Erro ao obter dados'}), 500


@axl_bp.route('/cluster', methods=['GET'])
def get_cluster():
    """Retorna status do cluster CallManager"""
    if not axl_helper.client:
        return jsonify({'erro': 'AXL não configurado'}), 400
    
    data = axl_helper.client.get_cluster_stats()
    return jsonify(data) if data else jsonify({'erro': 'Erro ao obter dados'}), 500


@axl_bp.route('/status', methods=['GET'])
def get_status():
    """Verifica status da conexão AXL"""
    return jsonify({
        'conectado': axl_helper.client is not None,
        'host': current_app.config.get('CALLMANAGER_HOST', 'não configurado'),
        'mensagem': 'AXL configurado e pronto' if axl_helper.client else 'AXL não está configurado'
    }), 200


# ============ Como integrar ao app.py ============
"""
# Em app.py, adicionar:

from routes.axl_routes import axl_bp

# Registrar blueprint
app.register_blueprint(axl_bp)

# Ou integrar diretamente no seu app.py:

from modules.axl_integration import AXLDashboardHelper

axl_helper = AXLDashboardHelper()

@app.route('/api/dashboard/cisco-stats')
def get_cisco_stats():
    result = axl_helper.get_dashboard_data()
    return jsonify(result), 200 if result['sucesso'] else 500
"""

