#!/usr/bin/env python
# Teste completo do get_rtmt_data função

import sys
sys.path.insert(0, 'c:\\Users\\z616240\\Videos\\Checklist Profissional')

import random
from modules.perfmon_collector import perfmon
from modules.axl_collector import AXLCollector
from datetime import datetime
import json

print("=== DEBUG: Testando Perfmon e AXL Collector ===\n")

print("1️⃣ PERFMON TESTE:")
perfmon_metrics = perfmon.get_all_metrics()
print(f"   CPU: {perfmon_metrics['cpu']}%")
print(f"   Memory: {perfmon_metrics['memory']}%")
print(f"   Disk: {perfmon_metrics['disk']}%")

print("\n2️⃣ COLLECTOR TESTE:")
collector = AXLCollector()
cluster_nodes = collector.get_cluster_nodes()
print(f"   Nós encontrados: {len(cluster_nodes)}")
for node in cluster_nodes:
    print(f"      - {node['name']}")

print("\n3️⃣ SIMULANDO O QUE app.py FAZ:")
phone_status = collector.get_phone_status()
trunk_status = collector.get_trunk_status()
media_resources = collector.get_media_resources()
cucm_version = collector.get_cucm_version()
cluster_nodes = collector.get_cluster_nodes()
service_status = collector.get_service_status()

print(f"   phone_status: {phone_status}")
print(f"   trunk_status: {trunk_status}")
print(f"   service_status: {service_status}")

print("\n4️⃣ MONTAR CLUSTER HEALTH:")
perfmon_metrics = perfmon.get_all_metrics()
print(f"   Perfmon metrics: {perfmon_metrics}")

cluster_health_data = []
for i, node in enumerate(cluster_nodes):
    print(f"   Adicionando nó {i}: {node['name']}")
    cluster_health_data.append({
        'id': f'node-{i}',
        'name': node['name'],
        'cpu': perfmon_metrics['cpu'],
        'memory': perfmon_metrics['memory'],
        'disk': perfmon_metrics['disk']
    })

print("\n5️⃣ RESULTADO FINAL:")
print(json.dumps(cluster_health_data, indent=2))
