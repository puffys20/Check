#!/usr/bin/env python
# Debug script para testar Perfmon e AXL Collector

from modules.perfmon_collector import perfmon
from modules.axl_collector import AXLCollector

print('=== PERFMON ===')
metrics = perfmon.get_all_metrics()
print(f"CPU: {metrics['cpu']}%")
print(f"Memory: {metrics['memory']}%")
print(f"Disk: {metrics['disk']}%")

print('\n=== AXL COLLECTOR ===')
collector = AXLCollector()
nodes = collector.get_cluster_nodes()
print(f'Nós encontrados: {len(nodes)}')
for node in nodes:
    print(f"  - {node['name']}: {node.get('ip', 'N/A')}")

print('\n=== TESTANDO INTEGRAÇÃO ===')
print('Simulando o que app.py faz:')
perfmon_metrics = perfmon.get_all_metrics()
cluster_health_data = []
for i, node in enumerate(nodes):
    cluster_health_data.append({
        'id': f'node-{i}',
        'name': node['name'],
        'cpu': perfmon_metrics['cpu'],
        'memory': perfmon_metrics['memory'],
        'disk': perfmon_metrics['disk']
    })

import json
print(json.dumps(cluster_health_data, indent=2))
