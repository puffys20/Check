#!/usr/bin/env python
# Teste para verificar se endpoint está retornando dados reais

import requests
import json

url = "http://localhost:5000/api/rtmt-data"

print("=== TESTANDO ENDPOINT /api/rtmt-data ===\n")

try:
    response = requests.get(url, timeout=10)
    print(f"Status Code: {response.status_code}\n")
    
    if response.status_code == 200:
        data = response.json()
        print("✅ RESPOSTA RECEBIDA:\n")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        
        # Verificar se Perfmon está funcionando
        if 'dados' in data and 'clusterHealth' in data['dados']:
            for node in data['dados']['clusterHealth']:
                print(f"\n✅ {node['name']}:")
                print(f"   CPU: {node.get('cpu', 'N/A')}%")
                print(f"   Memory: {node.get('memory', 'N/A')}%")
                print(f"   Disk: {node.get('disk', 'N/A')}%")
    
    elif response.status_code == 401:
        print("❌ Erro 401: Não autenticado")
        print("   Verifique se está logado como admin")
        
    elif response.status_code == 403:
        print("❌ Erro 403: Sem permissão")
        print("   Apenas admin pode acessar este endpoint")
        
    else:
        print(f"❌ Erro {response.status_code}: {response.text}")
        
except requests.exceptions.ConnectionError:
    print("❌ Erro: Não conseguiu conectar ao Flask")
    print("   Certifique-se de que Flask está rodando: python app.py")
    
except Exception as e:
    print(f"❌ Erro: {e}")
