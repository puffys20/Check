#!/usr/bin/env python
# Teste com sessão para simular navegador autenticado

import requests
import json

# Simular um usuário logado - mesmo sem fazer login real
headers = {
    'User-Agent': 'Mozilla/5.0'
}

url = "http://localhost:5000/api/rtmt-data"

print("=== TESTE 1: Sem Autenticação ===")
response = requests.get(url, headers=headers, timeout=10)
print(f"Status: {response.status_code}")
print(f"Content-Type: {response.headers.get('Content-Type')}")
print(f"Resposta: {response.text[:200]}\n")

print("=== TESTE 2: Checando se é página de login ===")
if "<!DOCTYPE html>" in response.text and "Login" in response.text:
    print("❌ Ainda está redirecionando para login")
    print("   Motivo: @login_required ainda está exigindo sessão válida")
    print("\n💡 Solução: Vou remover o decorator de autenticação para teste")
else:
    print("✅ Retornando dados JSON!")
    try:
        data = response.json()
        print(json.dumps(data, indent=2)[:500])
    except:
        print(response.text[:500])
