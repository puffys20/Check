#!/usr/bin/env python
# Teste direto da coleta de dados simulando app.py

import json
from modules.perfmon_collector import perfmon
from modules.axl_collector import AXLCollector
from datetime import datetime
import random

print("=== TESTE DIRETO DO ENDPOINT /api/rtmt-data ===\n")

try:
    collector = AXLCollector()
    phone_status = collector.get_phone_status()
    trunk_status = collector.get_trunk_status()
    media_resources = collector.get_media_resources()
    cucm_version = collector.get_cucm_version()
    cluster_nodes = collector.get_cluster_nodes()
    service_status = collector.get_service_status()
    ping_status = collector.check_ping('10.243.190.12')

    # Monta a saúde do cluster com nomes reais E dados de performance REAIS do Perfmon
    perfmon_metrics = perfmon.get_all_metrics()
    print(f"Perfmon metrics: {perfmon_metrics}\n")
    
    cluster_health_data = []
    for i, node in enumerate(cluster_nodes):
        cluster_health_data.append({
            'id': f'node-{i}',
            'name': node['name'],
            'cpu': perfmon_metrics['cpu'],
            'memory': perfmon_metrics['memory'],
            'disk': perfmon_metrics['disk']
        })

    dados_coletados = {
        'clusterHealth': cluster_health_data,
        'callVolume': {
            'labels': ['-60m', '-50m', '-40m', '-30m', '-20m', '-10m', 'Agora'],
            'data': [random.randint(20, 150) for _ in range(7)]
        },
        'phoneStatus': phone_status,
        'trunkStatus': trunk_status,
        'mediaResources': media_resources,
        'cucmVersion': cucm_version.get('version', 'N/A'),
        'serviceStatus': service_status,
        'connectionMode': collector.connection_status_detail,
        'pingStatus': ping_status,
        'lastUpdated': datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
        'wsdlTimestamp': collector.get_wsdl_timestamp()
    }

    print("=== CLUSTER HEALTH (CPU/MEMORY/DISK) ===")
    for node in dados_coletados['clusterHealth']:
        print(f"{node['name']}:")
        print(f"  CPU: {node['cpu']}%")
        print(f"  Memory: {node['memory']}%")
        print(f"  Disk: {node['disk']}%\n")

    print("=== DADOS COMPLETOS ===")
    print(json.dumps(dados_coletados, indent=2, ensure_ascii=False))
    
except Exception as e:
    import traceback
    print(f"Erro: {e}")
    traceback.print_exc()
