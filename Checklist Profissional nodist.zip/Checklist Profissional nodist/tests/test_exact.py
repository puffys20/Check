#!/usr/bin/env python
# Simular exatamente o que Flask está fazendo no endpoint

import sys
sys.path.insert(0, '.')

# Importar exatamente como app.py faz
from modules.perfmon_collector import perfmon
from modules.axl_collector import AXLCollector
import random
import json
from datetime import datetime

print("=== SIMULANDO EXATAMENTE O CÓDIGO DO ENDPOINT ===\n")

try:
    print("1. Importando perfmon...")
    from modules.perfmon_collector import perfmon
    print("   ✓ OK\n")
    
    print("2. Criando AXLCollector...")
    collector = AXLCollector()
    print("   ✓ OK\n")
    
    print("3. Coletando dados...")
    phone_status = collector.get_phone_status()
    trunk_status = collector.get_trunk_status()
    media_resources = collector.get_media_resources()
    cucm_version = collector.get_cucm_version()
    cluster_nodes = collector.get_cluster_nodes()
    service_status = collector.get_service_status()
    ping_status = collector.check_ping('10.243.190.12')
    print("   ✓ OK\n")
    
    print("4. Pegando Perfmon metrics...")
    perfmon_metrics = perfmon.get_all_metrics()
    print(f"   Metrics: {perfmon_metrics}\n")
    
    print("5. Montando cluster_health_data...")
    cluster_health_data = []
    for i, node in enumerate(cluster_nodes):
        print(f"   Node {i}:")
        print(f"     - name: {node['name']}")
        print(f"     - cpu: {perfmon_metrics['cpu']}")
        print(f"     - memory: {perfmon_metrics['memory']}")
        print(f"     - disk: {perfmon_metrics['disk']}")
        cluster_health_data.append({
            'id': f'node-{i}',
            'name': node['name'],
            'cpu': perfmon_metrics['cpu'],
            'memory': perfmon_metrics['memory'],
            'disk': perfmon_metrics['disk']
        })
    print("   ✓ OK\n")
    
    print("6. Montando dados_coletados...")
    dados_coletados = {
        'clusterHealth': cluster_health_data,
        'callVolume': {
            'labels': ['-60m', '-50m', '-40m', '-30m', '-20m', '-10m', 'Agora'],
            'data': [random.randint(20, 150) for _ in range(7)]
        },
        'phoneStatus': phone_status,
        'trunkStatus': trunk_status,
        'mediaResources': media_resources,
        'cucmVersion': cucm_version.get('version', 'N/A'),
        'serviceStatus': service_status,
        'connectionMode': collector.connection_status_detail,
        'pingStatus': ping_status,
        'lastUpdated': datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
        'wsdlTimestamp': collector.get_wsdl_timestamp()
    }
    print("   ✓ OK\n")
    
    print("7. RESULTADO FINAL:")
    print(json.dumps(dados_coletados, indent=2, ensure_ascii=False)[:1000])
    
except Exception as e:
    import traceback
    print(f"\n❌ ERRO: {e}")
    traceback.print_exc()
