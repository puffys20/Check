import io
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from app import app
from modules.database import get_db_connection


def setup_user():
    conn = get_db_connection()
    conn.execute(
        "INSERT OR IGNORE INTO usuarios (id, nome_completo, email, senha, departamento, ativo, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (1001, 'Usuário de Teste', 'teste@perfil.local', 'hash', 'TI', 1, 0),
    )
    conn.commit()
    conn.close()


def test_profile_page_has_logo_upload_form():
    setup_user()
    with app.test_client() as client:
        with client.session_transaction() as sess:
            sess['usuario_id'] = 1001
            sess['usuario_nome'] = 'Usuário de Teste'

        response = client.get('/perfil')
        assert response.status_code == 200
        html = response.get_data(as_text=True).lower()
        assert 'upload' in html or 'logo' in html
        assert 'type="file"' in html


def test_upload_profile_logo():
    setup_user()
    with app.test_client() as client:
        with client.session_transaction() as sess:
            sess['usuario_id'] = 1001
            sess['usuario_nome'] = 'Usuário de Teste'

        image = (io.BytesIO(b'fake-image-content'), 'logo.png')
        response = client.post('/perfil/logo', data={'logo': image}, content_type='multipart/form-data', follow_redirects=True)

        assert response.status_code == 200
        conn = get_db_connection()
        usuario = conn.execute('SELECT foto_perfil FROM usuarios WHERE id = ?', (1001,)).fetchone()
        conn.close()
        assert usuario is not None
        assert usuario['foto_perfil'] is not None
        assert usuario['foto_perfil'].endswith('.png')


def test_remove_profile_logo():
    setup_user()
    conn = get_db_connection()
    conn.execute('UPDATE usuarios SET foto_perfil = ? WHERE id = ?', ('perfil/logo_teste.png', 1001))
    conn.commit()
    conn.close()

    with app.test_client() as client:
        with client.session_transaction() as sess:
            sess['usuario_id'] = 1001
            sess['usuario_nome'] = 'Usuário de Teste'

        response = client.post('/perfil/logo/remover', follow_redirects=True)
        assert response.status_code == 200

        conn = get_db_connection()
        usuario = conn.execute('SELECT foto_perfil FROM usuarios WHERE id = ?', (1001,)).fetchone()
        conn.close()
        assert usuario is not None
        assert usuario['foto_perfil'] is None
