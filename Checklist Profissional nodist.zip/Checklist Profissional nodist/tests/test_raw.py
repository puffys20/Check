#!/usr/bin/env python
import requests

url = "http://localhost:5000/api/rtmt-data"

try:
    response = requests.get(url, timeout=10)
    print(f"Status: {response.status_code}")
    print(f"Content-Type: {response.headers.get('Content-Type', 'N/A')}")
    print(f"\nResposta Raw (primeiros 500 caracteres):\n")
    print(response.text[:500])
    
except Exception as e:
    print(f"Erro: {e}")
