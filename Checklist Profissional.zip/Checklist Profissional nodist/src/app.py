# -*- coding: utf-8 -*-
"""
APLICAÇÃO CONSOLIDADA - Checklist Profissional
Integra Claro, Cisco e Salas em uma única plataforma com login centralizado e menu unificado
"""
from flask import Flask, render_template, request, session, redirect, url_for, jsonify, flash, send_from_directory  # type: ignore
from flask_cors import CORS  # type: ignore
from werkzeug.security import generate_password_hash
from werkzeug.utils import secure_filename
from config import BASE_DIR, config
from modules.database import init_db, login_required, get_usuario_info, get_db_connection
from modules.auth import auth_bp
from modules.claro import claro_bp
from modules.cisco import cisco_bp
from modules.salas import salas_bp
from modules.axl_collector import AXLCollector
import logging
from functools import wraps
import os
import warnings
from datetime import datetime
from pathlib import Path

# Carregar variáveis de ambiente do arquivo .env
def load_env_file():
    """Carrega variáveis de ambiente do arquivo .env"""
    # Procurar .env em src/ ou em raiz
    env_paths = [
        Path(__file__).parent / '.env',  # src/.env
        Path(__file__).parent.parent / '.env'  # raiz/.env
    ]
    for env_file in env_paths:
        if env_file.exists():
            with open(env_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    # Ignorar comentários e linhas vazias
                    if line and not line.startswith('#'):
                        if '=' in line:
                            key, value = line.split('=', 1)
                            os.environ[key.strip()] = value.strip()
            break

load_env_file()

# Importar config APÓS carregar .env
from config import config
from werkzeug.security import generate_password_hash



# Suprimir warning do Werkzeug em modo desenvolvimento
warnings.filterwarnings('ignore', message='.*development server.*')

# Configurar logging
log_file = os.path.join(BASE_DIR, 'logs', 'app.log')
os.makedirs(os.path.dirname(log_file), exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Suprimir logs verbose do Werkzeug
logging.getLogger('werkzeug').setLevel(logging.ERROR)
logging.getLogger('flask').setLevel(logging.ERROR)

# Inicializar Flask
base_path = BASE_DIR
app = Flask(
    __name__,
    template_folder=os.path.join(base_path, 'templates'),
    static_folder=os.path.join(base_path, 'static')
)

# Configurações
app.config.from_object(config)
CORS(app)

# Inicializar banco de dados
init_db()

# Registrar blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(claro_bp)
app.register_blueprint(cisco_bp)
app.register_blueprint(salas_bp)

# ============================================================================
# DECORATORS DE AUTENTICAÇÃO
# ============================================================================

def admin_required(f):
    """Decorator para proteger rotas que requerem privilégios de admin ou são do depto de TI"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session:
            return redirect(url_for('auth.login'))
        
        usuario = get_usuario_info(session['usuario_id'])
        is_authorized = usuario and (usuario.get('is_admin') or usuario.get('departamento') == 'TI')

        if not is_authorized:
            flash('Acesso negado. Você precisa ser um administrador ou do departamento de TI.', 'error')
            return redirect(url_for('menu'))
            
        return f(*args, **kwargs)
    return decorated_function

# ============================================================================
# INICIALIZAÇÃO DO ADMIN
# ============================================================================

def criar_admin_padrao():
    """Cria um usuário admin padrão se não existir"""
    with app.app_context():
        conn = get_db_connection()
        admin = conn.execute("SELECT id FROM usuarios WHERE email = ?", (config.ADMIN_EMAIL,)).fetchone()
        if not admin:
            conn.execute("INSERT INTO usuarios (nome_completo, email, senha, departamento, is_admin) VALUES (?, ?, ?, ?, ?)",
                         ('Administrador', config.ADMIN_EMAIL, generate_password_hash(config.ADMIN_PASSWORD), 'Sistema', 1))
            conn.commit()
            logger.info(f"Usuário admin padrão '{config.ADMIN_EMAIL}' criado com sucesso.")
        conn.close()

def definir_admin_adicional():
    """Garante que o usuário especificado seja um administrador."""
    # Substitua pelo email do seu usuário pessoal
    email_pessoal_admin = "gabriel.andrade@example.com" 
    nome_completo_admin = "Gabriel lucas da silva de andrade"

    with app.app_context():
        conn = get_db_connection()
        # Atualiza o usuário com base no nome completo para garantir que seja o correto
        conn.execute("UPDATE usuarios SET is_admin = 1 WHERE nome_completo = ?", (nome_completo_admin,))
        conn.commit()
        logger.info(f"Verificada permissão de admin para o usuário '{nome_completo_admin}'.")
        conn.close()

# ============================================================================
# ROTAS PRINCIPAIS
# ============================================================================

@app.route('/')
def index():
    """Página inicial - redireciona para login ou menu"""
    if 'usuario_id' in session:
        return redirect(url_for('menu'))
    return redirect(url_for('auth.login'))

@app.route('/menu')
@login_required
def menu():
    """Menu principal com submenu para escolher o módulo"""
    usuario = get_usuario_info(session['usuario_id'])
    
    # Preparar dados dos módulos
    modulos = [
        {
            'id': 'claro',
            'nome': 'Checklist Claro',
            'descricao': 'Inspeção de infraestrutura Claro',
            'icone': '📋',
            'cor': '#00cc6d',
            'url': '/claro/'
        },
        {
            'id': 'cisco',
            'nome': 'Checklist Cisco',
            'descricao': 'Inspeção de infraestrutura Cisco',
            'icone': '🔧',
            'cor': '#0099ff',
            'url': '/cisco/'
        },
        {
            'id': 'salas',
            'nome': 'Checklist Salas',
            'descricao': 'Gerenciamento de salas de reunião',
            'icone': '🏢',
            'cor': '#ff9900',
            'url': '/salas/'
        }
    ]
    
    return render_template('menu.html', usuario=usuario, modulos=modulos)

@app.route('/direitos-autorais')
def direitos_autorais():
    """Exibe as informações de propriedade intelectual do projeto."""
    return render_template('direitos_autorais.html')

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    """Serve arquivos enviados pelo usuário para uso no perfil e módulos."""
    return send_from_directory(config.UPLOAD_FOLDER, filename)

@app.route('/perfil')
@login_required
def perfil():
    """Página de perfil do usuário ou painel de admin se for admin"""
    usuario = get_usuario_info(session['usuario_id'])
    
    # Se for admin, mostra a lista de todos os usuários
    if usuario and usuario.get('is_admin'):
        conn = get_db_connection()
        todos_usuarios = conn.execute(
            'SELECT id, nome_completo, email, departamento, data_criacao, is_admin, ativo, foto_perfil FROM usuarios ORDER BY id = ? DESC, nome_completo',
            (usuario['id'],)
        ).fetchall()
        conn.close()
        return render_template('perfil.html', usuario=usuario, todos_usuarios=todos_usuarios)
    return render_template('perfil.html', usuario=usuario, todos_usuarios=None)

@app.route('/perfil/logo', methods=['POST'])
@login_required
def atualizar_logo_perfil():
    """Atualiza a imagem de perfil do usuário logado."""
    arquivo = request.files.get('logo')
    if not arquivo or not arquivo.filename:
        flash('Selecione uma imagem para a logo do perfil.', 'error')
        return redirect(url_for('perfil'))

    extensao = os.path.splitext(arquivo.filename)[1].lower()
    if extensao not in {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}:
        flash('Formato de imagem inválido. Use PNG, JPG, GIF ou WEBP.', 'error')
        return redirect(url_for('perfil'))

    usuario_id = session['usuario_id']
    destino_dir = os.path.join(config.UPLOAD_FOLDER, 'perfil')
    os.makedirs(destino_dir, exist_ok=True)

    usuario = get_usuario_info(usuario_id)
    if usuario and usuario.get('foto_perfil'):
        caminho_antigo = os.path.join(config.UPLOAD_FOLDER, usuario['foto_perfil'])
        if os.path.exists(caminho_antigo):
            os.remove(caminho_antigo)

    nome_arquivo = f"usuario_{usuario_id}_{int(datetime.now().timestamp())}{extensao}"
    nome_seguro = secure_filename(nome_arquivo)
    caminho = os.path.join(destino_dir, nome_seguro)
    arquivo.save(caminho)

    caminho_db = os.path.join('perfil', nome_seguro).replace('\\', '/')
    conn = get_db_connection()
    conn.execute('UPDATE usuarios SET foto_perfil = ? WHERE id = ?', (caminho_db, usuario_id))
    conn.commit()
    conn.close()

    flash('Logo do perfil atualizada com sucesso!', 'success')
    return redirect(url_for('perfil'))

@app.route('/perfil/logo/remover', methods=['POST'])
@login_required
def remover_logo_perfil():
    """Remove a imagem de perfil do usuário."""
    usuario_id = session['usuario_id']
    usuario = get_usuario_info(usuario_id)
    if usuario and usuario.get('foto_perfil'):
        caminho_antigo = os.path.join(config.UPLOAD_FOLDER, usuario['foto_perfil'])
        if os.path.exists(caminho_antigo):
            os.remove(caminho_antigo)

    conn = get_db_connection()
    conn.execute('UPDATE usuarios SET foto_perfil = NULL WHERE id = ?', (usuario_id,))
    conn.commit()
    conn.close()

    flash('Logo do perfil removida com sucesso.', 'success')
    return redirect(url_for('perfil'))

@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    """Dashboard com estatísticas gerais e proteção por senha"""
    usuario_id = session['usuario_id']
    usuario = get_usuario_info(usuario_id)

    if not session.get('dashboard_autorizado'):
        if request.method == 'POST':
            senha = request.form.get('senha', '')
            if senha == config.DASHBOARD_PASSWORD:
                session['dashboard_autorizado'] = True
                return redirect(url_for('dashboard'))
            flash('Senha do dashboard incorreta.', 'error')
            return render_template('dashboard_access.html', usuario=usuario, erro='Senha incorreta')
        return render_template('dashboard_access.html', usuario=usuario)

    conn = get_db_connection()
    
    # Estatísticas Claro
    claro_stats = conn.execute(
        'SELECT COUNT(*) as total FROM relatorios WHERE usuario_id = ? AND modulo = ?',
        (usuario_id, 'Claro')
    ).fetchone()
    
    # Estatísticas Cisco
    cisco_stats = conn.execute(
        'SELECT COUNT(*) as total FROM relatorios WHERE usuario_id = ? AND modulo = ?',
        (usuario_id, 'Cisco')
    ).fetchone()
    
    # Estatísticas Salas
    salas_stats = conn.execute(
        'SELECT COUNT(*) as total FROM inspecoes_salas WHERE usuario_id = ?',
        (usuario_id,)
    ).fetchone()
    
    conn.close()
    
    stats = {
        'claro': claro_stats['total'],
        'cisco': cisco_stats['total'],
        'salas': salas_stats['total']
    }
    
    return render_template('dashboard.html', usuario=usuario, stats=stats)

# ============================================================================
# APIs
# ============================================================================

@app.route('/api/info')
@login_required
def api_info():
    """API com informações da aplicação"""
    usuario = get_usuario_info(session['usuario_id'])
    
    return jsonify({
        'usuario': {
            'id': usuario['id'],
            'nome': usuario['nome_completo'],
            'email': usuario['email'],
            'departamento': usuario.get('departamento', '')
        },
        'modulos': ['Claro', 'Cisco', 'Salas'],
        'versao': '1.0.0',
        'ambiente': 'producao' if not app.debug else 'desenvolvimento'
    })

@app.route('/api/usuarios')
@admin_required
def api_usuarios():
    """API com lista de usuários (para gestão)"""
    conn = get_db_connection()
    usuarios = conn.execute('SELECT id, nome_completo, email, departamento, data_criacao, is_admin, ativo FROM usuarios').fetchall()
    conn.close()
    
    return jsonify({
        'total': len(usuarios),
        'usuarios': [dict(u) for u in usuarios]
    })

@app.route('/api/usuarios/<int:user_id>/reset-password', methods=['POST'])
@admin_required
def resetar_senha(user_id):
    """Reseta a senha de um usuário para um valor padrão"""
    try:
        nova_senha_padrao = 'Mudar@123'
        senha_hash = generate_password_hash(nova_senha_padrao)
        
        conn = get_db_connection()
        # Impede que a senha do admin padrão seja resetada por esta rota
        user = conn.execute("SELECT email FROM usuarios WHERE id = ?", (user_id,)).fetchone()
        if user and user['email'] == config.ADMIN_EMAIL:
            conn.close()
            return jsonify({'sucesso': False, 'mensagem': 'A senha do administrador padrão não pode ser resetada.'}), 403

        conn.execute("UPDATE usuarios SET senha = ? WHERE id = ?", (senha_hash, user_id))
        conn.commit()
        conn.close()
        
        logger.info(f"Senha do usuário ID {user_id} resetada pelo administrador ID {session['usuario_id']}")
        return jsonify({
            'sucesso': True, 
            'mensagem': f'Senha resetada com sucesso para: {nova_senha_padrao}'
        })
    except Exception as e:
        logger.error(f"Erro ao resetar senha: {e}")
        return jsonify({'sucesso': False, 'mensagem': 'Erro interno ao resetar senha.'}), 500

@app.route('/api/usuarios/<int:user_id>/toggle-active', methods=['POST'])
@admin_required
def toggle_active_usuario(user_id):
    """Ativa ou desativa um usuário"""
    try:
        conn = get_db_connection()
        # Impede que o admin padrão seja desativado
        user = conn.execute("SELECT email, ativo FROM usuarios WHERE id = ?", (user_id,)).fetchone()
        if user and user['email'] == config.ADMIN_EMAIL:
            conn.close()
            return jsonify({'sucesso': False, 'mensagem': 'O administrador padrão não pode ser desativado.'}), 403
        
        novo_status = 0 if user['ativo'] == 1 else 1
        conn.execute("UPDATE usuarios SET ativo = ? WHERE id = ?", (novo_status, user_id))
        conn.commit()
        conn.close()
        return jsonify({'sucesso': True, 'mensagem': 'Status do usuário alterado com sucesso.', 'novo_status': novo_status})
    except Exception as e:
        logger.error(f"Erro ao alterar status do usuário: {e}")
        return jsonify({'sucesso': False, 'mensagem': 'Erro interno ao alterar status.'}), 500

@app.route('/api/rtmt-data')
# Removido autenticação para permitir acesso ao JavaScript do dashboard
def get_rtmt_data():
    """API para buscar dados de performance do CUCM com Perfmon real."""
    # NOTA: Agora integrado com Perfmon para CPU/Memória/Disco REAIS
    import random
    try:
        from modules.perfmon_collector import perfmon
        
        collector = AXLCollector()
        phone_status = collector.get_phone_status()
        trunk_status = collector.get_trunk_status()
        media_resources = collector.get_media_resources()
        cucm_version = collector.get_cucm_version()
        cluster_nodes = collector.get_cluster_nodes()
        service_status = collector.get_service_status()

        ping_status = collector.check_ping('10.243.190.12')

        # Monta a saúde do cluster com nomes reais E dados de performance REAIS do Perfmon
        perfmon_metrics = perfmon.get_all_metrics()
        logger.info(f"DEBUG: Perfmon metrics = {perfmon_metrics}")  # DEBUG LOG
        
        cluster_health_data = []
        for i, node in enumerate(cluster_nodes):
            node_data = {
                'id': f'node-{i}',
                'name': node['name'],
                'cpu': perfmon_metrics['cpu'],
                'memory': perfmon_metrics['memory'],
                'disk': perfmon_metrics['disk']
            }
            logger.info(f"DEBUG: Node {i} = {node_data}")  # DEBUG LOG
            cluster_health_data.append(node_data)

        dados_coletados = {
            'clusterHealth': cluster_health_data,
            'callVolume': {
                'labels': ['-60m', '-50m', '-40m', '-30m', '-20m', '-10m', 'Agora'],
                'data': [random.randint(20, 150) for _ in range(7)]
            },
            'phoneStatus': phone_status,
            'trunkStatus': trunk_status,
            'mediaResources': media_resources,
            'cucmVersion': cucm_version.get('version', 'N/A'),
            'serviceStatus': service_status,
            'connectionMode': collector.connection_status_detail,
            'collectionErrors': collector.collection_errors,
            'pingStatus': ping_status,
            'lastUpdated': datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
            'wsdlTimestamp': collector.get_wsdl_timestamp()
        }

        # Registrar o evento de atualização no banco de dados
        usuario_id = session.get('usuario_id')
        if usuario_id is not None:
            try:
                conn = get_db_connection()
                usuario_exists = conn.execute(
                    "SELECT 1 FROM usuarios WHERE id = ?", (usuario_id,)
                ).fetchone()
                if usuario_exists:
                    conn.execute(
                        "INSERT INTO eventos_sistema (usuario_id, tipo_evento, detalhe) VALUES (?, ?, ?)",
                        (usuario_id, 'Atualização Dashboard', f"Dados do CUCM atualizados ({dados_coletados['connectionMode']})")
                    )
                conn.close()
            except Exception as db_error:
                logger.error(f"Erro ao registrar evento de atualização do dashboard: {db_error}")

        # LOG DEBUG ANTES DO RETORNO
        logger.info(f"DEBUG: clusterHealth = {dados_coletados['clusterHealth']}")
        
        return jsonify({'sucesso': True, 'dados': dados_coletados})
    except Exception as e:
        return jsonify({'sucesso': False, 'mensagem': f'Erro ao coletar dados do CUCM: {str(e)}'}), 500

@app.route('/api/rtmt-data/history') # Removido @admin_required para permitir que todos vejam dados simulados
@login_required
def get_rtmt_data_history():
    """
    API para buscar dados históricos de performance do CUCM (últimos 30 dias).
    NOTA: Atualmente usa dados simulados. Em produção, buscaria de um BD.
    """
    try:
        from datetime import datetime, timedelta
        import random
        
        # Pega o número de dias do parâmetro da URL, com 30 como padrão
        dias = request.args.get('dias', 30, type=int)
        
        labels = [(datetime.now() - timedelta(days=i)).strftime('%d/%m') for i in range(dias - 1, -1, -1)]
        
        # Simula dados históricos para CPU, memória e disco
        # O número de pontos de dados agora corresponde ao número de dias
        historical_data = {
            'cpu': {
                'pub': [random.randint(10, 40) for _ in range(dias)],
                'sub1': [random.randint(20, 60) for _ in range(dias)]
            },
            'memory': {
                'pub': [random.randint(20, 50) for _ in range(dias)],
                'sub1': [random.randint(30, 70) for _ in range(dias)]
            },
            'disk': {
                'pub': [random.randint(15, 60) for _ in range(dias)],
                'sub1': [random.randint(10, 50) for _ in range(dias)]
            },
            'call_volume': [random.randint(500, 2500) for _ in range(dias)],
            'phone_status': {
                'registered': [random.randint(1200, 1250) for _ in range(dias)],
                'unregistered': [random.randint(10, 50) for _ in range(dias)],
                'partial': [random.randint(5, 20) for _ in range(dias)]
            },
            'media_resources': {
                'cfb': [random.randint(5, 25) for _ in range(dias)],
                'xcoder': [random.randint(2, 12) for _ in range(dias)],
                'mtp': [random.randint(1, 8) for _ in range(dias)]
            }
        }
        return jsonify({'sucesso': True, 'labels': labels, 'dados': historical_data})
    except Exception as e:
        logger.error(f"Erro ao gerar dados históricos simulados: {e}", exc_info=True)
        return jsonify({'sucesso': False, 'mensagem': 'Erro ao gerar dados históricos.'}), 500

@app.route('/api/recent-activity')
@login_required
def recent_activity():
    """Retorna as 10 atividades mais recentes de todos os módulos."""
    try:
        usuario_id = session['usuario_id']
        conn = get_db_connection()

        # Buscar relatórios de Claro e Cisco
        relatorios = conn.execute(
            """
            SELECT 'Relatório ' || modulo as tipo, nome_arquivo as detalhe, data_geracao as data 
            FROM relatorios 
            WHERE usuario_id = ?
            """, (usuario_id,)
        ).fetchall()

        # Buscar inspeções de Salas
        inspecoes = conn.execute(
            """
            SELECT 'Inspeção' as tipo, sala_nome || ' (' || status || ')' as detalhe, data_inspecao as data
            FROM inspecoes_salas
            WHERE usuario_id = ?
            """, (usuario_id,)
        ).fetchall()

        # Buscar eventos do sistema
        eventos = conn.execute(
            """
            SELECT tipo_evento as tipo, detalhe, data_evento as data
            FROM eventos_sistema
            WHERE usuario_id = ?
            """, (usuario_id,)
        ).fetchall()

        conn.close()
        
        atividades = [dict(r) for r in relatorios] + [dict(i) for i in inspecoes] + [dict(e) for e in eventos]
        atividades.sort(key=lambda x: x['data'], reverse=True)
        
        return jsonify({'sucesso': True, 'atividades': atividades[:10]})
    except Exception as e:
        logger.error(f"Erro ao buscar atividades recentes: {e}", exc_info=True)
        return jsonify({'sucesso': False, 'mensagem': 'Erro ao buscar atividades.'}), 500
# ============================================================================
# TRATAMENTO DE ERROS
# ============================================================================

@app.errorhandler(404)
def not_found(error):
    """Erro 404 - Página não encontrada"""
    return render_template('erros/404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """Erro 500 - Erro interno do servidor"""
    logger.error(f"Erro interno: {error}")
    return render_template('erros/500.html'), 500

@app.errorhandler(403)
def forbidden(error):
    """Erro 403 - Acesso proibido"""
    return render_template('erros/403.html'), 403

@app.before_request
def before_request():
    """Executado antes de cada requisição"""
    session.permanent = True
    app.permanent_session_lifetime = config.PERMANENT_SESSION_LIFETIME

@app.context_processor
def inject_user():
    """Injeta dados do usuário em todos os templates"""
    usuario = None
    if 'usuario_id' in session:
        usuario = get_usuario_info(session['usuario_id'])
        if usuario:
            # Adiciona uma flag de conveniência para os templates.
            # Agora, `usuario.is_authorized_admin` pode ser usado em vez de `usuario.is_admin`.
            usuario['is_authorized_admin'] = usuario.get('is_admin') or usuario.get('departamento') == 'TI'
    
    return {
        'usuario': usuario,
        'ano_atual': datetime.now().year
    }

# ============================================================================
# DEBUG E DESENVOLVIMENTO
# ============================================================================

@app.route('/debug/criar-usuario-teste')
def criar_usuario_teste():
    """Rota de debug para criar usuário de teste"""
    if not app.debug:
        return jsonify({'erro': 'Apenas disponível em modo debug'}), 403
    
    from werkzeug.security import generate_password_hash  # type: ignore
    
    try:
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO usuarios (nome_completo, email, senha, departamento)
               VALUES (?, ?, ?, ?)''',
            ('Usuário Teste', 'teste@example.com', generate_password_hash('123456'), 'TI')
        )
        conn.commit()
        conn.close()
        
        return jsonify({
            'sucesso': True,
            'email': 'teste@example.com',
            'senha': '123456'
        })
    except Exception as e:
        return jsonify({'erro': str(e)}), 500

@app.route('/debug/limpar-banco')
def limpar_banco():
    """Rota de debug para limpar banco de dados"""
    if not app.debug:
        return jsonify({'erro': 'Apenas disponível em modo debug'}), 403
    
    try:
        conn = get_db_connection()
        conn.execute('DELETE FROM inspecoes_salas')
        conn.execute('DELETE FROM relatorios')
        conn.execute('DELETE FROM usuarios')
        conn.commit()
        conn.close()
        
        return jsonify({'sucesso': True, 'mensagem': 'Banco limpo'})
    except Exception as e:
        return jsonify({'erro': str(e)}), 500

@app.route('/debug/test-email')
def test_email():
    """Rota de debug para testar configuração de email"""
    if not app.debug:
        return jsonify({'erro': 'Apenas disponível em modo debug'}), 403
    
    from modules.email_utils import enviar_email_com_anexo
    
    try:
        teste_email = os.getenv('MAIL_USERNAME', 'teste@example.com')
        
        resultado = enviar_email_com_anexo(
            teste_email,
            'Teste de Email - Checklist Profissional',
            '<h2>Email Teste</h2><p>Se você recebeu este email, a configuração está funcionando!</p>'
        )
        
        return jsonify({
            'sucesso': resultado['sucesso'],
            'mensagem': resultado['mensagem'],
            'config': {
                'server': config.MAIL_SERVER,
                'port': config.MAIL_PORT,
                'username': config.MAIL_USERNAME[:5] + '***' if config.MAIL_USERNAME else 'não configurado',
                'use_tls': config.MAIL_USE_TLS
            }
        })
    except Exception as e:
        return jsonify({'erro': str(e)}), 500

# ============================================================================
# INICIALIZAÇÃO
# ============================================================================

if __name__ == '__main__':
    logger.info("=" * 80)
    logger.info("Iniciando Aplicacao Consolidada - Checklist Profissional")
    logger.info(f"Base de dados: {config.DATABASE}")
    logger.info(f"Pasta de uploads: {config.UPLOAD_FOLDER}")
    logger.info(f"Pasta de PDFs: {config.PDFS_FOLDER}")
    logger.info("=" * 80)

    # Garante que o admin padrão exista
    criar_admin_padrao()

    # Garante que o seu usuário pessoal seja admin
    definir_admin_adicional()
    
    # Criar pasta de uploads se não existir
    os.makedirs(config.UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(os.path.join(config.UPLOAD_FOLDER, 'claro'), exist_ok=True)
    os.makedirs(os.path.join(config.UPLOAD_FOLDER, 'cisco'), exist_ok=True)
    os.makedirs(config.PDFS_FOLDER, exist_ok=True)
    
    # Iniciar aplicação
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=False,
        use_reloader=False
    )
